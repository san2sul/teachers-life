src=open('audit2.py').read();exec(src.split("sizes=")[0])
import re,urllib.parse,io
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
STAFF=[{"name":"김과학","phone":"010-1000-0001","dept":"교무부","role":"교무부장","subj":"과학"},{"name":"이수학","phone":"010-1000-0002","dept":"연구부","role":"수업","subj":"수학"},
       {"name":"박국어","phone":"010-1000-0003","dept":"교무부","role":"학적","subj":"국어","email":"park@school.kr"},{"name":"최물리","phone":"010-1000-0004","dept":"과학정보부","role":"부장","subj":"과학"}]
def cls(i,name,roster,phones,emails={}):return {"id":i,"data":{"v":3,"cls":name,"year":2026,"term":"2학기","roster":roster,"phones":phones,"emails":emails,"teachers":[],"msg":"m","sessions":[]}}
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[cls("c1","1학년 1반",[["10101","가람"],["10102","가온"]],{"10101":"010-1111-0001"}),cls("c2","1학년 2반",[["10201","나래"],["10202","누리"]],{"10201":"010-2222-0001","10202":"010-2222-0002"}),cls("c3","2학년 1반",[["20101","다솜"]],{},{"20101":"dasom@ex.com"})],
    "staff":STAFF,"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
import base64,zlib
def dec(url):
  c=url.split("#d=")[1];assert c.startswith("z1.");b=c[3:];b+= "="*(-len(b)%4);raw=zlib.decompress(base64.urlsafe_b64decode(b),-15);return json.loads(raw)
FIX2="(()=>{const R=Date,off=new R('2026-10-27T10:00:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
def newpage(c,fix=FIX):
  P=c.new_page();P.on("pageerror",lambda e:errs.append(str(e)));P.add_init_script(fix);P.add_init_script("try{localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1')}catch(e){}");return P
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",accept_downloads=True);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script("window.__goSpy=[];window.__fileSpy=[];window.__printSpy=[];")
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','set');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}))}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click(".navb[data-v=set]");T.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)");T.wait_for_timeout(300)
  ok(T.is_checked("#shLock") and not T.locator("#shLock").is_disabled(),"공유: 잠금이 기본으로 켜짐")
  T.check("#shPh");T.wait_for_timeout(100);ok(T.locator("#shLock").is_disabled() and T.is_checked("#shLock") and "끌 수 없습니다" in T.inner_text("#shLockNote"),"연락처를 넣으면 잠금을 끌 수 없음")
  T.uncheck("#shPh");T.wait_for_timeout(100)
  T.locator("#mkLink").scroll_into_view_if_needed();T.click("#mkLink");T.wait_for_timeout(1200)
  url=T.inner_text("#linkOut");code=T.inner_text("#linkCodeV");env=dec(url)
  ok(re.fullmatch(r"[0-9A-Z]{4}-[0-9A-Z]{4}",code) is not None and env.get("k")=="lock" and "roster" not in json.dumps(env) and "가람" not in json.dumps(env,ensure_ascii=False),"잠긴 링크: 받는 코드 · 링크 안에 이름 없음")
  ok("학생 2명" in T.inner_text("#linkCode") and "까지" in T.inner_text("#linkCode") and env.get("exp")=="2026-10-30","코드 상자: 담긴 것 · 유효 기간 7일")
  T.screenshot(path="shot/t146_lock.png")
  R=newpage(c);R.goto(url);R.wait_for_timeout(1000)
  ok("잠긴 명단" in R.inner_text("#sheetBox"),"받는 쪽: 코드 묻기")
  R.fill("#ulCode","AAAA-BBBB");R.click("#ulOk");R.wait_for_timeout(1500);ok("맞지 않습니다" in R.inner_text("#ulErr"),"틀린 코드는 열리지 않음")
  R.screenshot(path="shot/t146_unlock.png")
  R.fill("#ulCode",code.lower().replace("-"," "));R.click("#ulOk");R.wait_for_timeout(1500)
  ok(R.locator("#rcOk").count()==1,"맞는 코드 → 받기 창 (소문자 · 띄어쓰기 괜찮음)");R.click("#rcOk");R.wait_for_timeout(500)
  st=json.loads(R.evaluate("localStorage.getItem('att-app-v2')"));ok(any(len(x["data"]["roster"])==2 for x in st["list"]),"잠긴 명단 받기 완료");R.close()
  # 유효 기간 지남
  R=newpage(c,FIX2);T.select_option("#shExp","1");T.click("#mkLink");T.wait_for_timeout(1200);url1=T.inner_text("#linkOut")
  R.goto(url1);R.wait_for_timeout(1000);ok(R.locator("#ulCode").count()==0 and "유효 기간" in R.inner_text("body"),"유효 기간이 지난 링크는 열지 않음");R.close()
  # 잠그지 않기
  T.select_option("#shExp","7");T.uncheck("#shLock");T.wait_for_timeout(100);ok("누구나" in T.inner_text("#shLockNote"),"잠금을 끄면 경고")
  T.click("#mkLink");T.wait_for_timeout(1000);p0=dec(T.inner_text("#linkOut"));ok(p0.get("kind")=="share" and p0.get("exp")=="2026-10-30" and T.locator("#linkCode").is_hidden(),"잠그지 않은 링크 (유효 기간 포함)")
  # 파일도 잠금
  T.check("#shLock");T.click("#mkFile");T.wait_for_timeout(1000);fs=T.evaluate("window.__fileSpy");ok(fs and '"k":"lock"' in fs[-1]["text"] and "가람" not in fs[-1]["text"],"공유 파일도 잠금")
  lockfile=fs[-1]["text"];code2=T.inner_text("#linkCodeV")
  R=newpage(c);R.goto("https://tl.test/index.html");R.wait_for_timeout(800);R.click(".navb[data-v=set]");R.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)")
  R.evaluate("t=>{const f=new File([t],'x.json',{type:'application/json'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('restoreFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",lockfile);R.wait_for_timeout(800)
  ok(R.locator("#ulCode").count()==1,"잠긴 파일을 불러오면 코드 묻기");R.fill("#ulCode",code2);R.click("#ulOk");R.wait_for_timeout(1500);ok(R.locator("#rcOk").count()==1,"잠긴 파일 열기");R.close()
  # 저장 실패 띠
  T.evaluate("()=>{window._si=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='att-app-v2')throw new DOMException('full','QuotaExceededError');return window._si.call(this,k,v)}}")
  T.click(".navb[data-v=att]");T.wait_for_timeout(300);T.evaluate("()=>{const b=document.querySelector('[data-m=write]');b&&b.click()}");T.wait_for_timeout(200);T.evaluate("document.querySelector('[data-key=\"w:day\"]').click()");T.wait_for_timeout(150);T.click("#wrCard [data-wn=day]");T.wait_for_timeout(300);T.fill("#wrPl","저장 시험");T.wait_for_timeout(900)
  ok(T.locator("#saveBad").is_visible() and "저장되지 않았습니다" in T.inner_text("#saveBad"),"저장 실패 → ‘저장 안 됨’ 띠")
  T.screenshot(path="shot/t146_savebad.png")
  T.evaluate("()=>{Storage.prototype.setItem=window._si}");T.click("#sbRetry");T.wait_for_timeout(300)
  ok(T.locator("#saveBad").count()==0 and "저장 시험" in T.evaluate("localStorage.getItem('att-app-v2')"),"다시 저장하면 띠가 사라지고 저장됨")
  T.evaluate("()=>{const r=localStorage.getItem.bind(localStorage);window._gi=Storage.prototype.getItem;Storage.prototype.getItem=function(k){if(k==='att-app-v2')return '{}';return window._gi.call(this,k)}}")
  T.fill("#wrPl","저장 시험 2");T.wait_for_timeout(900);ok(T.locator("#saveBad").is_visible(),"다시 읽어 다르면 저장 실패로 봄")
  T.evaluate("()=>{Storage.prototype.getItem=window._gi}");T.click("#sbRetry");T.wait_for_timeout(300);T.click("#skNo");T.wait_for_timeout(300)
  # 백업 검사
  bk={"v":3,"app":"교사의 생활","savedAt":"2026-10-01T09:00:00Z","classes":[{"cls":"1학년 1반","roster":[["10101","가람"]],"phones":{},"emails":{},"teachers":[],"sessions":[]}],"staff":[],"tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[]}
  T.click(".navb[data-v=set]");T.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)")
  T.evaluate("t=>{const f=new File([t],'b.json',{type:'application/json'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('restoreFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",json.dumps(bk,ensure_ascii=False));T.wait_for_timeout(800)
  ok(T.locator("#sheetBox .bkcmp").count()==1 and T.locator("#sheetBox .bkcmp tr.less").count()>=2 and "지금 자료가 백업보다 많습니다" in T.inner_text("#sheetBox"),"백업 검사: 항목별 비교 · 줄어드는 항목 경고")
  T.screenshot(path="shot/t146_bkcmp.png")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
