src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  runs=lambda:root(T).get("flowRun",{})
  # 수업 전: 시간표 칸(학급 정보)에서 미리 확인 — 목요일 4교시 통합과학(내일)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click(".tc[data-d='3'][data-p='4']");T.wait_for_timeout(400)
  ok(T.is_visible("#cmFl") and "정하지 않음" in T.inner_text("#cmFl"),"시간표 칸 창에 수업 흐름(정하지 않음)")
  T.click("#cmFl");T.wait_for_timeout(300);ok("내일" not in T.inner_text("#sheetBox h2") and "10월 29일" in T.inner_text("#sheetBox h2") and T.is_visible("#flChg"),"수업 전에도 수업 흐름 창(날짜 · 틀 고르기)")
  T.click("#flChg");T.wait_for_timeout(300);T.click("#sheetBox [data-fp='b:grp']");T.click("#sheetBox [data-sc=run]");T.wait_for_timeout(100)
  ok("에만 씁니다" in T.inner_text("#sheetBox"),"적용 범위: 이 수업만");T.click("#flUse");T.wait_for_timeout(300)
  ok(T.locator("#sheetBox .flsr").count()==5 and "모둠 활동" in T.inner_text("#sheetBox .flcur") and "이 수업에서 고름" in T.inner_text("#sheetBox .flcur"),"고른 틀 · 단계 미리 보기")
  t0=T.inner_text("#sheetBox .flsr >> nth=0");ok(t0.startswith("12:00") or t0.startswith("11:"),"단계마다 시각 "+t0.split("\n")[0])
  k=[k for k in runs() if k.startswith("2026-10-29")];ok(k and runs()[k[0]].get("fid")=="b:grp" and not root(T).get("flowSub",{}).get("통합과학"),"이 수업만 저장(교과 기본은 그대로) · 동기화되는 자료에 저장")
  # 미리 돌려 보기 · 알림 시험
  T.evaluate("window.__flowAlerts=[]");T.click("#flBell");T.wait_for_timeout(200);ok(len(T.evaluate("window.__flowAlerts"))==1,"🔔 알림 시험")
  T.click("#flSim");T.wait_for_timeout(5600);txt=T.inner_text("#flDemo");al=T.evaluate("window.__flowAlerts")
  ok("미리 보기" in txt and "모둠 구성" in txt or "모둠 활동" in txt,"미리 돌려 보기(1분 = 1초) "+txt.split("\n")[0])
  ok(any("(미리 보기)" in (m or "") and "시작" in (m or "") for a,m,*_ in al),"미리 돌려 보기에서도 알림 "+str(al[-2:]))
  T.click("#flSim");T.wait_for_timeout(100)
  # 이 수업만 고치기
  T.click("#flMine");T.wait_for_timeout(300);ok("이 수업만 고치기" in T.inner_text("#sheetBox h2") and "원래 틀은 바뀌지 않습니다" in T.inner_text("#sheetBox"),"이 수업만 고치기")
  T.select_option("#sheetBox .fled[data-j='2'] [data-k=m]","20");T.select_option("#sheetBox .fled[data-j='3'] [data-k=m]","15");T.wait_for_timeout(100);T.click("#flOk");T.wait_for_timeout(300)
  r=runs()[k[0]];ok(r.get("fs") and [x["m"] for x in r["fs"]][2:4]==[20,15] and "이 수업만 고침" in T.inner_text("#sheetBox .flcur"),"이 수업에만 적용(단계 시간 바뀜)")
  ok(len(root(T).get("flows",[]))==0,"원래 틀 · 내 틀은 그대로")
  # 끄기 / 켜기 (수업 전)
  T.click("#sheetBox [data-flsw=off]");T.wait_for_timeout(200);ok(runs()[k[0]].get("off") is True and T.locator("#sheetBox .flsteps.off").count()==1,"수업 전에 끄기")
  T.click("#skNo");T.wait_for_timeout(300);ok("꺼짐" in T.inner_text("#cmFl"),"시간표 칸에도 꺼짐 표시")
  T.click("#cmFl");T.wait_for_timeout(300);T.click("#sheetBox [data-flsw=on]");T.wait_for_timeout(200);ok(not runs()[k[0]].get("off") and runs()[k[0]].get("fs"),"다시 켜기(고친 흐름 그대로)")
  T.click("#skNo");T.wait_for_timeout(200);T.click("#skNo");T.wait_for_timeout(200)
  # 오늘 수업 목록의 ⏱ 표시
  T.click(".navb[data-v=todo]");T.wait_for_timeout(500)
  chips=T.evaluate("[...document.querySelectorAll('#tdToday [data-flk]')].map(e=>e.textContent)");ok(len(chips)>=1 and any("흐름 정하기" in x for x in chips),"오늘 수업마다 ⏱ 표시 "+str(chips))
  T.locator("#tdToday [data-flk]").first.click();T.wait_for_timeout(300);ok(T.is_visible("#sheet") and "수업 흐름" in T.inner_text("#sheetBox h2"),"⏱ 표시 → 그 수업의 수업 흐름 창")
  # 이 차시에 쓰기 → 진도표 차시에 붙음
  T.click("#flChg");T.wait_for_timeout(300);T.click("#sheetBox [data-fp='b:exp']");T.click("#sheetBox [data-sc=ch]");T.wait_for_timeout(100);ok("차시를 하는 수업에서 씁니다" in T.inner_text("#sheetBox"),"적용 범위: 이 차시");T.click("#flUse");T.wait_for_timeout(300)
  ok(root(T)["plans"][0]["units"][0]["ch"][1].get("flow")=="b:exp" and "진도표 1-2 차시의 틀" in T.inner_text("#sheetBox .flcur"),"진도표 1-2 차시에 틀이 붙음")
  T.click("#skNo");T.wait_for_timeout(1200);ok("실험" in T.inner_text("#v-todo .nowhero [data-flowbox]"),"지금 수업 카드도 그 틀로")
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#ttPnBtn");T.wait_for_timeout(300)
  ok(T.locator("#ttProg em.pnfl").count()==1 and T.locator("#flSubSel").count()==1,"진도 현황: 차시에 ⏱ 표시 · 교과 기본 틀 고르기")
  T.select_option("#flSubSel","b:3");T.wait_for_timeout(200);ok(root(T)["flowSub"].get("물리학")=="b:3","교과 기본 틀을 진도 현황에서 바로")
  T.screenshot(path="shot/t170.png")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
