src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy,re
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def M(T,key="school:master"):return T.evaluate("k=>new Promise(r=>{const q=indexedDB.open('teachers-life-media');q.onsuccess=()=>{const g=q.result.transaction('m').objectStore('m').get('kv:'+k);g.onsuccess=()=>r(g.result?JSON.parse(g.result):null)}})",key)
def st(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
EMPTY={"active":"c0","list":[{"id":"c0","data":{"v":3,"cls":"","roster":[],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
ADM=copy.deepcopy(EMPTY);#ADM["tt"]["acal"]=[{"g":"x1","from":"2026-11-04","to":"2026-11-04","title":"체육대회","kind":"event"},{"g":"x2","from":"2026-11-19","to":"2026-11-19","title":"수능 휴업","kind":"cancel"},{"g":"x3","from":"2025-11-19","to":"2025-11-19","title":"작년 행사","kind":"event"}]
def dev(b,state,touch=False):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,has_touch=touch);c.route("**/*",handler);T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)))
  T.goto("https://tl.test/index.html");T.evaluate("s=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');if(!localStorage.getItem('att-app-ui'))localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));if(!localStorage.getItem('att-app-clsal'))localStorage.setItem('att-app-clsal','0');localStorage.setItem('att-app-setup','1')}",json.dumps(state));T.reload();T.wait_for_timeout(700);return T
def admin_setup(T,school="물리고등학교"):
  T.click(".navb[data-v=set]");T.evaluate("()=>{document.getElementById('d-school').open=true}");T.click("#schOpen");T.check("#schAgree");T.click("#schOnBtn");T.wait_for_timeout(400)
  T.set_input_files("#schFile","schf/v1.xlsx");T.wait_for_timeout(1200);T.click("#schGo");T.wait_for_timeout(400)
  T.fill("#schName",school);T.evaluate("document.getElementById('schName').dispatchEvent(new Event('change'))");T.wait_for_timeout(300)
def setpage(T):T.evaluate("()=>{document.getElementById('sheet').hidden=true;document.querySelector('.navb[data-v=set]').click();document.getElementById('d-pack').open=true}");T.wait_for_timeout(150)
def openfile(T,text):
  setpage(T);T.evaluate("t=>{const f=new File([t],'pack.json',{type:'application/json'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('packFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",text);T.wait_for_timeout(900)
def by(s,n):return [c for c in s["list"] if c["data"].get("cls")==n]
def dl(A):
  with A.expect_download() as d:A.click("#packMake")
  A.wait_for_timeout(600);return open(d.value.path(),encoding="utf-8").read()
def recv(B,pack,name,code,first=False):
  openfile(B,pack)
  if first:B.click("#pkOk");B.wait_for_timeout(200)
  if B.locator("#pmA").count():B.click("#pmA");B.wait_for_timeout(200)
  B.click(f"#pkList [data-t] >> text={name}");B.fill("#pkCode",code);B.click("#pkGo");B.wait_for_timeout(900)
def roster(s,n):return {r[0]:r[1] for r in by(s,n)[0]["data"]["roster"]}
with sync_playwright() as p:
  b=p.chromium.launch()
  A=dev(b,EMPTY);admin_setup(A);A.click("[data-st=asg]");A.wait_for_timeout(200);A.set_input_files("#asgFile","schf/asg_list.xlsx");A.wait_for_timeout(1000);A.click("#asgGo");A.wait_for_timeout(400)
  ok("처음 만드는 묶음" in A.inner_text("#distBox"),"admin: first pack noted")
  pack1=dl(A);m=M(A);codes={t["name"]:t["code"] for t in m["staff"] if t.get("code")}
  A.wait_for_timeout(300);ok("바뀐 학생 없음" in A.inner_text("#distBox"),"after pack: distribution remembered, nothing changed yet")
  # teacher receives v1
  B=dev(b,EMPTY,touch=True);recv(B,pack1,"김물리",codes["김물리"],first=True);B.click("#pkApply");B.wait_for_timeout(600);s=st(B)
  r11=roster(s,"1학년 1반");sid_song=[k for k,v in r11.items() if v=="송라온"][0];sid_ryu=[k for k,v in r11.items() if v=="류나래"][0]
  # attendance: everyone present; plus an observation for 송라온
  0 and B.evaluate("""([a,b])=>{const c=S.list.find(x=>x.data.cls==='1학년 1반').data;c.sessions.push({id:'ses1',date:'2026-10-20',time:'',label:'',p:Object.fromEntries(c.roster.map(r=>[r[0],true]))});c.obs.push({id:'o1',sid:a,date:'2026-10-20',tags:{},memo:'관찰',at:1});c.sts={[a]:{t:'세특 초안',at:1}};save()}""",[sid_song,sid_ryu]) if False else None
  B.evaluate("([a])=>{const raw=JSON.parse(localStorage.getItem('att-app-v2'));const c=raw.list.find(x=>x.data.cls==='1학년 1반').data;c.sessions.push({id:'ses1',date:'2026-10-20',time:'',label:'',p:Object.fromEntries(c.roster.map(r=>[r[0],true]))});c.obs.push({id:'o1',sid:a,date:'2026-10-20',tags:{},memo:'관찰',at:1});c.sts={[a]:{t:'세특 초안',at:1}};localStorage.setItem('att-app-v2',JSON.stringify(raw))}",[sid_song]);B.reload();B.wait_for_timeout(700)
  # admin uploads v2 and applies everything
  A.set_input_files("#schFile","schf/v2.xlsx");A.wait_for_timeout(1500);A.click("#schGo");A.wait_for_timeout(600)
  A.click("[data-st=asg]");A.wait_for_timeout(500)
  db=A.inner_text("#distBox");print("  distBox:",db)
  ok("전입 2" in db and "반 이동 1" in db and "전출" in db and "학번 변경 1" in db and "이름 변경 1" in db,"admin sees what changed since last distribution")
  pack2=dl(A)
  # teacher receives v2
  recv(B,pack2,"김물리",codes["김물리"]);sh=B.inner_text("#sheetBox");print("  preview:",sh[:900].replace("\n"," | "))
  items=B.evaluate("[...document.querySelectorAll('[data-di]')].map(x=>x.closest('label').innerText)")
  def has(*w):return any(all(x in t for x in w) for t in items)
  ok(has("빠짐","한마루","반 이동","1학년 2반"),"1-1: 한마루 빠짐 → 1학년 2반 (반 이동)")
  ok(has("들어옴","한마루","1학년 1반에서 반 이동","같은 학번이 이미 있어"),"1-2: 한마루 들어옴 from 1학년 1반 — but 10201 is already taken in 1-2 (fixture), so flagged")
  ok(B.evaluate("[...document.querySelectorAll('[data-di]')].find(x=>x.closest('label').innerText.includes('한마루 (10201)')).disabled"),"clashing item cannot be checked")
  ok(has("빠짐","류나래","전출"),"류나래 빠짐 · 전출")
  ok(has("학번","송라온",sid_song,"10130"),"송라온 학번 변경")
  ok(has("이름","신다솜","신다님"),"이름 변경")
  ok(has("들어옴","전입"),"전입 students")
  n_items=len(items);print("  items:",n_items)
  # uncheck the 이름 change
  B.evaluate("()=>{const l=[...document.querySelectorAll('[data-di]')].find(x=>x.closest('label').innerText.includes('신다님'));l.checked=false}")
  B.click("#pkApply");B.wait_for_timeout(700);s=st(B);r11=roster(s,"1학년 1반");r12=roster(s,"1학년 2반")
  ok("한마루" not in r11.values() and "한마루" not in r12.values() and len([v for v in r12.values()])==25,"moved student left 1-1; clash not forced into 1-2")
  ok("류나래" not in r11.values(),"전출 student removed from roster")
  ok("새전입" in roster(s,"1학년 4반").values(),"전입 student added to 1-4")
  ok(r11.get("10130")=="송라온" and sid_song not in r11,"학번 changed")
  ok("신다솜" in r11.values() and "신다님" not in r11.values(),"unchecked change NOT applied")
  c11=by(s,"1학년 1반")[0]["data"];ses=c11["sessions"][0]
  ok(ses["p"].get("10130") and sid_song not in ses["p"] and ses["p"].get(sid_ryu),"attendance moved to new 학번, 전출 student's record kept")
  ok(c11["obs"][0]["sid"]=="10130" and "10130" in c11.get("sts",{}),"observation and 세특 moved to new 학번")
  ok(c11["sch"]["uids"].get("10130") and sid_ryu not in c11["sch"]["uids"],"unique-id map updated")
  ok(len([c for c in s["list"] if c["data"].get("sch")])==6,"no duplicate classes")
  R=json.loads(B.evaluate("localStorage.getItem('att-app-schpack')"));ok(R["upd"] and R["upd"][-1]["n"]==n_items-2,"update logged: "+str(R.get("upd")))
  setpage(B);ok("최근 명단 갱신" in B.inner_text("#packBody"),"update shown in 받은 정보")
  # receiving same pack again: only the skipped change remains
  recv(B,pack2,"김물리",codes["김물리"]);items2=B.evaluate("[...document.querySelectorAll('[data-di]:not([disabled])')].map(x=>x.closest('label').innerText)")
  ok(len(items2)==1 and "신다님" in items2[0],"re-open: only the change I skipped is offered: "+str(items2))
  B.click("#skNo")
  # older pack warning
  recv(B,pack1,"김물리",codes["김물리"]);ok("오래된 묶음" in B.inner_text("#sheetBox"),"older pack warned");B.click("#skNo")
  # undo the update
  setpage(B);B.click("#pkUndo");B.wait_for_timeout(300);B.click("#skOk");B.wait_for_timeout(500);s=st(B);r11=roster(s,"1학년 1반")
  ok("한마루" in r11.values() and "류나래" in r11.values() and r11.get(sid_song)=="송라온","undo: roster back to before the update")
  ok(by(s,"1학년 1반")[0]["data"]["sessions"][0]["p"].get(sid_song),"undo: attendance back on old 학번")
  b.close()
print("fails",F);print(errs)
