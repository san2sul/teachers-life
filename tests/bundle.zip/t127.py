src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ROS=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"]]
def state(tt_extra):
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":"과학실"} for w in range(5)}
  cells["2-3"]={"subject":"통합과학","clsId":"c1","clsName":"","room":""}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]};t.update(tt_extra)
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ROS,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s1","date":"2026-10-21","time":"","label":"","p":{"10101":True}}]}}],
    "staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('%s').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
def dev(b,st,when,cheer=None,wx=None):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,timezone_id="Asia/Seoul");c.route("**/*",handler)
  if wx=="fail":c.route("https://api.open-meteo.com/**",lambda r:r.abort())
  elif wx:c.route("https://api.open-meteo.com/**",lambda r:(calls.append(r.request.url),r.fulfill(json=wx))[1])
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX%when);T.add_init_script(SPY)
  T.goto("https://tl.test/index.html");T.evaluate("([s,ch])=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-cheer',JSON.stringify(ch||{am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','5')}",[json.dumps(st),cheer])
  T.reload();T.wait_for_timeout(900);return T
SPY="window.__plays=[];window.__vib=[];const _p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){window.__plays.push({src:this.src,vol:this.volume});return Promise.resolve()};try{Object.defineProperty(navigator,'vibrate',{value:p=>{window.__vib.push(p);return true},configurable:true})}catch(e){}"
calls=[]
WX={"current":{"temperature_2m":-2.6,"apparent_temperature":-6,"weather_code":0},"daily":{"temperature_2m_max":[4.2],"temperature_2m_min":[-5.1]}}
import urllib.parse as up
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def tk(T):return root(T).get("tasks",[])
def gos(T):return T.evaluate("window.__goSpy.slice()")
with sync_playwright() as p:
  b=p.chromium.launch()
  ST=state({"from":"2026-08-24","to":"2026-12-31"})
  c1=ST["list"][0];c1["data"]["roster"]=[[f"101{i:02d}",n] for i,n in enumerate(["가람","나래","다솜","라온"],1)];c1["data"]["phones"]={"10101":"010-1111-0001","10102":"010-1111-0002","10104":"010-1111-0004"};c1["data"]["emails"]={"10101":"a@ex.com","10102":"b@ex.com"}
  c2=copy.deepcopy(c1);c2["id"]="c2";c2["data"]["cls"]="1학년 2반";c2["data"]["roster"]=[["10201","마루"],["10202","바다"]];c2["data"]["phones"]={"10201":"010-2222-0001"};c2["data"]["emails"]={};c2["data"]["sessions"]=[]
  ST["list"]=[c1,c2]
  ST["tasks"]=[{"id":"T1","k":"hw","n":"3단원 학습지","due":"2026-10-21","cls":["c1","c2"],"miss":{"c1":{"10101":"m","10102":"m","10103":"m","10104":"l"},"c2":{"10201":"m"}},"at":"2026-10-20T00:00:00Z"}]
  E=dev(b,ST,"2026-10-22T10:30:00+09:00");E.evaluate("window.__goSpy=[]")
  # class view → 연락하기
  E.click(".navb[data-v=att]");E.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");E.wait_for_timeout(200);E.click("#tkCard .tkrow");E.wait_for_timeout(150)
  ok(E.is_visible("#tkSms") and "미제출 학생 연락하기" in E.inner_text("#tkSms"),"contact button in check sheet")
  E.click("#tkSms");E.wait_for_timeout(150);sh=E.inner_text("#sheetBox");print("  contact:",sh[:300].replace("\n"," | "))
  ok("연락하기" in sh and E.locator(".tkcr").count()==3,"lists 3 미제출 (늦게 냄 excluded by default)")
  ok("번호 없음" in E.inner_text(".tkcr:has-text('다솜')"),"shows missing phone")
  E.click("[data-tcl='1']");E.wait_for_timeout(100);ok(E.locator(".tkcr").count()==4,"늦게 냄 포함")
  E.click("[data-tcl='0']")
  E.click(".tkcr:has-text('가람') [data-sms]");E.wait_for_timeout(150)
  g=gos(E)[-1];txt=up.unquote(g);print("  sms:",txt[:160]);ok(g.startswith("sms:01011110001") and "가람 학생이 과제 ‘3단원 학습지’(10월 21일 마감)" in txt and "[1학년 1반]" in txt,"personalised SMS with name, class, item, date")
  ok("연락함" in E.inner_text(".tkcr:has-text('가람')"),"marked 연락함 after sending")
  ok(root(E)["tasks"][0]["ct"]["c1"].get("10101"),"contact mark saved")
  E.click(".tkcr:has-text('나래') [data-tel]");E.wait_for_timeout(100);ok(gos(E)[-1]=="tel:01011110002","phone call")
  E.click(".tkcr:has-text('가람') [data-em]");E.wait_for_timeout(100);ok(gos(E)[-1].startswith("mailto:a%40ex.com") or gos(E)[-1].startswith("mailto:a@ex.com"),"email")
  # edit message, group send
  E.fill("#tkcMsg","{이름} 학생 {항목} 꼭 내주세요");E.wait_for_timeout(100)
  E.click("#tkcAll");E.wait_for_timeout(150);g=up.unquote(gos(E)[-1]);ok("01011110001" in g and "01011110002" in g and "해당 학생 3단원 학습지 꼭 내주세요" in g,"group SMS to all with numbers ({이름}→해당)")
  E.click("#skNo");E.wait_for_timeout(150);E.click("#skNo")
  E.reload();E.wait_for_timeout(800);E.evaluate("window.__goSpy=[]");E.click(".navb[data-v=att]");E.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");E.wait_for_timeout(200);E.click("#tkCard .tkrow");E.click("#tkSms");E.wait_for_timeout(150)
  ok(E.input_value("#tkcMsg")=="{이름} 학생 {항목} 꼭 내주세요","edited message remembered")
  E.click("#tkcReset");E.wait_for_timeout(100);ok("아직 제출하지 않았습니다" in E.input_value("#tkcMsg"),"reset to default wording")
  E.click(".tkcr:has-text('가람') [data-ck]");E.wait_for_timeout(100);ok(not root(E)["tasks"][0]["ct"]["c1"].get("10101"),"연락 취소")
  E.click("#skNo");E.wait_for_timeout(150)
  # choose specific students then contact
  E.check("#tkOn [data-on='10103']");E.click("#tkSms");E.wait_for_timeout(150);ok(E.locator(".tkcr").count()==1 and "다솜" in E.inner_text(".tkcr"),"only selected students");E.click("#skNo");E.click("#skNo")
  E.screenshot(path="s542c_x.png")
  # common area: all classes
  E.click(".navb[data-v=att]");E.wait_for_timeout(150);E.evaluate("document.querySelector('[data-key=\"m:task\"]').click()");E.wait_for_timeout(200);E.click("#ttTasks .tkrow");E.wait_for_timeout(150);E.click("#hbCt");E.wait_for_timeout(150)
  sh=E.inner_text("#sheetBox");ok(E.locator(".tkcr").count()==4 and "2개 학급" in sh and "1학년 2반" in E.inner_text(".tkcr:has-text('마루')"),"common area: contact across classes")
  E.screenshot(path="s542_ct.png")
  E.click(".tkcr:has-text('마루') [data-sms]");E.wait_for_timeout(100);ok("[1학년 2반] 안녕하세요. 마루 학생이" in up.unquote(gos(E)[-1]),"class name per student in common area")
  E.click("#skNo");E.wait_for_timeout(150);ok("모두 연락하기" in E.inner_text("#sheetBox"),"back to the item")
  # perf wording
  r=root(E);r["tasks"].append({"id":"T2","k":"perf","n":"실험 발표","due":"2026-10-22","cls":["c1"],"miss":{"c1":{"10102":"m"}},"at":"x"});E.evaluate("s=>localStorage.setItem('att-app-v2',s)",json.dumps(r));E.reload();E.wait_for_timeout(800);E.evaluate("window.__goSpy=[]")
  E.click(".navb[data-v=att]");E.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");E.wait_for_timeout(200);E.click("#tkCard .tkrow:has-text('실험 발표')");E.click("#tkSms");E.wait_for_timeout(150)
  ok("수행평가 ‘{항목}’({날짜})에 참여하지 못했습니다" in E.input_value("#tkcMsg"),"수행평가 wording")
  b.close()
print("fails",F);print(errs)
