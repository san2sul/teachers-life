src=open('audit2.py').read();exec(src.split("sizes=")[0])
import re
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def cls(i,name,roster,phones):return {"id":i,"data":{"v":3,"cls":name,"year":2026,"term":"2학기","roster":roster,"phones":phones,"emails":{},"teachers":[],"msg":"{이름} 학생 결석 안내","sessions":[]}}
def state():
  cells={"4-1":{"subject":"물리학","clsId":"c1","clsName":"","room":"과학실"},"4-2":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"0-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""}}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[cls("c1","1학년 1반",[["10101","가람"],["10102","가온"],["10103","나래"]],{"10101":"010-1111-0001","10102":"010-1111-0002"}),cls("c2","1학년 2반",[["10201","누리"]],{})],
    "tt":{"list":[t],"active":"t1"},"notes":{"t1:0:1:2026-10-19":{"progress":"2단원 4차시","date":"2026-10-19","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":1}},"events":[],"evals":[],"tasks":[],"recs":[],"staff":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T09:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def c1(T):return [x for x in root(T)["list"] if x["id"]=="c1"][0]["data"]
def vis(T,sel):return T.evaluate(f"(()=>{{const e=document.querySelector('main.view:not([hidden]) {sel}');return !!(e&&!e.hidden&&e.offsetParent)}})()")
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.add_init_script("try{if(!localStorage.getItem('att-app-ttmode'))localStorage.setItem('att-app-ttmode','week')}catch(e){}");T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script("window.__goSpy=[];")
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  # ---- 지금 수업 단추
  ok(vis(T,".nowhero") and "지금 수업" in T.inner_text("#v-att .nowhero") and "1교시 물리학" in T.inner_text("#v-att .nowhero") and "출석 체크 ›" in T.inner_text("#v-att .nowhero"),"수업 시간에 열면 지금 수업 단추가 맨 위에")
  hb=T.locator("#v-att .nowgo").bounding_box();ok(hb and hb["height"]>=56 and hb["y"]<220,"단추가 크고 화면 위쪽에 있음")
  T.screenshot(path="shot/t148_hero.png")
  T.click("#v-att .nowgo");T.wait_for_timeout(400)
  s=c1(T)["sessions"];ok(len(s)==1 and s[0]["src"]=="t1:4:1" and s[0]["date"]=="2026-10-23","한 번 눌러 지금 수업 출석 체크 시작")
  ok(not vis(T,".nowhero"),"출석 체크 중에는 지금 수업 단추를 숨김")
  # ---- 수업 메모
  ok(vis(T,"#sesMemo") and "1교시 수업 메모" in T.inner_text("#sesMemo") and "2단원 4차시" in T.inner_text("#sesMemo"),"출석 체크 아래 같은 교시 수업 메모 (지난 진도)")
  T.fill("#smProg","2단원 5차시");T.fill("#smMemo","실험 보고서 안내");T.wait_for_timeout(700)
  n=root(T)["notes"].get("t1:4:1:2026-10-23",{});ok(n.get("progress")=="2단원 5차시" and n.get("memo")=="실험 보고서 안내" and n.get("clsId")=="c1","수업 메모가 시간표 메모장에 저장")
  # ---- 결석 연락 바로
  ok(not vis(T,"#abGoBar"),"아직 체크 전(모두 결석 상태)에는 연락 단추 없음")
  T.click("#allIn");T.wait_for_timeout(200)
  T.locator("#list .st").nth(0).click();T.wait_for_timeout(150);T.locator("#list .st").nth(2).click();T.wait_for_timeout(250)
  ok(vis(T,"#abGoBar") and "결석 2명" in T.inner_text("#abGoBar") and "번호 없음 1명" in T.inner_text("#abGoBar"),"출석을 마치면 결석 연락 줄이 바로 나옴")
  T.screenshot(path="shot/t148_abgo.png")
  ok("가람" in T.inner_text("#abNext"),"문자 한 명씩: 첫 학생")
  T.click("#abNext");T.wait_for_timeout(250);g=T.evaluate("window.__goSpy")[-1]
  ok(g.startswith("sms:01011110001") and "%EA%B0%80%EB%9E%8C" in g.replace("가람","%EA%B0%80%EB%9E%8C"),"한 번 눌러 결석 학생에게 이름 들어간 문자")
  ok("1/1" in T.inner_text("#abNext") or "처음부터" in T.inner_text("#abNext"),"다음 학생으로 넘어감")
  T.click("#abGo");T.wait_for_timeout(400)
  ok(T.evaluate("document.querySelector('#v-call').hidden")==False and T.locator("#abList .crow").count()==2,"연락 화면으로 바로 (결석 2명)")
  # ---- 오늘 화면에서도 지금 수업 단추 (이어서) · 닫기
  T.click(".navb[data-v=todo]");T.wait_for_timeout(400)
  ok(vis(T,".nowhero") and "출석 이어서" in T.inner_text("#v-todo .nowhero") and "출석 1/3" in T.inner_text("#v-todo .nowhero"),"다른 화면에서는 ‘출석 이어서’와 현황")
  T.click("#v-todo .nhx");T.wait_for_timeout(200);ok(not vis(T,".nowhero"),"✕로 닫기")
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);ok(not vis(T,".nowhero"),"닫은 수업은 다른 화면에서도 다시 안 뜸")
  # ---- 시간표 3일 보기
  T.click("[data-tm=d3]");T.wait_for_timeout(300)
  ok(T.locator("table.ttg.d3").count()==1,"3일 보기")
  shown=T.evaluate("[...document.querySelectorAll('table.ttg thead th')].filter(e=>getComputedStyle(e).display!=='none').length")
  ok(shown==4,"요일 3개만 보임 (+교시 칸) : %s"%shown)
  ok("10. 21." in T.inner_text("#ttWeekTxt") or "21" in T.inner_text("#ttWeekTxt"),"기간 표시 "+T.inner_text("#ttWeekTxt"))
  fs=T.evaluate("Math.min(...[...document.querySelectorAll('table.ttg .tc b')].filter(e=>e.offsetParent).map(e=>parseFloat(getComputedStyle(e).fontSize)))")
  ok(fs>=11,"3일 보기 글씨 11px 이상 (%.1f)"%fs)
  T.set_viewport_size({"width":360,"height":740});T.wait_for_timeout(300)
  fs=T.evaluate("Math.min(...[...document.querySelectorAll('table.ttg .tc b')].filter(e=>e.offsetParent).map(e=>parseFloat(getComputedStyle(e).fontSize)))");ok(fs>=11,"폭 360px에서도 11px 이상 (%.1f)"%fs)
  T.screenshot(path="shot/t148_d3.png")
  T.click("#ttNext");T.wait_for_timeout(250);ok(T.get_attribute("table.ttg","data-w")=="0" and "26" in T.inner_text("#ttWeekTxt"),"다음 → 다음 주 월~수")
  T.click("#ttPrev");T.wait_for_timeout(250);ok(T.get_attribute("table.ttg","data-w")=="2","이전 → 지난 수~금")
  T.click("#ttPrev");T.wait_for_timeout(250);ok(T.get_attribute("table.ttg","data-w")=="1","하루씩 옮김")
  T.locator("table.ttg .tc[data-d='1'][data-p='1'], table.ttg .tc[data-d='2'][data-p='1']").first.click();T.wait_for_timeout(300);ok(T.evaluate("!document.getElementById('sheet').hidden"),"3일 보기에서도 칸 누르기")
  T.click("#skNo");T.wait_for_timeout(200)
  T.click("[data-tm=week]");T.wait_for_timeout(250);ok(T.locator("table.ttg.d3").count()==0,"주간으로 돌아가기")
  b.close()
  # ---- 아이폰 홈 화면 앱 처음 열기
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,service_workers="block",user_agent="Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1");c.route("**/*",handler)
  I=c.new_page();I.add_init_script("try{if(!localStorage.getItem('att-app-ttmode'))localStorage.setItem('att-app-ttmode','week')}catch(e){}");I.on("pageerror",lambda e:errs.append("I:"+str(e)));I.add_init_script("Object.defineProperty(navigator,'standalone',{get:()=>true})")
  I.goto("https://tl.test/index.html");I.wait_for_timeout(1500)
  ok(I.locator("#wzIos").count()==1 and "전체 백업" in I.inner_text("#wzIos"),"아이폰 홈 화면 앱 처음 열기: 사파리 자료 옮기기 안내")
  I.screenshot(path="shot/t148_ios.png")
  ok(I.locator("#wzBk").count()==1,"백업 파일에서 단추")
  b.close()
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block");c.route("**/*",handler)
  A=c.new_page();A.add_init_script("try{if(!localStorage.getItem('att-app-ttmode'))localStorage.setItem('att-app-ttmode','week')}catch(e){}");A.goto("https://tl.test/index.html");A.wait_for_timeout(1200);ok(A.locator("#wzIos").count()==0,"다른 기기에서는 이 안내가 나오지 않음");b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
