src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400)
  T.click("#mnPnAtt");T.wait_for_timeout(600)
  note=lambda:[v for k,v in root(T)["notes"].items() if k.endswith(":2:3:2026-10-28")]
  plan=lambda:root(T)["plans"][0]
  ok(T.is_visible("#pnFree") and T.input_value("#pnFree")=="","✎ 직접 입력 칸")
  # 한글 조합: 입력 칸이 새로 그려지지 않음
  T.click("#pnFree");cd=c.new_cdp_session(T);T.evaluate("window.__f0=document.getElementById('pnFree')")
  for ch in "가속도":cd.send("Input.imeSetComposition",{"text":ch,"selectionStart":1,"selectionEnd":1});T.wait_for_timeout(120);cd.send("Input.insertText",{"text":ch});T.wait_for_timeout(350)
  ok(T.input_value("#pnFree")=="가속도" and T.evaluate("window.__f0===document.getElementById('pnFree')"),"직접 입력: 한글 입력이 끊기지 않음")
  ok("1-2" in T.inner_text("#pnLink") and T.locator("#pnLink [data-pc]").count()==2,"차시 이름을 쓰면 진도표 차시와 이어짐(🔗 1-2 · 마침 · 반만)")
  T.fill("#pnFree","1-2 가속도, 교과서 54~57쪽");T.wait_for_timeout(400);T.dispatch_event("#pnFree","change");T.wait_for_timeout(300)
  g=plan()["pg"]["c1"];ok(g.get("a2",{}).get("st")=="d" and g["a2"]["d"]=="2026-10-28" and "a3" not in g,"칸을 벗어나면 이어진 차시(1-2만, 54~57쪽은 아님) → 이 수업 마침")
  n=note();ok(n and n[0]["progress"]=="1-2 가속도, 교과서 54~57쪽" and not n[0].get("pAuto"),"직접 입력한 글이 수업 메모 진도로 그대로")
  ok("1-2 가속도" in T.inner_text("#pnFullBox .pncmp div.ok"),"계획과 실제가 같으면 초록 표시 "+T.inner_text("#pnFullBox .pncmp").replace("\n"," "))
  T.click("#pnLink [data-pc='a2|h']");T.wait_for_timeout(200);ok(plan()["pg"]["c1"]["a2"]["st"]=="h" and T.get_attribute("#pnFullBox [data-pc='a2|h']","aria-pressed")=="true","연결 칩에서 반만 → 목록에도")
  n=note();ok(n[0]["progress"]=="1-2 가속도, 교과서 54~57쪽","직접 쓴 글은 기록을 바꿔도 그대로")
  # 진도표에 없는 차시 넣기
  T.fill("#pnFree","실험 보충");T.wait_for_timeout(400);ok("이어지지 않았습니다" in T.inner_text("#pnLink"),"진도표에 없으면 안내")
  T.click("#pnInsB");T.wait_for_timeout(200);ok(T.input_value("#pnInsT")=="실험 보충","넣을 차시 이름 미리 채움")
  ok(T.evaluate("document.getElementById('pnInsP').value")=="0|1","넣을 자리 기본값: 이 수업에서 한 차시 다음 "+T.evaluate("document.getElementById('pnInsP').value"))
  T.click("#pnInsOk");T.wait_for_timeout(300)
  u=plan()["units"][0]["ch"];ok([c["t"] for c in u]==["속력과 속도","가속도","실험 보충","뉴턴 법칙"] and u[2].get("add")=="2026-10-28","진도표 1단원 3차시로 ‘실험 보충’ 들어감(추가 표시)")
  ok(plan()["pg"]["c1"].get(u[2]["id"],{}).get("st")=="d","넣은 차시를 이 수업 마침으로")
  ok(T.locator("#pnFullBox .pnrow em.pnadd").count()==1,"목록에 ‘추가’ 표시")
  ok(len(plan()["orig"]["u"][0]["ch"])==3,"처음 계획은 따로 저장(3차시)")
  T.click("#pnFullX");T.wait_for_timeout(200);T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  # 진도 현황: 처음 계획과 비교
  T.click("#ttPnBtn");T.wait_for_timeout(300)
  ok(T.locator("#ttProg .pndiff").count()==1 and "추가 1" in T.inner_text("#ttProg .pndiff summary") and "5차시 → 지금 6차시" in T.inner_text("#ttProg .pndiff summary"),"처음 계획과 비교: "+T.inner_text("#ttProg .pndiff summary").replace("\n"," "))
  T.click("#ttProg .pndiff summary");T.wait_for_timeout(100);ok("1-3 실험 보충" in T.inner_text("#ttProg .pndiff"),"추가한 차시 목록")
  T.screenshot(path="shot/t167_diff.png")
  # 진도표 고치기에서 이름 바꾸기 → 바뀜
  T.click("#pnEd");T.wait_for_timeout(300);tx=T.input_value("#pnTx");T.fill("#pnTx",tx.replace("뉴턴 법칙","뉴턴 운동 법칙"));T.wait_for_timeout(500);T.click("#pnOk");T.wait_for_timeout(300)
  if not T.is_visible("#ttProg"):T.click("#ttPnBtn");T.wait_for_timeout(300)
  ok("바뀜 1" in T.inner_text("#ttProg .pndiff summary") and plan()["units"][0]["ch"][2].get("add")=="2026-10-28","고치기에서 이름 바꿈 → ‘바뀜’, 추가 표시는 유지")
  # 엑셀에 비고(추가)
  T.click("#ttProg .pndiff summary");T.wait_for_timeout(100);T.click("#pnOrigReset");T.wait_for_timeout(100);T.click("#pnOrigReset");T.wait_for_timeout(300);ok(T.locator("#ttProg .pndiff").count()==0,"비교 기준을 지금 진도표로")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
