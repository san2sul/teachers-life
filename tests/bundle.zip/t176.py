src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"],["10103","나래"],["10104","다온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":False,"10103":False,"10104":False},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{"10102":"010-1111-2222","10103":"010-3333-4444","10104":"010-5555-6666"},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{"t1:0:2:2026-10-26":{"progress":"1-2 가속도 (반만)","memo":"실험 보고서 걷기","date":"2026-10-26","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":2,"updated":1}},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"},"a2":{"st":"h","d":"2026-10-26","k":"t1:0:2:2026-10-26"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click(".navb[data-v=call]");T.wait_for_timeout(400);T.click("#ctabs [data-c=abs]");T.wait_for_timeout(300)
  cnt=lambda:(T.inner_text("#navCnt") if T.get_attribute("#navCnt","hidden") is None else "")
  ok(cnt()=="3" and T.locator("#abList [data-a=skip]").count()==3,"결석 3명 · 연락 알림 3 · 학생마다 ‘연락 제외’ 단추 "+cnt())
  row=T.locator("#abList .crow").nth(0);ok(row.locator("[data-a=done]").is_visible() and row.locator("[data-a=skip]").is_visible(),"‘연락 완료’ 옆에 ‘연락 제외’")
  T.locator("#abList .crow").nth(0).locator("[data-a=skip]").click();T.wait_for_timeout(250)
  ok(cnt()=="2","연락 제외 → 연락 알림 숫자 3 → "+cnt())
  ok("연락 제외" in T.inner_text("#abDoneBox") and "제외 취소" in T.inner_text("#abDone"),"아래 칸에 ‘연락 제외’로 표시 "+T.inner_text("#abDoneBox").replace("\n"," / ")[:80])
  ses=lambda:[x for x in root(T)["list"][0]["data"]["sessions"] if x["id"]=="s1"][0]
  ok(ses().get("dx")=={"10102":1} and "10102" in ses().get("done",{}),"저장: done + dx "+str(ses().get("dx")))
  T.click(".navb[data-v=att]");T.wait_for_timeout(300);T.evaluate("document.querySelector('[data-key=\"m:att\"]')&&document.querySelector('[data-key=\"m:att\"]').click()");T.wait_for_timeout(300)
  if T.locator("[data-av=grid]").count():T.click("[data-av=grid]");T.wait_for_timeout(200)
  tl=T.evaluate("[...document.querySelectorAll('#list .st')].map(e=>e.innerText.replace(/\\n/g,' '))");ok(any("10102" in x or "연락 제외" in x for x in tl) and not any("연락됨" in x for x in tl if "제외" in x) and any("연락 제외" in x for x in tl),"출석부 칸: 연락 제외 학생은 ‘연락 제외’(연락됨 아님) "+str(tl))
  T.click(".navb[data-v=call]");T.wait_for_timeout(300);T.click("#ctabs [data-c=abs]");T.wait_for_timeout(300)
  T.locator("#abList .crow").nth(0).locator("[data-a=done]").click();T.wait_for_timeout(250)
  ok(cnt()=="1" and "완료 1 · 제외 1" in T.inner_text("#abDoneCnt") and "연락 완료 · 제외" in T.inner_text("#abDoneBox h2"),"완료 · 제외 섞여 표시 "+T.inner_text("#abDoneCnt"))
  T.locator("#abDone .crow.skip [data-a=done]").click();T.wait_for_timeout(250)
  ok(cnt()=="2" and not ses().get("dx"),"제외 취소 → 다시 연락할 목록, 알림 2")
  # 여러 명 골라 한꺼번에 제외
  ok(T.is_visible("#cBulk") and T.is_disabled("#pickSkip"),"한꺼번에 고르기 줄(고르기 전엔 단추 꺼짐)")
  T.check("#abList [data-pick='10102']");T.wait_for_timeout(100);ok("고른 1명" in T.inner_text("#pickN") and "1명 연락 제외" in T.inner_text("#pickSkip"),"1명 고름")
  T.check("#pickAll");T.wait_for_timeout(100);ok("고른 2명" in T.inner_text("#pickN"),"모두 고르기 → 2명")
  T.uncheck("#abList [data-pick='10104']");T.wait_for_timeout(100)
  T.click("#pickSkip");T.wait_for_timeout(250);ok(cnt()=="1" and ses().get("dx")=={"10102":1},"고른 학생만 연락 제외 → 알림 1 "+str(ses().get("dx")))
  T.locator("#abDone .crow.skip [data-a=done]").first.click();T.wait_for_timeout(250);ok(cnt()=="2","다시 되돌림")
  T.click("#pickAll");T.wait_for_timeout(100);T.click("#pickSkip");T.wait_for_timeout(250)
  ok(cnt()=="" and len(ses().get("dx",{}))==2,"모두 고르기 → 연락 제외 → 알림 숫자 사라짐")
  T.locator("#abDone .crow.skip [data-a=done]").first.click();T.wait_for_timeout(250);T.locator("#abDone .crow.skip [data-a=done]").first.click();T.wait_for_timeout(250)
  ok(cnt()=="2","되돌림 2")
  T.click("#skipAll");T.click("#skipAll");T.wait_for_timeout(250)
  ok(cnt()=="" and "모두 연락을 마쳤습니다" in T.inner_text("#abList") and len(ses().get("dx",{}))==2,"남은 학생 모두 연락 제외 → 알림 숫자 사라짐 "+repr(cnt()))
  # 출결은 결석 그대로 · 다시 열어도 유지 · 오늘 화면 연락할 학생에서도 빠짐
  ok(not ses()["p"].get("10102"),"출결은 결석 그대로")
  T.reload();T.wait_for_timeout(900);ok(cnt()=="" and len(ses().get("dx",{}))==2,"다시 열어도 유지")
  T.click(".navb[data-v=todo]");T.wait_for_timeout(400);ok("연락할 결석 학생" not in T.inner_text("#v-todo"),"오늘 화면 ‘연락할 결석 학생’에서도 빠짐")
  T.click(".navb[data-v=att]");T.wait_for_timeout(400);T.click("[data-av=list]");T.wait_for_timeout(300);ok("연락 제외" in T.inner_text("#v-att"),"출석부 목록 보기 학생 칸에 ‘연락 제외’ 표시")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
