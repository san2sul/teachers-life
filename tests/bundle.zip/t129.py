src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ROS=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"]]
def state(tt_extra):
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":"과학실"} for w in range(5)}
  cells["2-3"]={"subject":"통합과학","clsId":"c1","clsName":"","room":""}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]};t.update(tt_extra)
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ROS,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s1","date":"2026-10-21","time":"","label":"","p":{"10101":True}}]}}],
    "staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('%s').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
def dev(b,st,when,cheer=None,wx=None):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,timezone_id="Asia/Seoul");c.route("**/*",handler)
  if wx=="fail":c.route("https://api.open-meteo.com/**",lambda r:r.abort())
  elif wx:c.route("https://api.open-meteo.com/**",lambda r:(calls.append(r.request.url),r.fulfill(json=wx))[1])
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX%when);T.add_init_script(SPY)
  T.goto("https://tl.test/index.html");T.evaluate("([s,ch])=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-cheer',JSON.stringify(ch||{am:false,pm:false}));localStorage.setItem('att-app-clsal','5')}",[json.dumps(st),cheer])
  T.reload();T.wait_for_timeout(900);return T
SPY="window.__plays=[];window.__vib=[];const _p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){window.__plays.push({src:this.src,vol:this.volume});return Promise.resolve()};try{Object.defineProperty(navigator,'vibrate',{value:p=>{window.__vib.push(p);return true},configurable:true})}catch(e){}"
calls=[]
WX={"current":{"temperature_2m":-2.6,"apparent_temperature":-6,"weather_code":0},"daily":{"temperature_2m_max":[4.2],"temperature_2m_min":[-5.1]}}
with sync_playwright() as p:
  b=p.chromium.launch()
  ST=state({"from":"2026-08-24","to":"2026-12-31"})
  N=dev(b,ST,"2026-10-22T13:55:00+09:00",{"am":False,"pm":False})
  N.wait_for_timeout(2600);ok(N.is_visible("#sheet") and "오후 일과를 시작해요" in N.inner_text("#sheetBox"),"noon greeting shown")
  btn=N.inner_text("#sheetBox [data-cplay]");ok("오후를 여는 음악" in btn and "오후의 다짐" in btn,"noon music button: "+btn.replace("\n"," "))
  N.evaluate("window.__plays=[]");N.click("#sheetBox [data-cplay]");N.wait_for_timeout(300)
  pl=N.evaluate("window.__plays");ok(any(x["src"].endswith("sounds/noon.mp3") for x in pl),"plays sounds/noon.mp3")
  r=N.evaluate("fetch('sounds/noon.mp3').then(r=>r.blob()).then(b=>[b.size,b.type])");ok(r[0]>500000,"noon.mp3 served ("+str(r)+")")
  N.click("#chGo");N.click(".navb[data-v=set]");N.evaluate("()=>{const d=document.getElementById('d-cheer');d.open=true;d.dispatchEvent(new Event('toggle'))}");N.wait_for_timeout(300)
  ok("오후를 여는 음악" in N.inner_text("#cheerBody") and "앱 음악 ‘오후의 다짐’" in N.inner_text("#cheerBody"),"settings: 오후를 여는 음악")
  N.click("#cheerBody [data-ck=noonM][data-cv=none]");N.wait_for_timeout(150);ok(json.loads(N.evaluate("localStorage.getItem('att-app-cheer')"))["noonM"]=="none","can switch off")
  N.click("#cheerBody [data-ck=amM][data-cv=none]");N.wait_for_timeout(100);ok(json.loads(N.evaluate("localStorage.getItem('att-app-cheer')"))["noonM"]=="none","am/noon settings independent")
  b.close()
print("fails",F);print(errs)
