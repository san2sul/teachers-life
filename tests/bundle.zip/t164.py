src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"],["10103","한별"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",has_touch=True,is_mobile=True,device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  labs=T.evaluate("[...document.querySelectorAll('nav .navb')].map(b=>b.textContent.trim().replace(/\\d+$/,''))")
  ok(labs==["오늘","시간표","출석","연락","기록"],"아래 메뉴 다섯 개 "+str(labs))
  ok(T.evaluate("!!document.querySelector('#topBtns .navb.setb[data-v=set]')"),"설정 단추가 오른쪽 위로")
  ok(T.evaluate("(()=>{const g=document.getElementById('gsPill'),s=document.querySelector('#topBtns .setb');return !g||g.nextElementSibling===s})()"),"설정은 ‘동기화’ 표시 바로 옆")
  T.click(".navb[data-v=todo]");T.wait_for_timeout(300)
  ov=T.evaluate("""(()=>{const R=e=>e.getBoundingClientRect();const top=[...document.querySelectorAll('#topBtns > *')].filter(e=>e.offsetParent).map(R);let o=[];[...document.querySelectorAll('#v-todo button')].filter(e=>e.offsetParent).forEach(e=>{const b=R(e);top.forEach(a=>{if(a.left<b.right&&b.left<a.right&&a.top<b.bottom&&b.top<a.bottom)o.push(e.textContent.trim())})});const g=R(document.querySelector('#topBtns .setb'));return [o,Math.round(g.width),Math.round(g.height)]})()""")
  ok(ov[0]==[] and ov[1]==ov[2]==36,"오늘: 설정 · 도움말과 ‘＋ 일정 · 할 일’이 겹치지 않음, 설정은 36px 원 "+str(ov))
  T.click("#topBtns .setb");T.wait_for_timeout(250);ok(T.is_visible("#v-set") and T.get_attribute("#topBtns .setb","aria-current")=="page","설정 열기")
  # 출석
  T.click("nav .navb[data-v=att]");T.wait_for_timeout(300)
  vis=lambda sel:T.evaluate("[...document.querySelectorAll('%s [data-key]')].filter(b=>!b.hidden&&b.offsetParent).map(b=>b.textContent.trim())"%sel)
  ok(vis("#amode")==["출석부","수업 관찰","출석 통계"],"출석: 출석부 · 수업 관찰 · 출석 통계 "+str(vis("#amode")))
  ok(T.get_attribute("nav .navb[data-v=att]","aria-current")=="page","출석 메뉴 표시")
  ok(T.evaluate("(()=>{const a=document.getElementById('amode'),d=document.getElementById('dayCard');return !!(a.compareDocumentPosition(d)&Node.DOCUMENT_POSITION_FOLLOWING)})()") and T.is_visible("#dayCard"),"날짜는 메뉴 아래(출석부)")
  y0=T.evaluate("document.querySelector('#amode').getBoundingClientRect().top")
  T.click("#amode [data-key='m:obs']");T.wait_for_timeout(300)
  y1=T.evaluate("document.querySelector('#amode').getBoundingClientRect().top")
  ok(abs(y0-y1)<1 and not T.is_visible("#dayCard"),"수업 관찰로 바꿔도 메뉴 자리 그대로 (%s→%s)"%(y0,y1))
  T.screenshot(path="shot/t164_att.png")
  T.click("#amode [data-key='t:att']");T.wait_for_timeout(300)
  ok(T.is_visible("#v-stat") and vis("#stabs")==["출석부","수업 관찰","출석 통계"] and T.get_attribute("nav .navb[data-v=att]","aria-current")=="page","출석 통계도 출석 메뉴 안")
  y2=T.evaluate("document.querySelector('#stabs').getBoundingClientRect().top");ok(abs(y2-y0)<1,"출석 통계 메뉴 자리도 같음 %s"%y2)
  T.click("nav .navb[data-v=att]");T.wait_for_timeout(300);ok(T.is_visible("#m-att") and T.is_visible("#dayCard"),"출석을 한 번 더 누르면 출석부로")
  T.locator("[data-key='t:att']:visible").click();T.wait_for_timeout(200)
  # 기록
  T.click("nav .navb[data-v=rec]");T.wait_for_timeout(300)
  tabs=T.evaluate("[...document.querySelectorAll('#amode .amf')].map(b=>b.textContent.trim())")
  ok(tabs==["평가","기록","학생 정보"],"기록: 평가 · 기록 · 학생 정보 "+str(tabs))
  ok(T.is_visible("#m-task") and vis("#amode")==["평가 점수","학생 서명"] and T.get_attribute("nav .navb[data-v=rec]","aria-current")=="page","기록 메뉴 처음은 평가")
  T.click("#amode [data-sec=rec]");T.wait_for_timeout(300)
  ok(T.is_visible("#m-write") and vis("#amode")==["생활 기록","업무 기록","일상 기록"],"기록 → 생활 · 업무 · 일상")
  T.screenshot(path="shot/t164_rec.png")
  T.click("#amode [data-sec=stu]");T.wait_for_timeout(300)
  ok(T.is_visible("#v-call") and T.is_visible("#c-stu") and T.is_visible("#cnav") and not T.is_visible("#ctabs") and T.inner_text("#callTitle")=="학생 정보","학생 정보")
  ok(T.get_attribute("nav .navb[data-v=rec]","aria-current")=="page" and T.get_attribute("#cnav .amf[data-sec=stu]","aria-selected")=="true","학생 정보에서도 기록 메뉴 표시")
  # 한글 찾기(조합)
  T.click("#stuQ");cd=c.new_cdp_session(T);T.evaluate("window.__q0=document.getElementById('stuQ')")
  for t in ["ㅎ","하","한"]:cd.send("Input.imeSetComposition",{"text":t,"selectionStart":len(t),"selectionEnd":len(t)});T.wait_for_timeout(60)
  cd.send("Input.insertText",{"text":"한"});T.wait_for_timeout(60)
  for t in ["ㅂ","벼","별"]:cd.send("Input.imeSetComposition",{"text":t,"selectionStart":len(t),"selectionEnd":len(t)});T.wait_for_timeout(60)
  cd.send("Input.insertText",{"text":"별"});T.wait_for_timeout(200)
  ok(T.input_value("#stuQ")=="한별" and T.evaluate("window.__q0===document.getElementById('stuQ')&&document.activeElement===window.__q0"),"학생 찾기: 한글 조합이 끊기지 않음 '%s'"%T.input_value("#stuQ"))
  rows=T.evaluate("[...document.querySelectorAll('#c-stu .stur b')].map(b=>b.firstChild.textContent)");ok(rows==["한별"],"찾기 결과 "+str(rows))
  T.screenshot(path="shot/t164_stu.png")
  T.fill("#stuQ","");T.evaluate("document.activeElement.blur()");T.wait_for_timeout(200)
  ys=[]
  for k in ["nav:att","t:att","nav:rec","sec:ev","t:eval","sec:rec","sec:stu"]:
    if k.startswith("nav:"):T.click("nav .navb[data-v=%s]"%k[4:])
    elif k.startswith("sec:"):T.locator("[data-sec=%s]:visible"%k[4:]).click()
    else:T.locator("[data-key='%s']:visible"%k).click()
    T.wait_for_timeout(250);ys.append(round(T.evaluate("[...document.querySelectorAll('#amode,#stabs,#cnav')].find(x=>x.offsetParent).getBoundingClientRect().top")))
  ok(len(set(ys))==1,"출석 · 기록 하위 화면을 옮겨도 메뉴 자리 같음 "+str(ys))
  # 연락
  T.click("nav .navb[data-v=call]");T.wait_for_timeout(300)
  cl=T.evaluate("[...document.querySelectorAll('#ctabs .chip')].map(b=>b.textContent.trim())")
  ok(T.is_visible("#ctabs") and not T.is_visible("#cnav") and T.inner_text("#callTitle")=="연락" and T.is_visible("#c-abs") and cl==["결석 학생","골라 연락","교직원 연락","직접 입력"],"연락: 결석 학생 · 골라 연락 · 교직원 연락 · 직접 입력 "+str(cl))
  ok(T.get_attribute("nav .navb[data-v=call]","aria-current")=="page","연락 메뉴 표시")
  # 기록 → 마지막 하위 화면 기억
  T.click("nav .navb[data-v=rec]");T.wait_for_timeout(300);ok(T.is_visible("#c-stu"),"기록 메뉴는 마지막에 본 화면으로(학생 정보)")
  T.click("#cnav [data-sec=rec]");T.wait_for_timeout(300);T.click("#amode [data-key='w:day']");T.wait_for_timeout(300)
  # 글 목록 찾기 한글
  if T.locator("#wrQ").count():
    T.click("#wrQ");T.evaluate("window.__q1=document.getElementById('wrQ')")
    for t in ["ㅊ","체"]:cd.send("Input.imeSetComposition",{"text":t,"selectionStart":len(t),"selectionEnd":len(t)});T.wait_for_timeout(60)
    cd.send("Input.insertText",{"text":"체"});T.wait_for_timeout(150)
    ok(T.input_value("#wrQ")=="체" and T.evaluate("window.__q1===document.getElementById('wrQ')"),"기록 찾기: 한글 조합")
  # 글쓰기 창: 입력 중 아래 단추 숨김
  T.click("[data-wn=day]");T.wait_for_timeout(500)
  ok(T.is_visible("#wrDel") or T.is_visible("#wrCancel"),"글쓰기 창 아래 단추")
  T.evaluate("window.__tlKb=1");T.locator("#wrEd [contenteditable]").first.click();T.wait_for_timeout(300)
  ok(T.evaluate("document.activeElement.isContentEditable"),"글 칸에 커서")
  ok(not T.is_visible("#wrCancel") and T.evaluate("document.getElementById('sheetBox').classList.contains('kbtyping')"),"입력 중에는 삭제 · 취소 · 전달 · 완료 숨김")
  for i in range(30):T.keyboard.type("줄 %d"%i);T.keyboard.press("Enter")
  T.wait_for_timeout(300)
  vis_ok=T.evaluate("""(()=>{const s=getSelection();const g=s.getRangeAt(0).cloneRange();let r=g.getBoundingClientRect();if(!r.height){let n=g.endContainer;if(n.nodeType!==1)n=n.parentNode;r=n.getBoundingClientRect()}const b=document.getElementById('sheetBox').getBoundingClientRect();return [r.bottom,b.bottom]})()""")
  ok(vis_ok[0]<=vis_ok[1]-10,"엔터 뒤 커서 줄이 창 안에 보임 "+str(vis_ok))
  T.screenshot(path="shot/t164_type.png")
  T.evaluate("document.activeElement.blur()");T.wait_for_timeout(300)
  ok(T.is_visible("#wrCancel") and not T.evaluate("document.getElementById('sheetBox').classList.contains('kbtyping')"),"입력을 마치면(키보드 닫힘) 단추 다시 보임")
  T.click("#wrCancel");T.wait_for_timeout(300)
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
