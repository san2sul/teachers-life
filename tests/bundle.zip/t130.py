src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ROS=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"]]
def state(tt_extra):
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":"과학실"} for w in range(5)}
  cells["2-3"]={"subject":"통합과학","clsId":"c1","clsName":"","room":""}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]};t.update(tt_extra)
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ROS,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s1","date":"2026-10-21","time":"","label":"","p":{"10101":True}}]}}],
    "staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('%s').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
def dev(b,st,when,cheer=None,wx=None):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,timezone_id="Asia/Seoul");c.route("**/*",handler)
  if wx=="fail":c.route("https://api.open-meteo.com/**",lambda r:r.abort())
  elif wx:c.route("https://api.open-meteo.com/**",lambda r:(calls.append(r.request.url),r.fulfill(json=wx))[1])
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX%when);T.add_init_script(SPY)
  T.goto("https://tl.test/index.html");T.evaluate("([s,ch])=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-cheer',JSON.stringify(ch||{am:false,pm:false}));localStorage.setItem('att-app-clsal','5')}",[json.dumps(st),cheer])
  T.reload();T.wait_for_timeout(900);return T
SPY="window.__plays=[];window.__vib=[];const _p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){window.__plays.push({src:this.src,vol:this.volume});return Promise.resolve()};try{Object.defineProperty(navigator,'vibrate',{value:p=>{window.__vib.push(p);return true},configurable:true})}catch(e){}"
calls=[]
WX={"current":{"temperature_2m":-2.6,"apparent_temperature":-6,"weather_code":0},"daily":{"temperature_2m_max":[4.2],"temperature_2m_min":[-5.1]}}
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def recs(T):return root(T).get("recs",[])
def wtab(T):T.click(".navb[data-v=att]");T.wait_for_timeout(150);T.evaluate("document.querySelector('[data-key=\"w:day\"]').click()");T.wait_for_timeout(200)
def typ(T,s):T.keyboard.type(s,delay=10);T.wait_for_timeout(60)
R=lambda i,t,x:{"id":i,"k":"day","at":"2026-10-2"+str(i[-1])+"T09:00","place":"교실","blocks":[{"id":"b"+i,"t":"p","x":x}],"media":[]}
with sync_playwright() as p:
  b=p.chromium.launch()
  ST=state({"from":"2026-08-24","to":"2026-12-31"});ST["recs"]=[R("r1","","첫째 기록"),R("r2","","둘째 기록"),R("r3","","셋째 기록")]
  E=dev(b,ST,"2026-10-22T13:40:00+09:00");wtab(E)
  # editor cancel on new
  E.evaluate("document.querySelector('[data-key=\"w:day\"]').click()");E.wait_for_timeout(150);E.click("#wrCard [data-wn=day]");E.wait_for_timeout(150);E.click("#wrEd .wbt");typ(E,"쓰다 말았음");E.click("#wrCancel");E.wait_for_timeout(150)
  ok("새 글 쓰기 취소" in E.inner_text("#sheetBox"),"cancel asks first");E.click("#wcBack");E.wait_for_timeout(150);ok("쓰다 말았음" in E.inner_text("#wrEd"),"계속 쓰기 returns with text")
  E.click("#wrCancel");E.click("#wcOk");E.wait_for_timeout(150);ok(len(recs(E))==3,"new record discarded on cancel")
  # editor cancel on existing: revert edits + new attachment
  E.click("#wrCard .wrrow:has-text('첫째') .wrmain");E.wait_for_timeout(150);E.fill("#wrPl","바뀐 장소");E.click("#wrEd .wbt");E.keyboard.press("End");typ(E," 추가문장")
  with E.expect_file_chooser() as fc:E.click("[data-wm=photo]")
  fc.value.set_files("wr_photo.jpg");E.wait_for_timeout(700)
  r1=[x for x in recs(E) if x["id"]=="r1"][0];ok(r1["place"]=="바뀐 장소" and len(r1["media"])==1,"edits autosaved")
  E.click("#wrCancel");E.wait_for_timeout(100);ok("첨부 1개도 지웁니다" in E.inner_text("#sheetBox"),"mentions new attachment");E.click("#wcOk");E.wait_for_timeout(300)
  r1=[x for x in recs(E) if x["id"]=="r1"][0];ok(r1["place"]=="교실" and r1["blocks"][0]["x"]=="첫째 기록" and not r1["media"],"cancel restores the original")
  E.click("#wrCard .wrrow:has-text('첫째') .wrmain");E.wait_for_timeout(150);E.click("#wrCancel");E.wait_for_timeout(150);ok(E.is_hidden("#sheet"),"no changes → cancel just closes")
  # list edit mode
  E.click("#wrEdOn");E.wait_for_timeout(100);ok(E.locator("[data-wsel]").count()==3,"edit mode shows checkboxes")
  E.click("#wrCard .wrrow:has-text('둘째') .wrmain");E.check("[data-wsel=r3]");ok("선택 삭제 (2)" in E.inner_text("#wrSelDel"),"select two (tap row or box)")
  E.click("#wrSelDel");E.click("#wrSelDel");E.wait_for_timeout(150);ok([x["id"] for x in recs(E)]==["r1"],"선택 삭제 (two-step)")
  E.click("#utoast button");E.wait_for_timeout(150);ok(len(recs(E))==3,"undo restores")
  E.click("[data-wd=r2]");E.click("[data-wd=r2]");E.wait_for_timeout(150);ok(len(recs(E))==2,"single delete in edit mode")
  E.click("#wrEdX");E.wait_for_timeout(100);ok(E.locator("[data-wsel]").count()==0 and E.locator("#wrCard .wrrow[data-wr]").count()==2,"취소 leaves edit mode")
  # swipe delete
  row=E.locator("#wrCard .wrrow:has-text('셋째')");row.evaluate("e=>e.scrollIntoView({block:'center'})");E.wait_for_timeout(200);bb=row.bounding_box();y=bb["y"]+bb["height"]/2
  E.mouse.move(bb["x"]+bb["width"]-20,y);E.mouse.down();
  for i in range(1,11):E.mouse.move(bb["x"]+bb["width"]-20-i*22,y);E.wait_for_timeout(16)
  E.mouse.up();E.wait_for_timeout(300)
  if E.is_visible(".swdel"):E.click(".swdel");E.wait_for_timeout(300)
  ok(len(recs(E))==1,"swipe left to delete")
  E.screenshot(path="s5432.png")
  b.close()
print("fails",F);print(errs)
