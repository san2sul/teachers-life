src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def state():
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"],["10102","가온"]],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-27T16:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
vis=lambda T,i:T.evaluate(f"(()=>{{const e=document.getElementById('{i}');return !!e&&!e.hidden&&!!e.offsetParent}})()")
with sync_playwright() as p:
  b=p.chromium.launch()
  for W in (390,360):
    c=b.new_context(viewport={"width":W,"height":800},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
    T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1000)
    nav=T.evaluate("[...document.querySelectorAll('nav.bottom .navb')].map(b=>b.dataset.v+':'+b.textContent.trim())")
    ok([x.split(':')[0] for x in nav]==["todo","tt","att","call","set"],f"{W}px 아래 메뉴 순서 {nav}")
    ok("att:출석·기록" in nav and not any(x.startswith("stat") for x in nav),"‘출석·기록’, ‘평가·통계’ 없음")
    tiles=T.evaluate("[...document.querySelectorAll('#amode .amt')].map(b=>[b.textContent.trim(),Math.round(b.getBoundingClientRect().height),Math.round(b.getBoundingClientRect().width)])")
    ok([t[0] for t in tiles]==["출석 체크","출석 통계","관찰 기록","글쓰기","평가 · 과제","학생 서명"],"3 × 2 메뉴 여섯 칸")
    ok(min(t[1] for t in tiles)>=56 and min(t[2] for t in tiles)>=88,f"{W}px 칸 크기 넉넉함 {tiles[0][1:]}")
    ok(T.evaluate("(()=>{const a=[...document.querySelectorAll('#amode .amt')].map(b=>b.getBoundingClientRect());return a[0].top===a[2].top&&a[3].top===a[5].top&&a[3].top>a[0].top})()"),"두 줄 세 칸")
    ok(T.evaluate("document.documentElement.scrollWidth")<=W,f"{W}px 화면 폭 안")
    ok(T.get_attribute("#amode [data-m=att]","aria-pressed")=="true","지금 칸(출석 체크) 표시")
    if W==390:T.screenshot(path="shot/t155_att.png")
    T.click("#amode [data-t=eval]");T.wait_for_timeout(300)
    ok(vis(T,"v-stat") and vis(T,"s-eval") and T.get_attribute(".navb[data-v=att]","aria-current")=="page","학생 서명 → 서명 화면, 아래 메뉴는 출석·기록에 불")
    ok(T.get_attribute("#stabs [data-t=eval]","aria-pressed")=="true" and T.get_attribute("#stabs [data-m=att]","aria-pressed")=="false","서명 화면에서도 같은 여섯 칸, 학생 서명에 불")
    if W==390:T.screenshot(path="shot/t155_sign.png")
    T.click("#stabs [data-t=att]");T.wait_for_timeout(300);ok(vis(T,"s-att") and "출석 통계" in T.inner_text("#stTitle"),"출석 통계")
    T.click("#stabs [data-m=obs]");T.wait_for_timeout(300);ok(vis(T,"v-att") and vis(T,"m-obs") and T.get_attribute("#amode [data-m=obs]","aria-pressed")=="true","통계 화면에서 관찰 기록으로 바로")
    T.click("#amode [data-m=write]");T.wait_for_timeout(300);ok(vis(T,"m-write"),"글쓰기")
    T.click("#amode [data-m=task]");T.wait_for_timeout(300);ok(vis(T,"m-task"),"평가 · 과제")
    T.click("#amode [data-m=att]");T.wait_for_timeout(300);ok(T.get_attribute("#amode [data-m=att]","aria-pressed")=="true","출석 체크로")
    T.click("#amode [data-t=eval]");T.wait_for_timeout(300);T.reload();T.wait_for_timeout(900);ok(vis(T,"v-stat") and T.get_attribute(".navb[data-v=att]","aria-current")=="page","다시 열어도 마지막 화면(서명)")
    c.close()
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
