src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"],["10103","나래"]];r2=[["10201","다솜"]]
def state():
  ses=[{"id":"s1","date":"2026-10-27","time":"10:00","label":"2교시 물리학","p":{"10101":True,"10102":True},"ak":{"10103":"결석"},"ar":{"10103":"질병"}},
       {"id":"s2","date":"2026-10-28","time":"10:00","label":"2교시 물리학","p":{"10102":True,"10103":True}}]
  d1={"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{"10101":"010-1111-0001"},"gph":{"10101":[{"r":"어머니","p":"010-2222-0001"}]},"emails":{},"teachers":[],"msg":"m","sessions":ses,
    "obs":[{"id":"o1","sid":"10101","date":"2026-10-27","tags":{"a1":2,"a3":1},"memo":"실험 설계를 주도함","at":1}],"snote":{"10102":[{"k":"warn","t":"앞자리 배치","at":"2026-10-10T09:00:00Z"}]}}
  return {"active":"c1","list":[{"id":"c1","data":d1},{"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],
    "tasks":[{"id":"x1","k":"exam","n":"중간고사","due":"2026-10-20","cls":["c1"],"miss":{},"at":"2026-10-20T00:00:00Z","max":100,"sc":{"c1":{"10101":72,"10102":90}}}],
    "recs":[{"id":"r1","k":"stu","sub":"cns","at":"2026-10-25T14:30","place":"","stus":[{"sid":"10101","name":"가람","phone":""}],"cns":{"who":"stu","how":"meet","tp":["교우"],"act":"짝 활동","next":"2026-11-04T15:00"},"blocks":[{"id":"b1","t":"p","x":"모둠에서 소외감"}],"media":[]},
            {"id":"r2","k":"stu","at":"2026-10-15T12:00","place":"운동장","stus":[{"sid":"10101","name":"가람","phone":""}],"blocks":[{"id":"b2","t":"p","x":"점심시간 다툼 중재"}],"media":[]}],
    "period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','todo');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul",accept_downloads=True);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  ok("기록" in T.inner_text(".navb[data-v=rec]"),"5.71: 학생 정보는 아래 메뉴 ‘기록’ 안")
  T.click(".navb[data-v=rec]");T.wait_for_timeout(300);T.locator("[data-sec=stu]:visible").click();T.wait_for_timeout(300)
  ok(T.is_visible("#c-stu") and T.locator("#c-stu .stur").count()==3 and "학생" in T.inner_text("#v-call h1"),"학생 탭: 우리 반 명단")
  ok("결석 1" in T.inner_text("#c-stu .stur:has-text('나래')") and "상담 11월 4일" in T.inner_text("#c-stu .stur:has-text('가람')"),"명단 표시: 결석 · 상담 예정")
  T.screenshot(path="shot/t162_list.png")
  T.click("#c-stu [data-sf=w]");T.wait_for_timeout(150);ok([x.strip().split("\n")[1] for x in T.evaluate("[...document.querySelectorAll('#c-stu .stur b')].map(b=>b.innerText)")] if False else T.locator("#c-stu .stur").count()==1 and "가온" in T.inner_text("#c-stu .stulist"),"⚠ 살펴볼 학생 (주의 메모)")
  T.click("#c-stu [data-sf='']");T.fill("#stuQ","다솜");T.wait_for_timeout(250);ok(T.locator("#c-stu .stur").count()==1 and "1학년 2반" in T.inner_text("#c-stu .stulist"),"찾기는 모든 학급에서")
  T.fill("#stuQ","");T.wait_for_timeout(200)
  T.click(".navb[data-v=call]");T.wait_for_timeout(200);ok(T.is_visible("#c-abs") and not T.is_visible("#c-stu"),"아래 메뉴 연락 → 결석 학생 연락 화면");T.click(".navb[data-v=rec]");T.wait_for_timeout(300);ok(T.is_visible("#c-stu"),"기록 → 다시 학생 정보")
  # 학생 화면
  T.click("#c-stu .stur:has-text('가람')");T.wait_for_timeout(300)
  tx=T.inner_text("#c-stu");ok("가람" in tx and "1학년 1반" in tx and "10101" in tx,"학생 화면 머리")
  tiles=T.evaluate("[...document.querySelectorAll('#c-stu .stutiles b')].map(b=>b.textContent)");ok(tiles==["50%","1","72","1"],"출석 · 결석 · 점수 평균 · 상담 "+str(tiles))
  kinds=T.evaluate("[...document.querySelectorAll('#c-stu .stui .tg')].map(b=>b.textContent)");ok(set(kinds)>={"출결","관찰","평가","상담","생활"},"날짜순 기록: 출결 · 관찰 · 평가 · 상담 · 생활 "+str(kinds))
  ok(T.evaluate("[...document.querySelectorAll('#c-stu .stui .d')].map(x=>x.textContent)")[0].startswith("10월 28일"),"최신 기록이 위")
  ok(T.locator("#c-stu a[href^='tel:01011110001']").count()==1 and T.locator("#c-stu a[href^='tel:01022220001']").count()==1,"학생 · 학부모 전화")
  T.screenshot(path="shot/t162_prof.png")
  T.click("#c-stu [data-tf=cns]");T.wait_for_timeout(150);ok(T.locator("#c-stu .stui").count()==1,"상담만 거르기")
  T.click("#c-stu .stui");T.wait_for_timeout(300);ok(T.is_visible("#sheet") and T.locator("#wrRef .wrref").count()==1,"상담 기록 열면 학생 자료 참고")
  T.click("#skNo");T.wait_for_timeout(200)
  # 5.83.4: 학생만 들어간 새 상담 기록을 아무것도 안 쓰고 닫으면 저장 안 함
  n0=len(root(T)["recs"]);T.click("#c-stu [data-tf='']");T.wait_for_timeout(100);T.click("#stuCns");T.wait_for_timeout(300);T.click("#skNo");T.wait_for_timeout(300)
  ok(len(root(T)["recs"])==n0 and T.locator("#c-stu .stui .tg:text('상담')").count()==1,"학생만 넣고 닫은 빈 상담 기록은 남지 않음")
  ok("상담 상담" not in T.inner_text("#c-stu"),"상담 제목이 ‘상담 상담’으로 겹치지 않음")
  # 새 상담 기록 + 자료 인용
  T.click("#c-stu [data-tf='']");T.wait_for_timeout(100);T.click("#stuCns");T.wait_for_timeout(300)
  ok(T.input_value(".wrstu >> nth=0 >> [data-sk=name]")=="가람" and T.get_attribute("#wrSub [data-sub=cns]","aria-pressed")=="true","＋ 상담 기록: 학생이 들어간 채로")
  refs=T.evaluate("[...document.querySelectorAll('#wrRef [data-ref]')].map(b=>b.textContent)");ok(any("결석 1" in x for x in refs) and any("적극 참여" in x for x in refs) and any("중간고사 72점" in x for x in refs) and any("지난 상담" in x for x in refs),"참고 자료: 출결 · 관찰 · 점수 · 지난 상담 "+str(refs)[:200])
  T.screenshot(path="shot/t162_cns.png")
  T.locator("#wrRef [data-ref]").first.click();T.wait_for_timeout(700)
  r=root(T)["recs"][-1];ok(any(x["t"]=="quote" and "출석" in x["x"] for x in r["blocks"]),"누르면 내용에 인용으로 들어감")
  T.click("#cnTp [data-v='학업']");T.click("#wrEd .wb.p .wbt");T.keyboard.type("성적 상담",delay=3);T.wait_for_timeout(600);T.click("#skNo");T.wait_for_timeout(300)
  ok(T.is_visible("#c-stu") and T.locator("#c-stu .stui .tg:text('상담')").count()==2,"학생 화면에 새 상담이 바로 보임")
  T.click("#stuBack");T.wait_for_timeout(200);ok(T.locator("#c-stu .stur").count()==3,"‹ 학생 → 명단")
  # 출석 격자 길게 누르기 → 학생 화면
  T.click(".navb[data-v=att]");T.wait_for_timeout(300);T.evaluate("document.querySelector('[data-key=\"m:att\"]').click()");T.wait_for_timeout(300)
  T.evaluate("document.querySelectorAll('#list .st')[1].scrollIntoView({block:'center'})");T.wait_for_timeout(2500);tile=T.locator("#list .st").nth(1);bb=tile.bounding_box();T.mouse.move(bb["x"]+10,bb["y"]+10);T.mouse.down();T.wait_for_timeout(800);T.mouse.up();T.wait_for_timeout(300)
  ok(T.is_visible("#c-stu") and "가온" in T.inner_text("#c-stu .stuhd"),"출석 격자에서 길게 누르면 그 학생 화면")
  ok(root(T)["list"][0]["data"]["sessions"][1]["p"].get("10102")==True,"길게 눌러도 출석은 그대로")
  ok(T.is_visible("#stuBackW") and "출석" in T.inner_text("#stuBackW"),"출석에서 온 학생 화면: 맨 위 ‘‹ 출석(으)로’ "+(T.inner_text("#stuBackW") if T.locator("#stuBackW").count() else ""))
  T.click("#stuBackW");T.wait_for_timeout(400);ok(T.is_visible("#list .st") and not T.is_visible("#c-stu"),"‹ 출석(으)로 → 보던 출석부로 돌아감")
  # 상담 기록 뺀 백업
  T.click("#topBtns .navb[data-v=set]");T.wait_for_timeout(200);T.evaluate("document.getElementById('d-bk').open=true");T.uncheck("#bkCns");T.evaluate("()=>{navigator.canShare=undefined}")
  with T.expect_download() as dl:T.evaluate("document.getElementById('backupFile').click()")
  bk=json.loads(open(dl.value.path(),encoding="utf-8").read())
  ok(bk.get("noCns") and not any(x.get("sub")=="cns" for x in bk["recs"]) and any(x["id"]=="r2" for x in bk["recs"]),"상담 기록 뺀 백업 (학교생활 기록은 들어감)")
  T.evaluate("t=>{const f=new File([t],'b.json',{type:'application/json'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('restoreFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",json.dumps(bk,ensure_ascii=False));T.wait_for_timeout(700)
  ok("상담 기록을 뺀 백업" in T.inner_text("#sheetBox"),"불러오기 안내");T.click("#rsReplace");T.click("#rsReplace");T.wait_for_timeout(500)
  ok(sum(1 for x in root(T)["recs"] if x.get("sub")=="cns")==2,"완전히 바꾸기 해도 이 기기 상담 기록 유지")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
