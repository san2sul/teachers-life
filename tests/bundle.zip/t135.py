src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
R1=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"],["10105","마루"]]
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  ses=[{"id":"s1","date":"2026-10-22","time":"09:00","label":"1교시","src":"t1:3:1","p":{"10101":True,"10102":True,"10103":True,"10104":True}}]
  tasks=[{"id":"k1","k":"perf","n":"실험 발표","due":"2026-10-22","cls":["c1"],"miss":{"c1":{"10102":"m","10103":"m","10104":"m"}},"at":"2026-10-20T00:00:00Z"},
         {"id":"k2","k":"hw","n":"학습지","due":"2026-10-20","cls":["c1"],"miss":{"c1":{"10102":"m"}},"at":"2026-10-19T00:00:00Z"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":R1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}}],"staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":tasks,"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-22T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def task(T,i):return [x for x in root(T)["tasks"] if x["id"]==i][0]
def why(T,i):return task(T,i).get("why",{}).get("c1",{})
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX)
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','task');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  P0=json.dumps(root(T)["list"][0]["data"]["sessions"],sort_keys=True)
  ok(task(T,"k1")["miss"]["c1"].get("10105")=="m","(결석 학생 마루 자동 반영)")
  T.locator("#ttTasks .tkrow",has_text="실험 발표").click();T.wait_for_timeout(250);T.click("#sheetBox [data-hc]");T.wait_for_timeout(250)
  n=T.locator("#tkOn .tkwhy").count();ok(n==4,"미참여 학생마다 유형 단추: %d"%n)
  ok(T.evaluate("[...document.querySelector('#tkOn .tkwhy').querySelectorAll('button')].map(b=>b.textContent)")==["백지제출","자발적 미참여","장기 미인정 결석"],"세 가지 유형")
  T.click("#tkOn [data-ws='10102'][data-why='blank']");T.wait_for_timeout(250)
  ok(why(T,"k1")=={"10102":"blank"},"나래 → 백지제출")
  ok("백지" in T.inner_text("#sheetBox .tkgrid [data-tg='10102']"),"격자 칸에 ‘백지’")
  T.click("#tkOn [data-ws='10102'][data-why='vol']");T.wait_for_timeout(250);ok(why(T,"k1")=={"10102":"vol"},"다른 유형으로 바꾸기")
  T.click("#tkOn [data-ws='10102'][data-why='vol']");T.wait_for_timeout(250);ok(why(T,"k1")=={},"같은 유형 다시 누르면 지움")
  # bulk
  T.check("#tkOn [data-on='10103']");T.check("#tkOn [data-on='10105']");T.click("#sheetBox [data-wb='long']");T.wait_for_timeout(300)
  ok(why(T,"k1")=={"10103":"long","10105":"long"},"선택한 학생 한꺼번에 ‘장기 미인정 결석’")
  ok(task(T,"k1")["as"]["c1"].get("10105")=="x","자동(결석) 학생에게 유형을 정하면 선생님 확인으로 고정")
  ok("장기 미인정 결석 2" in T.inner_text("#sheetBox .tkwsum"),"유형별 인원 요약")
  T.screenshot(path="shot/t135_sheet.png",full_page=False)
  T.locator("#sheetBox .tkwsum").scroll_into_view_if_needed();T.screenshot(path="shot/t135_sheet2.png")
  T.click("#utoast button");T.wait_for_timeout(300);ok(why(T,"k1")=={},"되돌리기")
  T.click("#tkOn [data-ws='10104'][data-why='blank']");T.wait_for_timeout(250)
  # copy text contains type
  T.evaluate("window.__cp=null;navigator.clipboard.writeText=t=>{window.__cp=t;return Promise.resolve()}")
  T.click("#tkCp");T.wait_for_timeout(200);cp=T.evaluate("window.__cp")or""
  ok("10104 라온 (백지제출)" in cp,"명단 복사에 유형: "+cp.replace("\n"," / "))
  # remove student → why cleared
  T.click("#sheetBox .tkgrid [data-tg='10104']");T.wait_for_timeout(250);ok("10104" not in why(T,"k1"),"학생을 빼면 유형도 지움")
  # hw labels
  T.evaluate("document.getElementById('sheet').hidden=true");T.locator("#ttTasks .tkrow",has_text="학습지").click();T.wait_for_timeout(250);T.click("#sheetBox [data-hc]");T.wait_for_timeout(250)
  ok(T.locator("#tkOn .tkwhy").count()==1,"과제 미제출에도 유형")
  T.click("#tkOn [data-ws='10102'][data-why='vol']");T.wait_for_timeout(200);ok(why(T,"k2")=={"10102":"vol"},"과제 유형 저장")
  ok(json.dumps(root(T)["list"][0]["data"]["sessions"],sort_keys=True)==P0,"출석 체크는 그대로")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
