src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def state():
  ros=[["10101","가람"],["10102","가온"],["10103","나래"]]
  cells={"1-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-27","time":"10:00","label":"2교시 물리학","p":{"10101":True},"src":"t1:1:2","done":{"10102":1}},
       {"id":"s2","date":"2026-10-27","time":"10:05","label":"잘못 만든 체크","p":{}}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ros,"phones":{"10102":"010-1111-0002","10103":"010-1111-0003"},"emails":{},"teachers":[],"msg":"m","sessions":ses}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-27T16:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def d1(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))["list"][0]["data"]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1000)
  ok(T.locator("#tabs .tab:not(.add)").count()==2,"출석 체크 두 개")
  ok(T.get_attribute("#tabs .tab:not(.add) >> nth=1","aria-selected")=="true","방금 만든(마지막) 체크가 골라져 있음")
  T.locator("#tabs .tab:not(.add)").nth(1).click();T.wait_for_timeout(300)
  ok(T.locator("#seDate").count()==1 and "잘못 만든 체크" in T.inner_text("#sheetBox"),"고른 출석 체크를 한 번 더 누르면 고치기 창")
  T.click("#skNo");T.wait_for_timeout(200)
  # 고치기: 다른 날짜로 옮기기
  T.click("#sEdit");T.wait_for_timeout(200);T.fill("#seDate","2026-10-26");T.fill("#seTime","11:00");T.fill("#seLabel","3교시 물리학");T.click("#seOk");T.wait_for_timeout(300)
  s2=[x for x in d1(T)["sessions"] if x["id"]=="s2"][0];ok(s2["date"]=="2026-10-26" and s2["time"]=="11:00" and s2["label"]=="3교시 물리학","날짜 · 시간 · 이름 고치기 저장")
  ok("10월 26일" in T.inner_text("#dayHead"),"고친 날짜로 화면이 따라감")
  # 시간표 연결된 체크를 다른 요일로 → 연결 풀림
  T.fill("#date","2026-10-27");T.dispatch_event("#date","change");T.wait_for_timeout(300)
  T.click("#sEdit");T.wait_for_timeout(200);ok(T.locator("#seSrc").count()==1,"시간표 연결 안내");T.fill("#seDate","2026-10-29");T.click("#seOk");T.wait_for_timeout(300)
  s1=[x for x in d1(T)["sessions"] if x["id"]=="s1"][0];ok(s1["date"]=="2026-10-29" and "src" not in s1 and s1["p"]=={"10101":True} and s1.get("done",{}).get("10102"),"다른 요일로 옮기면 시간표 연결만 풀리고 출석 · 연락 완료는 그대로")
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);ok("/" not in T.inner_text("table.ttg .tc[data-d='1'][data-p='2']"),"시간표 칸(화 2교시)에서 출석 표시가 빠짐")
  T.click(".navb[data-v=att]");T.wait_for_timeout(300)
  # 삭제: 확인 절차
  T.fill("#date","2026-10-29");T.dispatch_event("#date","change");T.wait_for_timeout(300)
  T.click("#sDel");T.wait_for_timeout(200)
  ok("출석 1명 · 결석 2명" in T.inner_text("#sheetBox") and "연락 완료" in T.inner_text("#sheetBox"),"삭제 전 지워질 내용 보여 줌")
  ok(T.is_disabled("#sdGo"),"확인 칸을 체크하기 전에는 삭제 단추가 안 눌림")
  T.screenshot(path="shot/t156_del.png")
  T.check("#sdOk");T.click("#sdGo");T.wait_for_timeout(300)
  d=d1(T);ok(not any(x["id"]=="s1" for x in d["sessions"]) and d.get("sesBin",[{}])[0]["s"]["id"]=="s1","삭제 → 삭제한 출석 체크로 보관")
  ok(T.locator("#sesBinRow").is_visible() and "1개" in T.inner_text("#sesBinBtn"),"‘삭제한 출석 체크 1개’ 단추")
  T.click(".navb[data-v=call]");T.wait_for_timeout(300);ok(T.locator("#abList .crow").count()==0,"연락 화면에도 반영(지운 체크의 결석 학생 없음)")
  T.click(".navb[data-v=att]");T.wait_for_timeout(300)
  T.click("#sesBinBtn");T.wait_for_timeout(200);T.click("[data-rs='0']");T.wait_for_timeout(300)
  d=d1(T);ok(any(x["id"]=="s1" and x["p"]=={"10101":True} for x in d["sessions"]) and not d.get("sesBin"),"되살리기: 출석 내용 그대로")
  # 잠긴 체크는 삭제 불가
  T.click("#lockBtn");T.wait_for_timeout(200);ok(T.is_disabled("#sDel"),"잠긴 출석 체크는 삭제 단추가 꺼짐")
  T.click("#sEdit");T.wait_for_timeout(200);ok(T.is_disabled("#seOk") and T.is_disabled("#seDel"),"잠긴 체크는 고치기 · 삭제 막힘");T.click("#skNo")
  # 되돌리기 알림
  T.click("#lockBtn");T.wait_for_timeout(200);T.click("#lockBtn") if T.locator("#sheetBox button:has-text('잠금 해제')").count()==0 else None
  T.evaluate("(()=>{const b=[...document.querySelectorAll('#sheetBox button')].find(x=>x.textContent.trim()==='잠금 해제');b&&b.click()})()");T.wait_for_timeout(300)
  T.click("#sDel");T.wait_for_timeout(200)
  if T.locator("#sdOk").count():
    T.check("#sdOk");T.click("#sdGo");T.wait_for_timeout(300);T.click("#utoast button");T.wait_for_timeout(300)
    ok(any(x["id"]=="s1" for x in d1(T)["sessions"]),"삭제 직후 ‘되돌리기’로 바로 복구")
  else:ok(False,"잠금 해제 뒤 삭제 창")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
