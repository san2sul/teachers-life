src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy,re
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def M(T,key="school:master"):return T.evaluate("k=>new Promise(r=>{const q=indexedDB.open('teachers-life-media');q.onsuccess=()=>{const g=q.result.transaction('m').objectStore('m').get('kv:'+k);g.onsuccess=()=>r(g.result?JSON.parse(g.result):null)}})",key)
def st(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
EMPTY={"active":"c0","list":[{"id":"c0","data":{"v":3,"cls":"","roster":[],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
ADM=copy.deepcopy(EMPTY);#ADM["tt"]["acal"]=[{"g":"x1","from":"2026-11-04","to":"2026-11-04","title":"체육대회","kind":"event"},{"g":"x2","from":"2026-11-19","to":"2026-11-19","title":"수능 휴업","kind":"cancel"},{"g":"x3","from":"2025-11-19","to":"2025-11-19","title":"작년 행사","kind":"event"}]
def dev(b,state,touch=False):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,has_touch=touch);c.route("**/*",handler);T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)))
  T.goto("https://tl.test/index.html");T.evaluate("s=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1')}",json.dumps(state));T.reload();T.wait_for_timeout(700);return T
def admin_setup(T,school="물리고등학교"):
  T.click(".navb[data-v=set]");T.evaluate("()=>{document.getElementById('d-school').open=true}");T.click("#schOpen");T.check("#schAgree");T.click("#schOnBtn");T.wait_for_timeout(400)
  T.set_input_files("#schFile","schf/v1.xlsx");T.wait_for_timeout(1200);T.click("#schGo");T.wait_for_timeout(400)
  T.fill("#schName",school);T.evaluate("document.getElementById('schName').dispatchEvent(new Event('change'))");T.wait_for_timeout(300)
def setpage(T):T.evaluate("()=>{document.getElementById('sheet').hidden=true;document.querySelector('.navb[data-v=set]').click();document.getElementById('d-pack').open=true}");T.wait_for_timeout(150)
def openfile(T,text):
  setpage(T);T.evaluate("t=>{const f=new File([t],'pack.json',{type:'application/json'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('packFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",text);T.wait_for_timeout(900)
def by(s,n):return [c for c in s["list"] if c["data"].get("cls")==n]
def dl(A):
  with A.expect_download() as d:A.click("#packMake")
  A.wait_for_timeout(600);return open(d.value.path(),encoding="utf-8").read()
def recv(B,pack,name,code,first=False):
  openfile(B,pack)
  if first:B.click("#pkOk");B.wait_for_timeout(200)
  if B.locator("#pmA").count():B.click("#pmA");B.wait_for_timeout(200)
  B.click(f"#pkList [data-t] >> text={name}");B.fill("#pkCode",code);B.click("#pkGo");B.wait_for_timeout(900)
def roster(s,n):return {r[0]:r[1] for r in by(s,n)[0]["data"]["roster"]}
def tell(B,name=None):
  setpage(B);B.click("#pkTell");B.wait_for_timeout(200)
  if name:B.fill("#rnName",name)
  t=B.inner_text("#rnMsg");B.click("#skNo");return t
def logtab(A):A.click("[data-st=log]");A.wait_for_timeout(300)
def fpbox(A):A.click("[data-st=asg]");A.wait_for_timeout(500);return A.inner_text("#fpBox")
def mkho(A):
  A.click("#hoMake");A.wait_for_timeout(1200);code=A.inner_text("#hoCode")
  with A.expect_download() as d:A.click("#hoSave")
  A.wait_for_timeout(300);path=d.value.path();return code,path
def takeho(D,path,code,mode="keep"):
  D.click(".navb[data-v=set]");D.evaluate("()=>{document.getElementById('d-school').open=true}");D.click("#schOpen");D.wait_for_timeout(200)
  D.set_input_files("#hoIn0",str(path));D.wait_for_timeout(400)
  D.fill("#hoIn",code);D.click("#hoGo");D.wait_for_timeout(1200)
  if mode=="new":D.check("[name=hoK][value=new]")
  D.click("#hoApply");D.wait_for_timeout(1200)
with sync_playwright() as p:
  b=p.chromium.launch()
  A=dev(b,EMPTY);admin_setup(A);A.click("[data-st=asg]");A.wait_for_timeout(200);A.set_input_files("#asgFile","schf/asg_list.xlsx");A.wait_for_timeout(1000);A.click("#asgGo");A.wait_for_timeout(400)
  A.check("#opMP");A.wait_for_timeout(100);fpA=A.inner_text("#fpBox")
  pack1=dl(A);m=M(A);codes={t["name"]:t["code"] for t in m["staff"] if t.get("code")};pc=m["pickCode"]
  ok(len(m["packs"])==1 and len(m["packs"][0]["t"])==3 and m["packs"][0]["pick"]["n"]>0,"distribution record kept: who and what")
  A.reload();A.wait_for_timeout(700);ok(M(A).get("pickCode")==pc,"school code survives reload (fixed: was lost before)")
  # teachers receive + tell
  B=dev(b,EMPTY,touch=True);recv(B,pack1,"김물리",codes["김물리"],first=True);B.click("#pkApply");B.wait_for_timeout(600)
  mB=tell(B);print("  msg:",mB);ok(re.search(r"1번째 학교 묶음 받음 · 김물리 · 확인 [0-9A-Z]{4}$",mB),"teacher: receipt message")
  C=dev(b,EMPTY);openfile(C,pack1);C.click("#pkOk");C.wait_for_timeout(200);C.click("#pmP");C.wait_for_timeout(200)
  C.click("#pcList [data-k='2-3']");C.fill("#pcCode",pc);C.click("#pcGo");C.wait_for_timeout(900);C.click("#pkApply");C.wait_for_timeout(600)
  mC=tell(C,"최영어");ok("최영어" in mC,"pick-mode receipt with typed name")
  fake=mB.replace("김물리","이수학")
  # admin pastes
  A.click(".navb[data-v=set]");A.evaluate("()=>{document.getElementById('d-school').open=true}");A.click("#schOpen");A.wait_for_timeout(500);logtab(A)
  A.fill("#rpTx","잘 받았어요!\n"+mB+"\n"+mC+"\n"+fake);A.click("#rpGo");A.wait_for_timeout(500)
  g=M(A)["packs"][0]["got"];print("  got:",g)
  ok(g["김물리"]["ok"] and g["최영어"]["ok"] and g["최영어"]["via"]=="pick" and not g["이수학"]["ok"],"receipts verified; copied code with another name is rejected")
  tx=A.inner_text("#schList");ok("받음 1" in tx and "선택" in tx and "확인 안 됨 1" in tx,"log shows counts")
  ok(A.locator("[data-nag]").count()==1 and "2명" in A.inner_text("[data-nag]"),"nudge button for teachers who haven't received")
  with A.expect_download() as d:A.click("#lgXl")
  A.wait_for_timeout(300);ok(d.value.suggested_filename.endswith(".xlsx"),"log Excel export")
  # handover (keep)
  code,path=mkho(A);ok(re.match(r"^[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}$",code),"handover code: "+code)
  raw=open(path,encoding="utf-8").read();ok("김물리" not in raw and "010-" not in raw and "priv" not in raw and pc not in raw,"handover file reveals nothing without the code")
  D=dev(b,EMPTY)
  D.click(".navb[data-v=set]");D.evaluate("()=>{document.getElementById('d-school').open=true}");D.click("#schOpen");D.wait_for_timeout(200);D.set_input_files("#hoIn0",str(path));D.wait_for_timeout(400)
  D.fill("#hoIn","AAAA-BBBB-CCCC");D.click("#hoGo");D.wait_for_timeout(1000);ok("맞지 않습니다" in D.inner_text("#hoMsg"),"wrong handover code rejected");D.click("#skNo")
  takeho(D,path,code);mD=M(D)
  ok(D.evaluate("document.documentElement.dataset.view")=="school" and len(mD["students"])==len(m["students"]) and mD.get("pickCode")==pc and len(mD["packs"])==1,"new 담당자: master, school code, records all moved")
  ok(fpbox(D)==fpA,"same 확인 코드 kept")
  ok("바뀐 학생 없음" in D.inner_text("#distBox"),"last-distribution memory moved too")
  pack3=dl(D)
  openfile(B,pack3);sh=B.inner_text("#sheetBox");ok("개인 코드로 받기" in sh and "다릅니다" not in sh,"teacher: pack from new 담당자 (same code) opens normally")
  B.click("#skNo")
  # old device wipes
  A.click("#hoWipe");A.click("#hoWipe");A.wait_for_timeout(600)
  ok(M(A) is None and M(A,"school:key") is None and A.evaluate("localStorage.getItem('att-app-school')") is None,"old device: master and key erased")
  # handover with new code
  D.click("[data-st=cls]");D.wait_for_timeout(200);code2,path2=mkho(D);D.click("#skNo")
  E=dev(b,EMPTY);takeho(E,path2,code2,"new");fpE=fpbox(E);ok(fpE!=fpA,"new 확인 코드 made: "+fpE)
  pack4=dl(E);P4=json.loads(pack4);ok("handover" in P4,"pack carries previous 담당자 endorsement")
  openfile(B,pack4);sh=B.inner_text("#sheetBox");print("  B sees:",sh[:160].replace("\n"," | "))
  ok("담당자가 바뀌었습니다" in sh and fpE in sh and "다른 사람이 만든" not in sh,"teacher: friendly notice (endorsed by previous 담당자)")
  B.click("#pkOk");B.wait_for_timeout(300);ok("개인 코드로 받기" in B.inner_text("#sheetBox"),"continues to receive")
  ok(json.loads(B.evaluate("localStorage.getItem('att-app-schtrust')"))["물리고등학교"]["fp"]==fpE,"trust moved to new code")
  # forged endorsement: different admin copies the handover block
  G=dev(b,EMPTY);admin_setup(G);G.click("[data-st=asg]");G.set_input_files("#asgFile","schf/asg_list.xlsx");G.wait_for_timeout(900);G.click("#asgGo");G.wait_for_timeout(300)
  forged=json.loads(dl(G));B.evaluate("()=>{const o=JSON.parse(localStorage.getItem('att-app-schtrust'));o['물리고등학교'].fp=%s;localStorage.setItem('att-app-schtrust',JSON.stringify(o))}"%json.dumps(fpA))
  forged["handover"]=P4["handover"]
  openfile(B,json.dumps(forged,ensure_ascii=False));ok("열 수 없는" in B.inner_text("#sheetBox"),"copied endorsement breaks signature → refused")
  B.evaluate("()=>{const o=JSON.parse(localStorage.getItem('att-app-schtrust'));o['물리고등학교'].fp='ZZZZ-ZZZZ';localStorage.setItem('att-app-schtrust',JSON.stringify(o))}")
  openfile(B,pack4);ok("확인 코드가 다릅니다" in B.inner_text("#sheetBox"),"endorsement only counts if it comes from the 담당자 this teacher trusted")
  b.close()
print("fails",F);print(errs)
