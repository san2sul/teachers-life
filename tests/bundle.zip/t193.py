src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
# 5.92 흐름 꼬임 · 수업 화면: 출석은 늘 오늘 · 돌아가는 단추 · 학생 창 · 학급 안 바뀜 · 출석부 수업 흐름 한 줄 · 일하는 중 인사 미루기
r1=[["10101","가람"],["10102","가온"],["10103","나래"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s0","date":"2026-10-26","time":"10:00","label":"2교시 물리학","p":{"10101":False,"10102":True},"src":"t1:0:2"},{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s2","date":"2026-10-28","time":"09:00","label":"1교시 물리학","p":{"10201":True},"src":"t1:2:1"}]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "flows":[{"id":"f1","n":"실험 수업","steps":[{"id":"x1","n":"도입","m":5,"al":"vib"},{"id":"x2","n":"실험","m":35,"al":"vib"},{"id":"x3","n":"정리","m":10,"al":"vib"}]}],"flowSub":{"물리학":"f1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘","ch":[{"id":"a1","t":"속력"}]}],"pg":{}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:true,noon:false,pmAt:'11:00'}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},has_touch=True,service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1500)
  V=lambda:T.evaluate("document.documentElement.dataset.view")
  def att():T.evaluate("document.querySelector('[data-key=\"m:att\"]').click()");T.wait_for_timeout(400)
  def lp(i):
    T.evaluate("i=>document.querySelectorAll('#list .st')[i].scrollIntoView({block:'center'})",i);T.wait_for_timeout(300)
    bb=T.locator("#list .st").nth(i).bounding_box();T.mouse.move(bb["x"]+8,bb["y"]+8);T.mouse.down();T.wait_for_timeout(800);T.mouse.up();T.wait_for_timeout(400)
  T.click(".navb[data-v=att]");T.wait_for_timeout(400);att()
  # 5.92.1 수업 모드: 날짜 카드 접힘 · 진도 줄은 학생 칸 아래 · 첫 화면에 학생 칸
  ok(T.evaluate("document.getElementById('v-att').classList.contains('lsnow')") and not T.is_visible("#dayCard") and T.is_visible("#lsDate"),"수업 모드: 날짜 카드는 접고 📅 다른 날짜 단추")
  ok(T.evaluate("(()=>{const l=document.getElementById('list'),p=document.getElementById('pnBar');return !!(l&&p&&(l.compareDocumentPosition(p)&4))})()"),"수업 모드: 진도 줄은 학생 칸 아래")
  ok(T.evaluate("document.querySelector('#list .st').getBoundingClientRect().top")<520,"수업 모드: 첫 학생 칸이 화면 위쪽(%d px)"%T.evaluate("document.querySelector('#list .st').getBoundingClientRect().top"))
  T.click("#lsDate");T.wait_for_timeout(300);ok(T.is_visible("#dayCard"),"📅 → 날짜 카드 펼침");T.click("#lsDate");T.wait_for_timeout(300);ok(not T.is_visible("#dayCard"),"📅 다시 → 접힘")
  if T.locator("#ghint:visible").count():T.mouse.click(200,400);T.wait_for_timeout(200);ok(not T.is_visible("#ghint"),"첫 안내는 아무 데나 누르면 닫힘")
  # A: 지금 수업의 출석부 맨 위에 수업 흐름 한 줄
  ok(T.is_visible("#flLine") and "▶ 시작" in T.inner_text("#flLine") and T.locator("#flLine").bounding_box()["height"]<=56,"A: 출석부 맨 위에 수업 흐름 한 줄(▶ 시작) "+(T.inner_text("#flLine").replace("\n"," ") if T.locator("#flLine").count() else ""))
  ok(T.locator("#flPill:visible").count()==0,"A: 떠 있는 작은 표시와 겹치지 않음")
  T.screenshot(path="shot/t193_att_wait.png")
  T.click("#flLine [data-fll=start]");T.wait_for_timeout(600)
  ln=T.inner_text("#flLine").replace("\n"," ");ok("도입" in ln and T.locator("#flLine [data-fll=pause]").count()==1 and T.locator("#flLine [data-fll=stop]").count()==1,"A: 출석부에서 바로 시작 → 단계 · 남은 시간 · ⏸ · ■ "+ln)
  ok(T.is_hidden("#sheet"),"A: 시작해도 창이 뜨지 않음(칸을 가리지 않음)")
  T.click("#flLine [data-fll=pause]");T.wait_for_timeout(400);ok(T.locator("#flLine [data-fll=resume]").count()==1,"A: ⏸ → ▶ 이어서")
  T.click("#flLine [data-fll=resume]");T.wait_for_timeout(400)
  T.screenshot(path="shot/t193_att_run.png")
  T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(500)
  ok(T.is_visible("#flLine") and "도입" in T.inner_text("#flLine"),"A: 수업 관찰에서도 같은 한 줄")
  y1=T.locator("#flLine").bounding_box();ok(y1["height"]<=56,"A: 관찰 화면에서도 얇은 한 줄(높이 %d)"%y1["height"])
  T.screenshot(path="shot/t193_obs_run.png")
  T.click("#flLine [data-fls]");T.wait_for_timeout(400);ok(T.is_visible("#sheet") and "수업 흐름" in T.inner_text("#sheetBox"),"A: 줄을 누르면 그때만 자세한 창")
  T.evaluate("document.getElementById('sheet').hidden=true");att()
  # H: 수업 중 · 일하는 중에는 저녁 인사가 뜨지 않음
  ok("cheer" not in T.inner_text("#sheetBox") and T.locator("#sheetBox .cheer").count()==0,"H: 수업 중(출석부)에는 저녁 인사를 띄우지 않음")
  # B: 지난 출석부로 갔다가 아래 메뉴 ‘출석’ → 오늘
  T.click("#lsDate") if T.is_visible("#lsDate") else None;T.wait_for_timeout(300);T.click("#dPrev");T.wait_for_timeout(300);T.click("#dPrev");T.wait_for_timeout(300)
  past=T.evaluate("selDateTxt=document.getElementById('dToday').hidden");ok(not past,"B: 지난 날짜를 보는 중엔 ‘오늘’ 단추")
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click(".navb[data-v=att]");T.wait_for_timeout(500)
  ok(T.evaluate("document.getElementById('dToday').hidden"),"B: 다른 메뉴에 갔다가 ‘출석’을 누르면 오늘로")
  # F: 다른 반 학생을 잠깐 보고 닫으면 보던 반 그대로
  a0=root(T)["active"]
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  T.click(".navb[data-v=att]");T.wait_for_timeout(400);att()
  ok(root(T)["active"]=="c1","F: 지금 수업(1반)의 출석부")
  # D: 학생 창에서 기록(지난 출결)으로 갔다가 돌아오기
  lp(0);ok(T.is_visible("#stuOv"),"D: 학생 창")
  it=T.locator("#stuOv [data-ti]").first
  if it.count():
    it.click();T.wait_for_timeout(500)
    ok(not T.is_visible("#stuOv") and T.is_visible("#retBar") and "학생 창" in T.inner_text("#retBar"),"D: 기록으로 넘어가면 맨 위에 ‘‹ 가람 학생 창으로’ "+(T.inner_text("#retBar") if T.locator("#retBar").count() else ""))
    T.click("#retBar");T.wait_for_timeout(500)
    ok(T.is_visible("#stuOv") and "가람" in T.inner_text("#stuOv .stuhd") and T.evaluate("document.getElementById('dToday').hidden"),"D: 누르면 보던 출석부(오늘) 위에 학생 창이 다시")
    T.click("#stuOvX");T.wait_for_timeout(300)
  else:ok(False,"D: 학생 창에 기록 줄이 없음");T.click("#stuOvX")
  # C: 연락에서 번호 없는 학생 → 설정 → ‹ 연락(으)로
  T.click(".navb[data-v=call]");T.wait_for_timeout(400)
  T.evaluate("document.querySelectorAll('#sheet').forEach(s=>s.hidden=true)")
  if T.locator(".crow [data-a=tel]:visible").count():T.locator(".crow [data-a=tel]:visible").first.click();T.wait_for_timeout(500)
  if V()=="set":
    ok(T.is_visible("#retBar") and "연락" in T.inner_text("#retBar"),"C: 번호를 넣으러 설정에 오면 맨 위 ‘‹ 연락(으)로’")
    T.evaluate("document.getElementById('sheet').hidden=true");T.click("#retBar");T.wait_for_timeout(400);ok(V()=="call","C: 누르면 연락으로")
  else:ok(False,"C: 연락에서 번호 없는 학생 → 설정으로 가지 않음(뷰 %s)"%V())
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#ttPnBtn");T.wait_for_timeout(300)
  ok(T.locator("#ttProg [data-lsgo]").count()==1,"진도 현황의 ⚙ 수업 설정")
  if T.locator("#ttProg [data-lsgo]").count():
    T.click("#ttProg [data-lsgo]");T.wait_for_timeout(400);ok(V()=="set" and T.is_visible("#retBar") and "시간표" in T.inner_text("#retBar"),"C: 진도 현황 → ⚙ 수업 설정 → 맨 위 ‘‹ 시간표(으)로’")
    T.click("#retBar");T.wait_for_timeout(400);ok(V()=="tt" and T.is_visible("#ttProg"),"C: 누르면 진도 현황으로")
  # F2: 오늘 화면에서 2반 학생 창을 열었다 닫아도 보던 반(1반) 그대로
  T.click(".navb[data-v=att]");T.wait_for_timeout(400);att()
  T.evaluate("()=>{}")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
