src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ROS=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"]]
def state(tt_extra):
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":"과학실"} for w in range(5)}
  cells["2-3"]={"subject":"통합과학","clsId":"c1","clsName":"","room":""}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]};t.update(tt_extra)
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ROS,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s1","date":"2026-10-21","time":"","label":"","p":{"10101":True}}]}}],
    "staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('%s').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
def dev(b,st,when,cheer=None,wx=None):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,timezone_id="Asia/Seoul");c.route("**/*",handler)
  if wx=="fail":c.route("https://api.open-meteo.com/**",lambda r:r.abort())
  elif wx:c.route("https://api.open-meteo.com/**",lambda r:(calls.append(r.request.url),r.fulfill(json=wx))[1])
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX%when);T.add_init_script(SPY)
  T.goto("https://tl.test/index.html");T.evaluate("([s,ch])=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-cheer',JSON.stringify(ch||{am:false,pm:false}));localStorage.setItem('att-app-clsal','5')}",[json.dumps(st),cheer])
  T.reload();T.wait_for_timeout(900);return T
SPY="window.__plays=[];window.__vib=[];const _p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){window.__plays.push({src:this.src,vol:this.volume});return Promise.resolve()};try{Object.defineProperty(navigator,'vibrate',{value:p=>{window.__vib.push(p);return true},configurable:true})}catch(e){}"
calls=[]
WX={"current":{"temperature_2m":-2.6,"apparent_temperature":-6,"weather_code":0},"daily":{"temperature_2m_max":[4.2],"temperature_2m_min":[-5.1]}}
def tk(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')")).get("tasks",[])
with sync_playwright() as p:
  b=p.chromium.launch()
  ST=state({"from":"2026-08-24","to":"2026-12-31"})
  ST["list"][0]["data"]["roster"]=[[f"101{i:02d}",n] for i,n in enumerate(["가람","나래","다솜","라온","마루","바다"],1)]
  ST["list"][0]["data"]["phones"]={"10101":"010-1111-2222"}
  E=dev(b,ST,"2026-10-22T10:30:00+09:00")
  E.click(".navb[data-v=att]");E.click("[data-m=obs]");E.wait_for_timeout(200)
  ok(E.is_visible("#tkCard") and "평가 · 과제 점검" in E.inner_text("#tkCard"),"card in 관찰 기록")
  E.click("#tkNew");E.wait_for_timeout(150);E.click("#tkK [data-k=perf]");ok("평가명" in E.inner_text("#sheetBox"),"name label follows kind")
  E.fill("#tkN","1차 실험 보고서 발표");E.click("#tkOk");E.wait_for_timeout(200)
  t=tk(E);ok(len(t)==1 and t[0]["k"]=="perf" and t[0]["n"]=="1차 실험 보고서 발표" and t[0]["due"]=="2026-10-22" and t[0]["cls"]==["c1"],"수행평가 created with name and date (this class only)")
  ok(E.locator(".tkgrid [data-tg]").count()==6,"check sheet opened right away")
  E.click("[data-tg='10101']");E.click("[data-tg='10102']");E.wait_for_timeout(150)
  ok(E.locator("#tkOn [data-on]").count()==2 and "미참여" in E.inner_text(".tkgrid [data-tg='10101']"),"tap to mark 미참여")
  E.click("[data-tg='10102']");E.wait_for_timeout(100);ok(E.locator("#tkOn [data-on]").count()==1,"tap again to unmark")
  E.check("#tkOff [data-off='10103']");E.check("#tkOff [data-off='10104']");E.click("#tkAdd");E.wait_for_timeout(150)
  ok(E.locator("#tkOn [data-on]").count()==3,"bulk add selected")
  E.check("#tkOn [data-on='10104']");E.click("#tkLateSel");E.wait_for_timeout(150);ok(tk(E)[0]["miss"]["c1"]["10104"]=="l","늦게 냄 표시")
  E.screenshot(path="s541_task.png")
  E.click("#tkAllOn");E.click("#tkDelSel");E.wait_for_timeout(150);ok(E.locator("#tkOn [data-on]").count()==0,"bulk remove all");E.click("#utoast button");E.wait_for_timeout(200)
  ok(E.locator("#tkOn [data-on]").count()==3,"undo bulk remove");E.click("#skNo")
  E.click("#tkNew");E.wait_for_timeout(100);E.click("#tkK [data-k=hw]");E.fill("#tkN","3단원 학습지");E.fill("#tkD","2026-10-24");E.click("#tkOk");E.wait_for_timeout(150);E.click("[data-tg='10101']");E.click("#skNo")
  card=E.inner_text("#tkCard");print("  card:",card.replace("\n"," | "));ok("3단원 학습지" in card and "미제출 1명" in card and "미참여 2명" in card and "늦게 1" in card,"card summarises each task")
  E.click("#tkStu");E.wait_for_timeout(150);sh=E.inner_text("#sheetBox");ok("가람" in sh and "안 낸 것 2" in sh and "3단원 학습지" in sh and "늦게 냄" in sh,"학생별 모아 보기")
  E.screenshot(path="s541_stu.png");E.click("#skNo")
  E.click("#tkCard .tkrow:has-text('3단원')");E.wait_for_timeout(100);E.click("#tkEditB");E.fill("#tkN","3단원 학습지(수정)");E.click("#tkOk");E.wait_for_timeout(100);ok(any(x["n"]=="3단원 학습지(수정)" for x in tk(E)),"rename");E.click("#skNo")
  E.reload();E.wait_for_timeout(800);ok(len(tk(E))==2,"persists after reload")
  E.click(".navb[data-v=set]");E.evaluate("()=>{document.querySelectorAll('details.card').forEach(d=>{if(d.querySelector('#stuList'))d.open=true})}");E.click("#stuList .prow:has-text('가람')");E.wait_for_timeout(150);E.fill("#esId","10199");E.click("#esOk");E.wait_for_timeout(150)
  ok(all("10199" in x["miss"]["c1"] and "10101" not in x["miss"]["c1"] for x in tk(E)),"학번 change carries task checks")
  E.click(".navb[data-v=att]");E.click("[data-m=obs]");E.click("#tkCard .tkrow:has-text('3단원')");E.click("#tkEditB");E.click("#tkDel");E.click("#tkDel");E.wait_for_timeout(150);ok(len(tk(E))==1,"delete task (two-step)")
  b.close()
print("fails",F);print(errs)
