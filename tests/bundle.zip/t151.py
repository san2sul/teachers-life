src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def state():
  d={"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"],["10102","가온"],["10103","나래"]],"phones":{"10101":"010-1111-0001","10103":"010-1111-0003"},
     "gph":{"10102":[{"r":"어머니","p":"010-2222-0002"}],"10103":[{"r":"아버지","p":"01033330003"}]},"emails":{},"teachers":[],"msg":"{이름} 학생 결석 안내","sessions":[{"id":"s1","date":"2026-10-23","time":"09:00","label":"1교시","p":{}}]}
  return {"active":"c1","list":[{"id":"c1","data":d}],"tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"staff":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def d1(T):return root(T)["list"][0]["data"]
def spy(T):return T.evaluate("window.__goSpy")[-1]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script("window.__goSpy=[];")
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','set');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  ok(d1(T)["gph"]["10103"][0]["p"]=="010-3333-0003","불러올 때 학부모 번호 형식 맞춤")
  T.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)")
  ok("학부모 어머니" in T.inner_text("#stuList .prow:has-text('가온')"),"명단에 학부모 연락처 표시")
  # 학생 고치기에서 학부모 연락처 넣기
  T.click("#stuList .prow:has-text('가람')");T.wait_for_timeout(250)
  ok(T.locator("#esGpAdd").is_visible() and "학생 전화번호" in T.inner_text("#sheetBox"),"학생 정보: 학생 전화 · 학부모 연락처(선택) 따로")
  T.click("#esGpAdd");T.fill("[data-gpp='0']","010555");T.click("#esOk");T.wait_for_timeout(200);ok(T.is_visible("#esErr") and "학부모 전화번호" in T.inner_text("#esErr"),"잘못된 학부모 번호는 막음")
  T.fill("[data-gpp='0']","01055550001");T.click("#esGpAdd");T.select_option("[data-gr='1']","보호자");T.fill("[data-gpp='1']","010-5555-0009")
  ok(not T.locator("#esGpAdd").is_visible(),"학부모 연락처는 2명까지")
  T.screenshot(path="shot/t151_edit.png")
  T.click("#esOk");T.wait_for_timeout(300)
  g=d1(T)["gph"]["10101"];ok(g==[{"r":"어머니","p":"010-5555-0001"},{"r":"보호자","p":"010-5555-0009"}],"저장: "+str(g))
  ok(d1(T)["phones"]["10101"]=="010-1111-0001","학생 번호는 그대로")
  # 학번 바꾸면 학부모 연락처도
  T.click("#stuList .prow:has-text('나래')");T.wait_for_timeout(250);T.fill("#esId","10113");T.click("#esOk");T.wait_for_timeout(300)
  d=d1(T);ok("10113" in d["gph"] and "10103" not in d["gph"],"학번을 바꾸면 학부모 연락처도 따라감")
  # 일괄 입력: 학생 · 학부모 칸
  T.evaluate("document.querySelector('[data-bulk=stu]').click()");T.wait_for_timeout(300)
  T.fill("#bkText","10104\t다솜\t010-4444-0004\t010-4444-9004\n10105\t라온\t\t010-5555-9005\n10106 마루 010-6666-0006");T.dispatch_event("#bkText","input");T.wait_for_timeout(200)
  ok("학부모 전화" in T.inner_text("#bkPrev") and "010-5555-9005" in T.inner_text("#bkPrev"),"일괄 입력 미리보기에 학부모 전화 칸")
  T.click("#bkAdd");T.wait_for_timeout(300);d=d1(T)
  ok(d["phones"].get("10104")=="010-4444-0004" and d["gph"]["10104"][0]["p"]=="010-4444-9004","두 번호: 학생 · 학부모")
  ok("10105" not in d["phones"] and d["gph"]["10105"][0]["p"]=="010-5555-9005","학생 칸이 비면 넷째 칸은 학부모 번호")
  ok(d["phones"].get("10106")=="010-6666-0006" and "10106" not in d.get("gph",{}),"번호 하나는 학생 번호")
  T.keyboard.press("Escape");T.evaluate("document.getElementById('sheet').hidden=true")
  # 연락: 결석 학생
  T.click(".navb[data-v=call]");T.wait_for_timeout(400)
  ok(T.locator("#bulk [data-cto]").count()==3 and T.get_attribute("#bulk [data-cto=stu]","aria-pressed")=="true","받는 사람: 학생 · 학부모 · 둘 다 (기본 학생)")
  row=T.locator("#abList .crow:has-text('가온')");ok("학생 번호 없음" in row.inner_text() and "어머니" in row.inner_text(),"결석 학생 줄에 학부모 연락처")
  ok(T.locator("#abList .crow:has-text('가람') [data-gs]").count()==2,"학부모마다 전화 · 문자 단추")
  T.locator("#abList .crow:has-text('가람') [data-gs='0']").click();T.wait_for_timeout(150);ok(spy(T).startswith("sms:01055550001") and "%EA%B0%80%EB%9E%8C" in spy(T),"학부모에게 이름 들어간 문자")
  T.screenshot(path="shot/t151_call.png")
  T.click("#bAll");T.wait_for_timeout(150);g=spy(T);ok("01011110001" in g and "01022220002" in g and "01055550001" not in g,"학생: 학생 번호, 학생 번호가 없으면 학부모 번호")
  T.click("#bulk [data-cto=par]");T.wait_for_timeout(300)
  T.click("#bAll");T.wait_for_timeout(150);g=spy(T);ok(all(x in g for x in ["01055550001","01055550009","01022220002","01033330003"]) and "01011110001" not in g,"학부모: 학부모 번호만 (두 분 모두)")
  T.click("#bulk [data-cto=both]");T.wait_for_timeout(300);T.click("#bAll");T.wait_for_timeout(150);g=spy(T);ok("01011110001" in g and "01055550001" in g,"둘 다")
  T.click("#bulk [data-cto=par]");T.wait_for_timeout(200)
  T.click("#bNext");T.wait_for_timeout(150);g=spy(T);ok(g.startswith("sms:") and "01055550001" in g and "01055550009" in g,"한 명씩 보내기: 그 학생의 학부모에게")
  # 학생 골라 연락
  T.click("#ctabs [data-c=pick]");T.wait_for_timeout(300)
  ok(T.locator("#ctStu [data-cto=par]").get_attribute("aria-pressed")=="true","골라 연락에도 같은 받는 사람")
  ok("어머니" in T.inner_text("#pk-stu .pk:has-text('가온')"),"골라 연락 목록에 학부모 번호 표시")
  T.locator("#pk-stu .pk:has-text('가온') [data-a=sms]").click();T.wait_for_timeout(150);ok(spy(T).startswith("sms:01022220002"),"골라 연락: 학부모 문자")
  ok(T.locator("#ctStu").bounding_box()["y"]<T.locator("#pk-stu").bounding_box()["y"],"받는 사람 고르기가 학생 목록 위에")
  r=T.locator("#pk-stu .pk:has-text('가람')");ok(r.locator("[data-gs]").count()==2 and "보호자" in r.inner_text(),"골라 연락: 학생마다 학부모 줄 (전화 · 문자)")
  r.locator("[data-gs='1']").click();T.wait_for_timeout(150);ok(spy(T).startswith("sms:01055550009") and r.get_attribute("aria-checked")=="false","학부모 문자 단추 (학생 선택은 그대로)")
  r.locator("[data-gt='0']").click();T.wait_for_timeout(150);ok(spy(T)=="tel:01055550001","학부모 전화 단추")
  T.locator("#pk-stu .pk:has-text('가람')").click();T.locator("#pk-stu .pk:has-text('가온')").click();T.wait_for_timeout(200)
  ok("받는 사람: 학부모" in T.inner_text("#cp-stu .cpinfo"),"보내기 안내에 받는 사람")
  T.locator("#cp-stu [data-a=all]").click();T.wait_for_timeout(150);g=spy(T);ok(all(x in g for x in ["01055550001","01055550009","01022220002"]) and "01011110001" not in g,"고른 학생의 학부모 모두에게 문자")
  T.locator("#pk-stu .pk:has-text('가람')").scroll_into_view_if_needed();T.screenshot(path="shot/t151_pick.png")
  T.click("#ctStu [data-cto=stu]");T.wait_for_timeout(200)
  # 출석: 결석 연락 줄
  T.click(".navb[data-v=att]");T.wait_for_timeout(300);T.locator("#list .st").nth(0).click();T.wait_for_timeout(250)
  ok(T.locator("#abGoBar").is_visible(),"출석 화면 결석 연락 줄")
  # 학생 한눈에 보기
  T.evaluate("localStorage.setItem('att-app-callto','stu')")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
