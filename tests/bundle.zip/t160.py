src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"],["10202","라온"]]
def state():
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],"tasks":[],
    "recs":[{"id":"f1","k":"free","title":"체육대회 준비 메모","at":"2026-10-20T10:00","place":"","blocks":[{"id":"b1","t":"p","x":"줄다리기 순서 정하기"}],"media":[]},
            {"id":"m1","k":"meet","at":"2026-10-21T15:00","place":"","meet":{"name":"학년 협의회","cnt":"","who":[]},"blocks":[{"id":"b2","t":"p","x":"교우 관계 지도 협의"}],"media":[]}],
    "period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def vis(T,s):return T.evaluate(f"[...document.querySelectorAll('{s}')].filter(e=>e.offsetParent).map(e=>e.textContent.trim())")
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click(".navb[data-v=att]");T.wait_for_timeout(200)
  # 1. 출석 · 기록 메뉴 (5.71)
  ok(vis(T,"#amode .amf")==[],"출석: 섹션 탭 없이")
  ok(vis(T,"#amode .amt")==["출석부","수업 관찰","출석 통계"],"출석 → 출석부 · 수업 관찰 · 출석 통계")
  T.screenshot(path="shot/t160_att.png")
  T.click(".navb[data-v=rec]");T.wait_for_timeout(200)
  ok(vis(T,"#amode .amf")==["평가","기록","학생 정보"],"기록: 평가 · 기록 · 학생 정보")
  ok(vis(T,"#amode .amt")==["평가 점수","학생 서명"] and T.is_visible("#ttTasks") and "평가" in T.inner_text("#cls"),"평가 → 평가 점수 · 학생 서명 (평가 점수부터)")
  T.click("#amode [data-key='t:eval']");T.wait_for_timeout(200);ok(T.is_visible("#s-eval") and vis(T,"#stabs .amt")==["평가 점수","학생 서명"],"학생 서명 (통계 화면 쪽 메뉴도 같은 모양)")
  T.click("#stabs [data-sec=rec]");T.wait_for_timeout(200)
  ok(vis(T,"#amode .amt")==["생활 기록","업무 기록","일상 기록"] and T.is_visible("#m-write"),"기록 → 생활 기록 · 업무 기록 · 일상 기록")
  T.screenshot(path="shot/t160_rec.png")
  T.click("#amode [data-sec=stu]");T.wait_for_timeout(150);T.click("#cnav [data-sec=ev]");T.wait_for_timeout(200)
  ok(T.is_visible("#s-eval"),"섹션마다 마지막 하위 화면 기억 (평가 → 학생 서명)")
  # 2. 생활 기록 · 상담
  T.click("#stabs [data-sec=rec]");T.wait_for_timeout(150);T.click("#amode [data-wk=stu]");T.wait_for_timeout(200)
  ok("생활 기록" in T.inner_text("#wrCard h2") and T.locator("#wrCard [data-wn=stu][data-sub=cns]").count()==1 and T.locator("#wrCard [data-wn=stu][data-sub=life]").count()==1,"생활 기록: 새 상담 · 새 학교생활")
  T.click("#wrCard [data-sub=cns]");T.wait_for_timeout(300)
  ok(T.get_attribute("#wrSub [data-sub=cns]","aria-pressed")=="true" and T.locator("#cnWho").count()==1 and "상담 일시" in T.inner_text("#sheetBox") and "상담 내용" in T.inner_text("#sheetBox"),"상담 칸: 대상 · 방법 · 주제 · 후속 조치 · 다음 상담")
  T.click("#wrPick");T.wait_for_timeout(200)
  T.locator("#sheetBox label:has-text('가온') input, #sheetBox [data-sid='10102']").first.click();T.wait_for_timeout(100)
  btns=vis(T,"#sheetBox .row2 .btn.pri");T.locator("#sheetBox .row2 .btn.pri").last.click();T.wait_for_timeout(300)
  T.click("#cnWho [data-v=par]");T.click("#cnHow [data-v=tel]");T.click("#cnTp [data-v='교우']");T.click("#cnTp [data-v='학업']")
  T.fill("#cnAct","짝 활동으로 바꿈");T.fill("#cnNext","2026-11-04T15:00");T.dispatch_event("#cnNext","change");T.wait_for_timeout(200)
  T.click("#wrEd .wbt");T.keyboard.type("모둠에서 소외감을 느낀다고 함",delay=3);T.wait_for_timeout(700)
  T.screenshot(path="shot/t160_cns.png")
  T.click("#skNo");T.wait_for_timeout(300)
  r=[x for x in root(T)["recs"] if x["k"]=="stu"][0]
  ok(r.get("sub")=="cns" and r["cns"]["who"]=="par" and r["cns"]["how"]=="tel" and set(r["cns"]["tp"])=={"교우","학업"} and r["cns"]["act"]=="짝 활동으로 바꿈" and r["cns"]["next"]=="2026-11-04T15:00","상담 저장 "+json.dumps(r.get("cns"),ensure_ascii=False))
  ev=[e for e in root(T)["events"] if e["id"]=="cns_"+r["id"]];ok(ev and ev[0]["date"]=="2026-11-04" and ev[0]["start"]=="15:00" and ev[0]["cat"]=="학생 면담" and "상담" in ev[0]["title"],"다음 상담 → 일정(학생 면담) "+str(ev[0]["title"] if ev else ""))
  ok("상담" in T.inner_text("#wrCard .wrlist") and T.locator("#wrCard [data-wf=cns]").count()==1,"목록에 ‘상담’ 표시 · 상담 거르기")
  # 학교생활로 바꾸기
  T.click("#wrCard [data-sub=life]");T.wait_for_timeout(300);ok(T.locator("#cnWho").count()==0 and "작성 일시" in T.inner_text("#sheetBox"),"학교생활: 상담 칸 없음");T.click("#skNo");T.wait_for_timeout(200)
  # 3. 일상 기록: 자유 글 옮겨짐, 제목 칸
  T.click("#amode [data-wk=day]");T.wait_for_timeout(200)
  ok("일상 기록" in T.inner_text("#wrCard h2") and "체육대회 준비 메모" in T.inner_text("#wrCard .wrlist") and T.locator("[data-wn=free]").count()==0,"자유 글 → 일상 기록 (제목 그대로)")
  T.click("#wrCard [data-wn=day]");T.wait_for_timeout(300);ok(T.locator("#wrTi").count()==1,"일상 기록에 제목 칸");T.fill("#wrTi","현장체험 안내");T.wait_for_timeout(600);T.click("#skNo");T.wait_for_timeout(200)
  R=root(T)["recs"];ok(any(x["k"]=="day" and x.get("title")=="현장체험 안내" for x in R) and not any(x["k"]=="free" for x in R),"새 일상 기록 저장 · 자유 글 없음 "+str([(x["k"],x.get("title")) for x in R]))
  # 4. 업무 기록 + 모든 기록 찾기
  T.click("#amode [data-wk=meet]");T.wait_for_timeout(200);ok("업무 기록" in T.inner_text("#wrCard h2") and "학년 협의회" in T.inner_text("#wrCard .wrlist") and "체육대회" not in T.inner_text("#wrCard .wrlist"),"업무 기록: 회의 기록만")
  T.fill("#wrQ","소외감");T.wait_for_timeout(300);ok("모든 기록에서 1개" in T.inner_text("#wrCard"),"찾기는 모든 기록(생활 · 업무 · 일상)에서")
  T.fill("#wrQ","");T.wait_for_timeout(200)
  # 5. 평가 3단계
  T.click("#amode [data-sec=ev]");T.wait_for_timeout(200);T.click("main.view:not([hidden]) [data-key='m:task']");T.wait_for_timeout(200)
  T.click("#ttTkNew");T.wait_for_timeout(200);T.click("#tkK [data-k=exam]");T.wait_for_timeout(100)
  ok(T.locator(".tksteps i.on").count()==1 and T.locator("#evY").count()==1 and T.locator("#evT").count()==1 and "실시할 학급" in T.inner_text("#sheetBox"),"1단계: 종류 · 평가명 · 학년도 · 학기 · 실시일 · 대상 학급")
  T.fill("#tkN","2학기 기말고사");T.fill("#tkD","2026-12-10");T.click("#tkAllC");ok("다음: 점수 넣기" in T.inner_text("#tkOk"),"다음 단추")
  T.screenshot(path="shot/t160_ev1.png")
  T.click("#tkOk");T.wait_for_timeout(300)
  t=[x for x in root(T)["tasks"] if x["n"]=="2학기 기말고사"][0];ok(t["year"]==2026 and t["term"]=="2학기","학년도 · 학기 저장")
  ok(T.locator(".tksteps i.on").count()==2 and T.locator("#tkScNx").count()==1,"2단계: 점수 넣기")
  T.fill("#tkPs","10101 90\n10102 80\n10201 70");T.click("#tkPsGo");T.wait_for_timeout(150);T.click("#tkScGo");T.wait_for_timeout(300)
  ok(T.locator("#tkScNx").count()==1,"점수를 넣어도 단계 그대로")
  T.click("#tkScNx");T.wait_for_timeout(200);ok(T.locator(".tksteps i.on").count()==3 and "학생 서명을 받을까요" in T.inner_text("#sheetBox") and "3명" in T.inner_text("#sheetBox"),"3단계: 서명 여부")
  T.click(".tkch[data-p=yes]");T.wait_for_timeout(150);T.screenshot(path="shot/t160_ev3.png")
  T.fill("#tsgR","t@ex.com");T.click("#tkSaGo");T.wait_for_timeout(400)
  E=[e for e in root(T)["evals"] if e.get("tk")==t["id"]];ok(len(E)==2 and T.is_visible("#s-eval"),"서명 받기: 점수 있는 학급마다 (2개) · 학생 서명 화면")
  # 서명 없이
  T.click("#stabs [data-key='m:task']");T.wait_for_timeout(200);T.click("#ttTkNew");T.wait_for_timeout(150);T.fill("#tkN","3단원 퀴즈");T.click("#tkK [data-k=form]");T.fill("#tkN","3단원 퀴즈");T.click("#tkC [data-c=c1]");T.click("#tkOk");T.wait_for_timeout(250)
  T.click("#tkScNx");T.wait_for_timeout(200);ok("아직 넣은 점수가 없어" in T.inner_text("#sheetBox") and T.get_attribute(".tkch[data-p=no]","class").find("on")>=0,"점수가 없으면 ‘서명 없이’만")
  T.click("#tkSaGo");T.wait_for_timeout(250);ok(T.is_visible("#sheet") and "3단원 퀴즈" in T.inner_text("#sheetBox"),"서명 없이 저장 → 그 평가 화면")
  T.click("#skNo");T.wait_for_timeout(150)
  # 과제는 예전처럼 한 번에
  T.click("#ttTkNew");T.wait_for_timeout(150);T.click("#tkK [data-k=hw]");T.wait_for_timeout(100);ok(T.locator(".tksteps").count()==0 and T.inner_text("#tkOk")=="만들기","과제는 단계 없이 바로 만들기")
  T.click("#skNo")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
