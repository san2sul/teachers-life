src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
LONG="https://www.example.com/"+"averyveryverylongpathsegment"*4
def state():
  blocks=[{"id":"b1","t":"h1","x":"제목"},{"id":"b2","t":"p","x":"보통 문단 "+LONG},{"id":"b3","t":"table","rows":[[f"열{i} 내용" for i in range(6)] for _ in range(2)],"hd":1},{"id":"b4","t":"p","x":"끝 문단"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"]],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],"tasks":[],
    "recs":[{"id":"r1","k":"free","title":"긴 글","at":"2026-10-27T08:00","blocks":blocks,"uAt":"2026-10-27T08:00:00Z"}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-27T16:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-wrk','day');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
fs=lambda T,sel:T.evaluate(f"parseFloat(getComputedStyle(document.querySelector('{sel}')).fontSize)")
with sync_playwright() as p:
  b=p.chromium.launch()
  for W in (390,360):
    c=b.new_context(viewport={"width":W,"height":800},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
    T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1000)
    ok(T.evaluate("getComputedStyle(document.documentElement).overflowX") in ("clip","hidden"),f"{W}px 문서 전체 가로 넘침 막기")
    ok(T.evaluate("getComputedStyle(document.documentElement).overscrollBehaviorY")=="none" and T.evaluate("getComputedStyle(document.body).overscrollBehaviorY")=="none",f"{W}px 화면 끝 출렁임 막기")
    ok(T.evaluate("getComputedStyle(document.querySelector('nav.bottom')).transform")!="none" and T.evaluate("getComputedStyle(document.querySelector('nav.bottom')).position")=="fixed","아래 메뉴는 고정 · 따로 그리기")
    T.locator("#wrCard [data-wo]").first.click();T.wait_for_timeout(600)
    ok(fs(T,"#wrEd .wb.p .wbt")>=16 and fs(T,"#wrEd .wtbl td")>=16,f"{W}px 글쓰기 본문 · 표 칸 16px 이상 (본문 {fs(T,'#wrEd .wb.p .wbt')}, 표 {fs(T,'#wrEd .wtbl td')})")
    ok(fs(T,"#wrEd .wb.h1 .wbt")>fs(T,"#wrEd .wb.p .wbt"),"제목은 본문보다 큼")
    T.click("[data-wc=ins]");T.click("#wrTool [data-bo=math]");T.wait_for_timeout(300);ok(fs(T,"#wmT")>=16,f"{W}px 수식 입력 칸 16px 이상");T.keyboard.press("Escape");T.wait_for_timeout(300)
    T.locator("#wrEd .wb.p .wbt").last.click();T.wait_for_timeout(200)
    ok(T.evaluate("document.documentElement.classList.contains('kbopen')") and T.evaluate("getComputedStyle(document.querySelector('nav.bottom')).visibility")=="hidden",f"{W}px 입력하는 동안 아래 바 숨김")
    T.evaluate("document.activeElement.blur()");T.wait_for_timeout(400)
    ok(not T.evaluate("document.documentElement.classList.contains('kbopen')") and T.evaluate("getComputedStyle(document.querySelector('nav.bottom')).visibility")=="visible",f"{W}px 입력을 마치면 아래 바 다시")
    ok(T.evaluate("document.getElementById('sheetBox').scrollWidth<=document.getElementById('sheetBox').clientWidth+1"),f"{W}px 글쓰기 창이 화면 폭 안")
    T.click("[data-wc=tool]");T.click("#wrTool [data-ex]");T.wait_for_timeout(300);T.click(".wexp [data-x=pres]");T.wait_for_timeout(800)
    sw=T.evaluate("(()=>{const e=document.querySelector('.wvps');return [e.scrollWidth,e.clientWidth]})()");ok(sw[0]<=sw[1]+1,f"{W}px 발표 화면: 긴 주소도 화면 폭 안 {sw}")
    ok(T.evaluate("document.documentElement.scrollWidth")<=W,f"{W}px 문서 폭 = 화면 폭")
    if W==390:T.screenshot(path="shot/t153_pres.png")
    c.close()
  c=b.new_context(viewport={"width":1280,"height":800},service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1000)
  T.locator("#wrCard [data-wo]").first.click();T.wait_for_timeout(600);T.locator("#wrEd .wb.p .wbt").last.click();T.wait_for_timeout(200)
  ok(not T.evaluate("document.documentElement.classList.contains('kbopen')"),"컴퓨터에서는 아래 바(왼쪽 메뉴)를 숨기지 않음")
  c.close();b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
