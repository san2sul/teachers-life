src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[],"to":"2026-11-04"}],"active":"t1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",accept_downloads=True);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  ok(T.locator("#ttPnBtn").count()==1,"시간표에 📘 진도 단추");T.click("#ttPnBtn");T.wait_for_timeout(300)
  ok(T.is_visible("#ttProg") and not T.is_visible("#ttGrid") and [x.split(" ·")[0] for x in T.evaluate("[...document.querySelectorAll('#ttProg [data-pns]')].map(b=>b.textContent)")]==["물리학","통합과학"],"진도 화면: 시간표의 교과")
  ok("물리학 · 2개 반" in T.inner_text("#ttProg .pnsubj"),"교과마다 가르치는 반 수")
  T.click("#pnMk");T.wait_for_timeout(200);ok(T.input_value("#pnS")=="물리학","교과 이름 미리 들어감")
  T.fill("#pnTx","1. 힘과 운동 3\n2. 열 2");T.wait_for_timeout(700);ok("2단원 5차시" in T.inner_text("#sheetBox"),"빠르게 만들기: 단원 이름 + 차시 수")
  ok("11월 4일" in T.inner_text("#pnEndI") and "시간표의 학기 종료일" in T.inner_text("#pnEndI"),"학기 끝 = 시간표의 학기 종료일 "+T.inner_text("#pnEndI"))
  T.screenshot(path="shot/t163_make.png")
  T.click("#pnOk");T.wait_for_timeout(300)
  pl=plan(T);ok(len(pl["units"])==2 and [len(u["ch"]) for u in pl["units"]]==[3,2] and set(pl["cls"])=={"c1","c2"} and "end" not in pl,"진도표 저장 (2단원 5차시 · 두 반)")
  ok(T.locator("#ttProg .pnr").count()==2,"현황: 반마다 막대")
  # 붙여넣기(단원 · 차시 두 칸)
  T.click("#pnNew");T.wait_for_timeout(150);T.fill("#pnS","통합과학");T.fill("#pnTx","단원\t차시\n1. 물질\t원소와 화합물\n\t주기율표\n2. 생명\t세포");T.wait_for_timeout(700)
  ok("2단원 3차시" in T.inner_text("#sheetBox"),"붙여넣기(단원 · 차시 두 칸)");T.click("#sheetBox #pnC [data-c=c1]");T.click("#pnOk");T.wait_for_timeout(300)
  tp=[p for p in root(T)["plans"] if p["subj"]=="통합과학"][0];ok([c["t"] for c in tp["units"][0]["ch"]]==["원소와 화합물","주기율표"] and tp["cls"]==["c2"],"차시 이름 · 적용 반")
  # 출석 체크 화면: 오늘 할 차시
  T.click(".navb[data-v=att]");T.wait_for_timeout(300)
  ok(T.is_visible("#pnBar") and "1단원 1차시" in T.inner_text("#pnBar"),"출석 체크 화면에 ‘오늘 할 차시’")
  T.screenshot(path="shot/t163_bar.png")
  T.click("#pnDone");T.wait_for_timeout(300)
  g=plan(T)["pg"]["c1"];ch1=plan(T)["units"][0]["ch"][0]["id"];ok(g.get(ch1,{}).get("st")=="d" and g[ch1]["s"]=="s1" and g[ch1]["d"]=="2026-10-28","✓ 마침 → 그 반 · 그 수업으로 기록")
  ok("✓" in T.inner_text("#pnBar") and T.locator("#pnUndo").count()==1,"기록 뒤 표시 · 되돌리기")
  n=root(T)["notes"];ok(any("1-1 " in (v.get("progress") or "") for v in n.values()),"수업 메모 ‘진도’ 칸에도 자동으로")
  T.click("#pnUndo");T.wait_for_timeout(200);ok(not plan(T).get("pg",{}).get("c1"),"되돌리기");T.click("#pnDone");T.wait_for_timeout(200)
  T.click("#pnMore");T.wait_for_timeout(200);T.locator("#sheetBox [data-pm]").nth(1).click();T.wait_for_timeout(100);T.click("#skNo");T.wait_for_timeout(200)
  g=plan(T)["pg"]["c1"];ok(len(g)==2,"다른 차시: 한 수업에서 두 차시")
  # 현황 · 남은 수업
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#ttProg [data-pns='물리학']");T.wait_for_timeout(200)
  rows=T.evaluate("[...document.querySelectorAll('#ttProg .pnr')].map(r=>r.innerText.replace(/\\n/g,' '))");ok("가장 앞섬" in rows[0] and "2차시 늦음" in rows[1],"반별 상태 "+str(rows))
  ok("부족" in T.inner_text("#ttProg"),"남은 수업 시간이 모자라면 경고 "+T.inner_text("#ttProg .pnwarn") if T.locator("#ttProg .pnwarn").count() else "경고 없음")
  T.screenshot(path="shot/t163_prog.png")
  T.locator("#ttProg [data-pnc]").first.click();T.wait_for_timeout(200);T.click("[data-pk='c2|d']");T.wait_for_timeout(100);T.fill("#pnWk","2026-10-27");T.dispatch_event("#pnWk","change");T.click("#skNo");T.wait_for_timeout(200)
  pl=plan(T);ok(pl["pg"]["c2"][ch1]["st"]=="d" and pl["units"][0]["ch"][0]["wk"]=="2026-10-27","진도표에서 반별로 고치기 · 계획 날짜")
  ok("계획대로" in T.inner_text("#ttProg") or "앞섬" in T.inner_text("#ttProg"),"계획 날짜가 있으면 계획 대비")
  # 고치기: 차시 추가해도 기록 유지
  T.click("#pnEd");T.wait_for_timeout(200);tx=T.input_value("#pnTx");ok(tx.startswith("# 1. 힘과 운동\n1차시"),"고치기: 개요 글로");T.fill("#pnTx",tx.replace("1차시","속력과 속도",1)+"\n3차시 정리");T.wait_for_timeout(600);T.click("#pnOk");T.wait_for_timeout(300)
  pl=plan(T);ok(pl["units"][0]["ch"][0]["t"]=="속력과 속도" and pl["units"][0]["ch"][0]["id"]==ch1 and pl["pg"]["c1"][ch1]["st"]=="d","고쳐도 기록한 진도 그대로")
  # 기록부 엑셀
  with T.expect_download() as dl:T.click("#pnXl")
  ok(dl.value.suggested_filename.startswith("수업진도기록부_물리학"),"수업 진도 기록부 엑셀")
  # 지금 수업 카드
  T.click(".navb[data-v=todo]");T.wait_for_timeout(300);ok("📘 ✓ 1-1, 1-2" in T.inner_text("#v-todo .nowhero"),"지금 수업 카드에 이 수업에서 한 차시(5.81: 기록했으면 ✓) "+T.inner_text("#v-todo .nowhero").replace("\n"," "))
  # 주간 보기로 돌아가기
  T.click(".navb[data-v=tt]");T.wait_for_timeout(200);T.click(".ttmode [data-tm=week]");T.wait_for_timeout(200);ok(T.is_visible("#ttGrid") and not T.is_visible("#ttProg"),"주간 보기로 돌아가기")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
