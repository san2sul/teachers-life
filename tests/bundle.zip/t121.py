src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ROS=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"]]
def state(tt_extra):
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":"과학실"} for w in range(5)}
  cells["2-3"]={"subject":"통합과학","clsId":"c1","clsName":"","room":""}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]};t.update(tt_extra)
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ROS,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s1","date":"2026-10-21","time":"","label":"","p":{"10101":True}}]}}],
    "staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('%s').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
def dev(b,st,when,cheer=None,wx=None):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,timezone_id="Asia/Seoul");c.route("**/*",handler)
  if wx=="fail":c.route("https://api.open-meteo.com/**",lambda r:r.abort())
  elif wx:c.route("https://api.open-meteo.com/**",lambda r:(calls.append(r.request.url),r.fulfill(json=wx))[1])
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX%when)
  T.goto("https://tl.test/index.html");T.evaluate("([s,ch])=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-cheer',JSON.stringify(ch||{am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','5')}",[json.dumps(st),cheer])
  T.reload();T.wait_for_timeout(900);return T
calls=[]
with sync_playwright() as p:
  b=p.chromium.launch()
  # ---- 1. 수업 시작 5분 전 알림 (목 08:56, 1교시 09:00)
  A=dev(b,state({"from":"2026-08-24","to":"2026-12-31"}),"2026-10-22T08:56:00+09:00")
  A.wait_for_timeout(3000);ok(A.is_visible("#alarmBar") and "곧 1교시 수업" in A.inner_text("#alarmBar") and "물리학" in A.inner_text("#alarmBar"),"class alarm 5 min before 1교시: "+(A.inner_text("#alarmBar") if A.is_visible("#alarmBar") else "-"))
  A.click("#abOpen");A.wait_for_timeout(200);ok(A.evaluate("document.documentElement.dataset.view")=="att","alarm → 출석 열기")
  A.reload();A.wait_for_timeout(3600);ok(A.is_hidden("#alarmBar"),"same class not alarmed twice")
  A.click(".navb[data-v=tt]");A.wait_for_timeout(300);ok(A.is_visible("#clsAlBox [data-cal='5'][aria-pressed=true]"),"default: 5분 전")
  with A.expect_download() as d:A.click("#clsIcs")
  ics=open(d.value.path(),encoding="utf-8").read().replace("\r\n ","")
  ok(ics.count("BEGIN:VEVENT")==6 and "RRULE:FREQ=WEEKLY;UNTIL=20261231T235959" in ics and "TRIGGER:-PT5M" in ics and "DTSTART:20261022T090000" in ics,"phone-calendar file: weekly classes with 5-min alarm until term end")
  A.click("#clsAlBox [data-cal='0']");A.wait_for_timeout(100);A.evaluate("localStorage.removeItem('att-app-clsal-seen')");A.reload();A.wait_for_timeout(3600);ok(A.is_hidden("#alarmBar"),"알림 끄기 works")
  # weekend / outside term: none
  W=dev(b,state({"from":"2026-08-24","to":"2026-12-31"}),"2026-10-24T08:56:00+09:00");W.wait_for_timeout(3000);ok(W.is_hidden("#alarmBar"),"no class alarm on Saturday")
  # ---- 2. 학기 종료 후: 시간표 알림 + 방학 인사 (날씨 반영)
  WX={"current":{"temperature_2m":3.4,"apparent_temperature":0.2,"weather_code":61},"daily":{"temperature_2m_max":[9.1],"temperature_2m_min":[1.2]}}
  st2=state({"from":"2026-03-02","to":"2026-10-20","nx":"2026-11-02"})
  B=dev(b,st2,"2026-10-22T08:56:00+09:00",{"am":False,"pm":False,"rg":"seoul"},WX)
  B.wait_for_timeout(2500);sh=B.inner_text("#sheetBox") if B.is_visible("#sheet") else "";print("  break:",sh[:400].replace("\n"," | "))
  ok("가을" in sh or "단풍" in sh,"autumn greeting");ok("서울은 지금 3도" in sh and "비가 내리고" in sh,"today's weather & temperature reflected")
  ok("새 학기가 11일 앞으로" in sh,"D-day to next term")
  ok(calls and "latitude=37.57" in calls[0] and "longitude=126.98" in calls[0],"only the region's coordinates sent")
  B.click("#chGo");B.wait_for_timeout(200)
  ok(B.is_hidden("#alarmBar"),"no class alarm during break (even at 08:56)")
  B.click(".navb[data-v=tt]");B.wait_for_timeout(300);tn=B.inner_text("#ttTermNote");ok("학기가 끝났습니다" in tn and "10월 20일" in tn and "D-11" in tn,"timetable announces term end: "+tn.replace("\n"," "))
  # app still works during break
  B.click(".navb[data-v=att]");B.wait_for_timeout(200);B.evaluate("()=>{const b=document.getElementById('startSes');if(b&&!b.closest('[hidden]'))b.click();else document.querySelector('#tabs .tab.add').click()}");B.wait_for_timeout(300);n0=B.evaluate("document.querySelectorAll('#list .st.on').length");B.click("#list .st >> nth=1");B.wait_for_timeout(150)
  ok(B.evaluate("document.querySelectorAll('#list .st.on').length")!=n0,"attendance still works during break")
  B.reload();B.wait_for_timeout(2500);ok(B.is_hidden("#sheet"),"break message once a day")
  # weather failure → still a message, no error
  C=dev(b,st2,"2026-10-23T09:30:00+09:00",{"am":False,"pm":False,"rg":"busan"},"fail");C.wait_for_timeout(3500)
  sh=C.inner_text("#sheetBox") if C.is_visible("#sheet") else "";ok(C.is_visible("#sheet") and "새 학기" in sh and "도," not in sh and C.inner_text("#brkWx")=="","weather unavailable → warm message without weather")
  # winter season message, no region
  st3=state({"from":"2026-08-24","to":"2026-12-24"})
  Dv=dev(b,st3,"2026-12-28T10:00:00+09:00");Dv.wait_for_timeout(2500);sh=Dv.inner_text("#sheetBox") if Dv.is_visible("#sheet") else ""
  ok("겨울" in sh and "지역 고르기" in sh,"winter message; offers region choice when none")
  Dv.click("#chOff");Dv.wait_for_timeout(100);ok(json.loads(Dv.evaluate("localStorage.getItem('att-app-cheer')"))["brk"]==False,"방학 인사 can be turned off")
  # date validation in UI
  Dv.click(".navb[data-v=tt]");Dv.evaluate("()=>{document.getElementById('ttSet').open=true}");Dv.fill("#ttTo","2026-01-01");Dv.dispatch_event("#ttTo","change");Dv.wait_for_timeout(200)
  ok(json.loads(Dv.evaluate("localStorage.getItem('att-app-v2')"))["tt"]["list"][0]["to"]=="2026-12-24","end before start rejected")
  Dv.fill("#ttTo","2027-02-10");Dv.dispatch_event("#ttTo","change");Dv.wait_for_timeout(200);ok(json.loads(Dv.evaluate("localStorage.getItem('att-app-v2')"))["tt"]["list"][0]["to"]=="2027-02-10","term end saved")
  ok(Dv.is_hidden("#ttTermNote") or "학기가 끝났습니다" not in Dv.inner_text("#ttTermNote"),"extending the term ends the break notice")
  # ---- 3. 최성보
  E=dev(b,state({}),"2026-10-22T13:00:00+09:00")
  E.click(".navb[data-v=set]");E.evaluate("()=>{document.querySelectorAll('details.card').forEach(d=>{if(d.querySelector('#stuList'))d.open=true})}");E.wait_for_timeout(100)
  E.click("#lowPick");E.wait_for_timeout(200);E.check("[data-low='10102']");E.check("[data-low='10104']");ok("2명" in E.inner_text("#lowN"),"pick 최성보");E.click("#lowOk");E.wait_for_timeout(200)
  ok(json.loads(E.evaluate("localStorage.getItem('att-app-v2')"))["list"][0]["data"]["low"]=={"10102":1,"10104":1},"saved in class data")
  ok(E.locator("#stuList .prow:has-text('나래') em").inner_text()=="최성보","marked in roster list")
  E.click(".navb[data-v=att]");E.wait_for_timeout(200);E.evaluate("()=>{const b=document.getElementById('startSes');if(b&&!b.closest('[hidden]'))b.click();else document.querySelector('#tabs .tab.add').click()}");E.wait_for_timeout(300);ok(E.locator("#list .lowtag").count()==2,"marked in attendance grid")
  E.click("[data-m=obs]");E.wait_for_timeout(200);ok(E.locator("#obsList .lowtag").count()==2,"marked in observation list")
  E.click(".navb[data-v=set]");E.evaluate("()=>{document.getElementById('d-ui').open=true}");E.click("[data-ui=low] [data-v=hide]");E.click(".navb[data-v=att]");E.click("[data-m=att]") if E.locator("[data-m=att]").count() else None;E.wait_for_timeout(200)
  ok(E.locator("#list .lowtag").count()==0,"hide option (when showing screen to students)")
  E.click(".navb[data-v=set]");E.click("[data-ui=low] [data-v='']");E.wait_for_timeout(100)
  # change 학번 keeps mark; uncheck in edit
  E.evaluate("()=>{document.querySelectorAll('details.card').forEach(d=>{if(d.querySelector('#stuList'))d.open=true})}");E.click("#stuList .prow:has-text('나래')");E.wait_for_timeout(200)
  ok(E.is_checked("#esLow"),"edit sheet shows checkbox");E.fill("#esId","10199");E.click("#esOk");E.wait_for_timeout(200)
  ok(json.loads(E.evaluate("localStorage.getItem('att-app-v2')"))["list"][0]["data"]["low"]=={"10199":1,"10104":1},"학번 change carries the mark")
  E.click("#stuList .prow:has-text('라온')");E.wait_for_timeout(200);E.uncheck("#esLow");E.click("#esOk");E.wait_for_timeout(200)
  E.reload();E.wait_for_timeout(800);ok(json.loads(E.evaluate("localStorage.getItem('att-app-v2')"))["list"][0]["data"]["low"]=={"10199":1},"unmark + survives reload")
  b.close()
print("fails",F);print(errs)
