src=open('audit2.py').read();exec(src.split("sizes=")[0])
import time
META=json.load(open("schf/meta.json"))
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def M(T):return T.evaluate("new Promise(r=>{const q=indexedDB.open('teachers-life-media');q.onsuccess=()=>{const g=q.result.transaction('m').objectStore('m').get('kv:school:master');g.onsuccess=()=>r(g.result?JSON.parse(g.result):null)}})")
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},has_touch=True,service_workers="block",accept_downloads=True);c.route("**/*",handler);T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)))
  T.goto("https://tl.test/index.html");T.evaluate("s=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1')}",json.dumps(S));T.reload();T.wait_for_timeout(700)
  s0=T.evaluate("localStorage.getItem('att-app-v2').length")
  T.click(".navb[data-v=set]");T.evaluate("()=>{const d=document.getElementById('d-school');d.open=true}");T.wait_for_timeout(150)
  ok("켜기" in T.inner_text("#schEntry"),"settings shows opt-in entry");T.click("#schOpen");T.wait_for_timeout(200)
  ok(T.evaluate("document.getElementById('schOnBtn').disabled"),"must confirm privacy notice first");T.check("#schAgree");T.click("#schOnBtn");T.wait_for_timeout(400)
  ok(not T.evaluate("document.getElementById('v-school').hidden"),"school screen opens")
  # upload v1
  T.set_input_files("#schFile","schf/v1.xlsx");T.wait_for_timeout(1500);sh=T.inner_text("#sheetBox")
  ok("학생 300명" in sh and "학급 12개" in sh and "교직원 3명" in sh,"NEIS-style file read (title rows above header, '성 명' header, 2 sheets): "+sh[:80].replace("\n"," "))
  T.click("#schGo");T.wait_for_timeout(500);m=M(T)
  ok(len(m["students"])==300 and len(m["staff"])==3 and len({s["uid"] for s in m["students"]})==300,"saved with unique ids")
  ok(m["students"][0]["sid"]=="10101" and m["students"][0]["pphone"].startswith("010-"),"학번 built from 학년·반·번호, phone kept")
  ok(T.evaluate("localStorage.getItem('att-app-v2').length")==s0 and "school" not in T.evaluate("localStorage.getItem('att-app-v2')"),"teacher's own data untouched (master kept separately)")
  kp=T.inner_text("#schBody .kpis");ok("12" in kp and "300" in kp,"KPIs: "+kp.replace("\n"," "))
  T.click("[data-ck='1-1']");T.wait_for_timeout(200);ok(T.locator("#schList .schstu .prow").count()==25,"class 1-1 shows 25 students")
  # edit
  T.locator("#schList .schstu .prow").nth(4).click();T.wait_for_timeout(200);T.fill("#ssPh","01055556666");T.click("#ssOk");T.wait_for_timeout(300)
  ok(any(s["phone"]=="010-5555-6666" for s in M(T)["students"]),"edit student saves")
  uid_moved=[s["uid"] for s in M(T)["students"] if s["name"]==META["moved"]][0]
  other=[s for s in M(T)["students"] if s["sid"]=="10201"][0]
  # upload v2 → compare
  T.set_input_files("#schFile","schf/v2.xlsx");T.wait_for_timeout(1500);sh=T.inner_text("#sheetBox");print("  compare:",sh[:400].replace("\n"," | "))
  def cnt(k):return T.evaluate(f"document.querySelectorAll('#sheetBox input[data-k={k}][data-i]').length")
  ok(cnt("add")==2 and cnt("move")==1 and cnt("sid")==1 and cnt("info")==1 and cnt("gone")==1 and cnt("staffAdd")==1 and cnt("staffInfo")==1,f"diff: add{cnt('add')} move{cnt('move')} sid{cnt('sid')} info{cnt('info')} gone{cnt('gone')} staffAdd{cnt('staffAdd')} staffInfo{cnt('staffInfo')}")
  # exclude one new student
  T.evaluate("()=>{document.querySelectorAll('#sheetBox .schk details').forEach(d=>d.open=true)}");T.uncheck("#sheetBox input[data-k=add][data-i='1']");T.wait_for_timeout(100)
  ok(T.evaluate("document.querySelector('#sheetBox input[data-k=add]:not([data-i])').indeterminate"),"category shows partial selection")
  T.click("#schGo");T.wait_for_timeout(500);m=M(T)
  live=[s for s in m["students"] if s["st"]=="재학"]
  mv=[s for s in m["students"] if s["uid"]==uid_moved][0];ot=[s for s in m["students"] if s["uid"]==other["uid"]][0]
  ok(mv["cls"]==2 and mv["sid"]=="10201","moved student kept same id, new class/학번")
  ok(ot["name"]==other["name"] and ot["sid"]=="10201","student already holding 10201 not mixed up (both exist)")
  ok(any(s["name"]==META["typo_to"] for s in live) and not any(s["name"]==META["typo_from"] for s in live),"name correction applied")
  ok([s["st"] for s in m["students"] if s["name"]==META["gone"]]==["전출"],"missing student marked 전출 (not deleted)")
  ok(sum(1 for s in live if s["name"] in("새전입","또전입"))==1,"unchecked newcomer skipped (selective apply)")
  ok(len(m["staff"])==4 and [t["role"] for t in m["staff"] if t["name"]=="김물리"]==["부장"],"staff added/updated")
  ok(len(m["log"])>=1 and m["log"][-1]["what"]=="명단 올리기","change log recorded")
  # undo
  T.click("#schUndo");T.wait_for_timeout(200);T.click("#skOk");T.wait_for_timeout(500);m=M(T)
  ok(len([s for s in m["students"] if s["st"]=="재학"])==300 and not any(s["name"]=="새전입" for s in m["students"]) and [s for s in m["students"] if s["uid"]==uid_moved][0]["cls"]==1,"갱신 전으로 되돌리기 restores")
  # swipe delete staff + undo
  T.click("[data-st=staff]");T.wait_for_timeout(200);n0=len(M(T)["staff"])
  cdp=c.new_cdp_session(T);row=T.locator("#schList .prow").first;row.evaluate("e=>e.scrollIntoView({block:'center'})");T.wait_for_timeout(150);bb=row.bounding_box();x=bb["x"]+bb["width"]*.7;y=bb["y"]+bb["height"]/2
  cdp.send("Input.dispatchTouchEvent",{"type":"touchStart","touchPoints":[{"x":x,"y":y}]})
  for i in range(1,9):cdp.send("Input.dispatchTouchEvent",{"type":"touchMove","touchPoints":[{"x":x-150*i/8,"y":y}]});T.wait_for_timeout(16)
  cdp.send("Input.dispatchTouchEvent",{"type":"touchEnd","touchPoints":[]});T.wait_for_timeout(300)
  bb=T.locator(".swdel").bounding_box();T.touchscreen.tap(bb["x"]+bb["width"]/2,bb["y"]+bb["height"]/2);T.wait_for_timeout(500)
  ok(len(M(T)["staff"])==n0-1,"swipe delete in school staff list");T.click("#utoast button");T.wait_for_timeout(400);ok(len(M(T)["staff"])==n0,"undo")
  # search
  T.click("[data-st=stu]");T.fill("#schQ",META["gone"]);T.wait_for_timeout(500);ok(T.locator("#schList .prow").count()>=1,"student search")
  # backup + off/on
  with T.expect_download() as dl:T.click("#schBk")
  bk=json.load(open(dl.value.path()));ok(bk["kind"]=="teachers-life-school" and len(bk["students"])==300,"원본 백업 파일")
  T.click("#schOff");T.click("#schOff");T.wait_for_timeout(300);ok(not T.evaluate("document.getElementById('v-set').hidden") and "켜기" in T.inner_text("#schEntry"),"turn off -> back to settings, entry hidden")
  T.evaluate("localStorage.setItem('att-app-view','school')");T.reload();T.wait_for_timeout(700);ok(T.evaluate("document.getElementById('v-school').hidden"),"off: school screen not reachable after reload")
  T.evaluate("localStorage.setItem('att-app-school','1');localStorage.setItem('att-app-view','school')");T.reload();T.wait_for_timeout(900)
  ok(not T.evaluate("document.getElementById('v-school').hidden") and "300" in T.inner_text("#schBody .kpis"),"on again: data still there after reload on school screen")
  # restore backup via general file import
  T.click("#schBack");T.evaluate("t=>{const f=new File([t],'b.json',{type:'application/json'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('restoreFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",json.dumps(bk,ensure_ascii=False));T.wait_for_timeout(700)
  ok("학교 원본 백업 불러오기" in T.inner_text("#sheetBox"),"settings file import recognises school backup");T.click("#skNo")
  # big file
  T.evaluate("()=>{document.getElementById('sheet').hidden=true;document.querySelector('.navb[data-v=set]').click();const d=document.getElementById('d-school');d.open=true}");T.click("#schOpen");T.wait_for_timeout(500)
  t0=time.time();T.set_input_files("#schFile","schf/big.xlsx");T.wait_for_selector("#schGo",timeout=60000);t1=time.time()-t0
  t0=time.time();T.click("#schGo");T.wait_for_timeout(200);T.wait_for_function("document.querySelector('#schBody .kpis')&&document.querySelector('#schBody .kpis').innerText.includes('4')",timeout=30000);t2=time.time()-t0
  m=M(T);live=[s for s in m["students"] if s["st"]=="재학"]
  print(f"  big file: read+compare {t1:.1f}s, apply {t2:.1f}s, live {len(live)}, staff {len(m['staff'])}")
  ok(len(live)==4200 and t1<15,"4,200-student file handled")
  T.screenshot(path="shot/sch_main.png",full_page=False)
  b.close()
print("fails",F);print(errs)
