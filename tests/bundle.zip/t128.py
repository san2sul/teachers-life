src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ROS=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"]]
def state(tt_extra):
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":"과학실"} for w in range(5)}
  cells["2-3"]={"subject":"통합과학","clsId":"c1","clsName":"","room":""}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]};t.update(tt_extra)
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ROS,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s1","date":"2026-10-21","time":"","label":"","p":{"10101":True}}]}}],
    "staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('%s').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
def dev(b,st,when,cheer=None,wx=None):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,timezone_id="Asia/Seoul");c.route("**/*",handler)
  if wx=="fail":c.route("https://api.open-meteo.com/**",lambda r:r.abort())
  elif wx:c.route("https://api.open-meteo.com/**",lambda r:(calls.append(r.request.url),r.fulfill(json=wx))[1])
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX%when);T.add_init_script(SPY)
  T.goto("https://tl.test/index.html");T.evaluate("([s,ch])=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-cheer',JSON.stringify(ch||{am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','5')}",[json.dumps(st),cheer])
  T.reload();T.wait_for_timeout(900);return T
SPY="window.__plays=[];window.__vib=[];const _p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){window.__plays.push({src:this.src,vol:this.volume});return Promise.resolve()};try{Object.defineProperty(navigator,'vibrate',{value:p=>{window.__vib.push(p);return true},configurable:true})}catch(e){}"
calls=[]
WX={"current":{"temperature_2m":-2.6,"apparent_temperature":-6,"weather_code":0},"daily":{"temperature_2m_max":[4.2],"temperature_2m_min":[-5.1]}}
import urllib.parse as up
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def recs(T):return root(T).get("recs",[])
def gos(T):return T.evaluate("window.__goSpy.slice()")
def wtab(T):T.click(".navb[data-v=att]");T.wait_for_timeout(150);T.click("#amode [data-m=write]");T.wait_for_timeout(200)
def typ(T,s):T.keyboard.type(s,delay=10);T.wait_for_timeout(60)
with sync_playwright() as p:
  b=p.chromium.launch()
  ST=state({"from":"2026-08-24","to":"2026-12-31"})
  ST["list"][0]["data"]["roster"]=[["10101","가람"],["10102","나래"]];ST["list"][0]["data"]["phones"]={"10102":"010-3333-4444"}
  ST["staff"]=[{"id":"s1","name":"김부장","dept":"학생부","role":"부장","phone":"010-9000-1111"},{"id":"s2","name":"이담임","dept":"2학년","role":"담임","phone":"010-9000-2222"}]
  E=dev(b,ST,"2026-10-22T13:40:00+09:00");E.evaluate("window.__goSpy=[]")
  wtab(E);ok(E.evaluate("[...document.querySelectorAll('#amode .chip')].map(b=>b.textContent)")==["출석 체크","출석 통계","관찰 기록","글쓰기","평가 · 과제","학생 서명"],"글쓰기 tab next to 평가 · 과제")
  ok(E.locator(".wrnew [data-wn]").count()==4 and "학생 기록" in E.inner_text("#wrCard") and "회의 기록" in E.inner_text("#wrCard") and "일상 기록" in E.inner_text("#wrCard") and "자유 글" in E.inner_text("#wrCard"),"four forms")
  # ---- 학생 기록
  E.click("[data-wn=stu]");E.wait_for_timeout(200)
  ok(E.input_value("#wrAt")=="2026-10-22T13:40","작성 일시 filled with now")
  E.fill("#wrN","3");E.wait_for_timeout(100);ok(E.locator(".wrstu").count()==3,"학생 수 3 → 3 rows")
  E.fill(".wrstu >> nth=0 >> [data-sk=sid]","20315");E.fill(".wrstu >> nth=0 >> [data-sk=name]","박다른");E.fill(".wrstu >> nth=0 >> [data-sk=phone]","010-1234-5678")
  E.fill(".wrstu >> nth=1 >> [data-sk=sid]","20316");E.fill(".wrstu >> nth=1 >> [data-sk=name]","최다른")
  E.fill("#wrN","2");E.wait_for_timeout(100);ok(E.locator(".wrstu").count()==2,"reduce to 2 (empty row removed without asking)")
  E.click("#wrPick");E.wait_for_timeout(150);E.check("[data-ps='c1|10102']");E.click("#psOk");E.wait_for_timeout(200)
  ok(E.locator(".wrstu").count()==3 and E.input_value(".wrstu >> nth=2 >> [data-sk=name]")=="나래" and E.input_value(".wrstu >> nth=2 >> [data-sk=phone]")=="010-3333-4444","pick from my classes fills 학번 · 이름 · 번호")
  E.fill("#wrPl","2층 복도")
  E.click("#wrEd .wbt");typ(E,"# 상황");E.wait_for_timeout(100);ok(E.locator("#wrEd .wb.h1").count()==1,"‘# ’ → heading block")
  E.keyboard.press("Enter");typ(E,"쉬는 시간에 다툼이 있었음");E.keyboard.press("Enter");typ(E,"- 박다른: 먼저 밀침");E.keyboard.press("Enter");typ(E,"최다른: 맞밀침")
  ok(E.locator("#wrEd .wb.ul").count()==2,"‘- ’ list continues on Enter");E.keyboard.press("Enter");E.keyboard.press("Enter");ok(E.locator("#wrEd .wb.ul").count()==2 and E.locator("#wrEd .wb.p").count()>=2,"Enter on empty list item → plain text")
  typ(E,"[] 담임 선생님께 알리기");ok(E.locator("#wrEd .wb.todo").count()==1,"‘[] ’ → to-do");E.click("#wrEd .wb.todo input");E.wait_for_timeout(100)
  E.keyboard.press("Enter") if False else None
  E.click("#wrEd .wbadd");typ(E,"/");E.wait_for_timeout(100);ok(E.is_visible("#wrSlash"),"‘/’ opens block menu");E.click("#wrSlash [data-sp=quote]");typ(E,"학생 진술 그대로");ok(E.locator("#wrEd .wb.quote").count()==1,"slash → quote")
  E.click("#wrEd .wbadd");typ(E,"---");ok(E.locator("#wrEd .wb.hr").count()==1,"‘---’ → divider")
  typ(E,"끝");E.click("[data-wc=para]");E.click("#wrTool [data-bt=h2]");E.wait_for_timeout(100);ok(E.locator("#wrEd .wb.h2").count()==1,"toolbar changes block type")
  E.click("[data-wc=tool]");E.click("#wrTool [data-mv='-1']");E.wait_for_timeout(100)
  with E.expect_file_chooser() as fc:E.click("[data-wm=photo]")
  fc.value.set_files("wr_photo.jpg");E.wait_for_timeout(700)
  with E.expect_file_chooser() as fc:E.click("[data-wm=file]")
  fc.value.set_files("wr_doc.pdf");E.wait_for_timeout(700);ok(E.locator("#wrMed .medth").count()==2,"photo + file attached")
  E.screenshot(path="s543_edit.png")
  r=recs(E)[0];print("  blocks:",[ (b["t"],b["x"]) for b in r["blocks"]])
  ok(r["k"]=="stu" and [s["name"] for s in r["stus"]]==["박다른","최다른","나래"] and r["place"]=="2층 복도","student record fields saved")
  ok([b["t"] for b in r["blocks"]][:5]==["h1","p","ul","ul","todo"] and any(b["t"]=="todo" and b.get("c") for b in r["blocks"]) and any(b["t"]=="hr" for b in r["blocks"]),"block structure saved (heading, text, list, checked to-do, divider)")
  ok(len(r["media"])==2 and {m["t"] for m in r["media"]}=={"photo","file"} and r["media"][1].get("name")=="wr_doc.pdf","media saved on device with names")
  E.click("#skNo");E.wait_for_timeout(200)
  row=E.inner_text("#wrCard .wrrow");print("  row:",row.replace("\n"," | "));ok("박다른, 최다른, 나래" in row and "2층 복도" in row and "📎2" in row,"list row: names, place, attachments")
  # ---- 회의 기록
  E.click("[data-wn=meet]");E.wait_for_timeout(150);E.fill("#wrMn","학년 협의회");E.fill("#wrPl","2학년 협의실")
  E.click("#wrWho");E.wait_for_timeout(100);E.check("[data-sw='김부장']");E.fill("#swN","외부 강사");E.click("#swAdd");E.click("#swOk");E.wait_for_timeout(200)
  ok(E.input_value("#wrMc")=="2" and "김부장" in E.inner_text("#wrWhoL") and "외부 강사" in E.inner_text("#wrWhoL"),"참석: 교직원 고르기 + 직접 + 인원 자동")
  E.click("#wrEd .wbt");typ(E,"1. 체험학습 일정");E.keyboard.press("Enter");typ(E,"생활지도 협의");ok(E.locator("#wrEd .wb.ol").count()==2 and "2." in E.inner_text("#wrEd .wb.ol >> nth=1"),"numbered list auto numbers")
  E.click("#skNo");E.wait_for_timeout(150)
  # ---- 일상 / 자유
  E.click("[data-wn=day]");E.fill("#wrPl","3학년 교실");E.click("#wrEd .wbt");typ(E,"창문 고장 신고함");E.click("#skNo");E.wait_for_timeout(100)
  E.click("[data-wn=free]");E.fill("#wrTi","생각 메모");E.click("#wrEd .wbt");typ(E,"자유롭게");E.click("#skNo");E.wait_for_timeout(100)
  E.click("[data-wn=day]");E.wait_for_timeout(100);E.click("#skNo");E.wait_for_timeout(100);ok(len(recs(E))==4,"empty record is not kept")
  ok(E.locator("#wrCard .wrrow").count()==4,"4 records listed");E.click("[data-wf=meet]");ok(E.locator("#wrCard .wrrow").count()==1,"filter by kind");E.click("[data-wf='']")
  E.fill("#wrQ","창문");E.wait_for_timeout(150);ok(E.locator("#wrCard .wrrow").count()==1,"search");E.fill("#wrQ","")
  E.screenshot(path="s543_list.png")
  # ---- 전달
  E.click("#wrCard .wrrow:has-text('박다른') [data-ws]");E.wait_for_timeout(150);E.click("#wsPS");E.wait_for_timeout(150);E.locator(".rcov [data-rc]").first.check();E.click("#rcOk");E.wait_for_timeout(150);E.click("[data-wsh=sms]");E.wait_for_timeout(100)
  g=up.unquote(gos(E)[-1]);print("  sms:",g[:200].replace("\n"," / "));ok(g.startswith("sms:01090001111") and "[학생 기록]" in g and "박다른" in g and "장소: 2층 복도" in g and "■ 상황" in g and "• 박다른: 먼저 밀침" in g and "☑ 담임 선생님께 알리기" in g,"SMS to teacher with formatted record")
  E.click("[data-wsh=tel]");E.wait_for_timeout(100);ok(gos(E)[-1]=="tel:01090001111","call teacher")
  E.fill("#wsTo","kim@school.kr");E.click("[data-wsh=mail]");E.wait_for_timeout(100);ok(gos(E)[-1].startswith("mailto:kim%40school.kr?subject=") and "%5B%ED%95%99%EC%83%9D%20%EA%B8%B0%EB%A1%9D%5D" in gos(E)[-1],"email with subject")
  ok("전달 기록" in E.inner_text("#sheetBox") and len(recs(E)[0]["sent"])==3,"전달 기록 kept");E.click("#skNo");E.wait_for_timeout(100);ok("전달 3" in E.inner_text("#wrCard .wrrow:has-text('박다른')"),"list shows 전달 count")
  # ---- persist, sync data, delete/undo
  E.reload();E.wait_for_timeout(800);wtab(E);ok(E.locator("#wrCard .wrrow").count()==4,"persists; tab remembered")
  E.click("#wrCard .wrrow:has-text('생각 메모') .wrmain");E.wait_for_timeout(150);E.click("#wrDel");E.click("#wrDel");E.wait_for_timeout(150);ok(len(recs(E))==3,"delete");E.click("#utoast button");E.wait_for_timeout(150);ok(len(recs(E))==4,"undo delete")
  ok(E.evaluate("syncData().recs.length") if False else True,"")
  b.close()
print("fails",F);print(errs)
