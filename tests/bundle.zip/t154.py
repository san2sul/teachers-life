src=open('audit2.py').read();exec(src.split("sizes=")[0])
import os,mimetypes
from urllib.parse import urlparse
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def ev(i,d,t,title,done=False):return {"id":i,"date":d,"start":t,"end":"","cat":"교무 업무","title":title,"memo":"","clsId":"","alarm":10,"important":False,"done":done}
def state():
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"]],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":{},"adj":{},"days":{},"chg":[]}],"active":"t1"},"notes":{},
    "events":[ev("a1","2026-10-27","13:00","생활기록부 점검"),ev("a2","2026-10-28","15:00","부서 회의"),ev("a3","2026-10-29","16:00","학부모 상담")],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-27T09:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def evs(T):return {e["id"]:e for e in json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))["events"]}
def anyhost(route,req):
  u=urlparse(req.url);path=u.path.lstrip('/');path=(path[len('teachers-life/'):] if path.startswith('teachers-life/') else path) or 'index.html'
  if path=='config.js':return route.fulfill(body='window.TL_CONFIG={};',content_type='text/javascript')
  fp=os.path.join(APP,path)
  if not os.path.exists(fp):return route.fulfill(status=404,body='nf')
  return route.fulfill(path=fp,content_type=mimetypes.guess_type(fp)[0] or 'text/plain')
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.add_init_script("window.__goSpy=[];");T.goto("https://tl.test/index.html");T.wait_for_timeout(1000)
  ok(T.locator("#offWarn").count()==0,"공식(시험) 주소에서는 경고 없음")
  ok(T.inner_text("#agCard h2")=="일정 알림","제목 ‘일정 알림’ (가운데 점 없음)")
  ok(T.inner_text("#agAdd").strip()=="＋ 일정 · 할 일","시간표 추가 단추 이름")
  ok(T.locator("#agList .ev .evck").count()==3,"일정마다 마감(완료) 단추")
  T.locator("#agList .ev[data-ev=a1] .evck").click();T.wait_for_timeout(300)
  ok(evs(T)["a1"].get("done") is True and "done" in T.get_attribute("#agList .ev[data-ev=a1]","class"),"시간표 일정 알림에서 마감 → 저장")
  ok(T.locator("#sheet").is_hidden(),"마감 단추는 일정 창을 열지 않음")
  ok("마감" in T.inner_text("#agList .ev[data-ev=a1]"),"마감 표시")
  T.screenshot(path="shot/t154_tt.png")
  T.click(".navb[data-v=todo]");T.wait_for_timeout(400)
  ok(T.inner_text("#tdAdd").strip()=="＋ 일정 · 할 일","오늘 추가 단추 이름도 같음")
  ok(T.locator("#tdList .td[data-k='ev:a1']").count()==0 and T.locator("#tdList .td[data-k='ev:a2']").count()==1,"오늘 할 일에서도 완료(목록에서 빠짐)")
  T.check("#tdDone");T.wait_for_timeout(300);ok("done" in T.get_attribute("#tdList .td[data-k='ev:a1']","class"),"완료 보기로 켜면 완료로 보임")
  T.locator("#tdList .td[data-k='ev:a2'] .tdc").click();T.wait_for_timeout(300)
  ok(evs(T)["a2"].get("done") is True,"오늘에서 완료")
  T.click(".navb[data-v=tt]");T.wait_for_timeout(400)
  ok("done" in T.get_attribute("#agList .ev[data-ev=a2]","class") and T.get_attribute("#agList .ev[data-ev=a2] .evck","aria-checked")=="true","시간표 일정 알림에도 마감으로 보임")
  T.locator("#agList .ev[data-ev=a2] .evck").click();T.wait_for_timeout(300);ok(not evs(T)["a2"].get("done"),"시간표에서 마감 풀기")
  T.click(".navb[data-v=todo]");T.wait_for_timeout(300);ok("done" not in T.get_attribute("#tdList .td[data-k='ev:a2']","class"),"오늘에서도 다시 할 일")
  T.click("#tdAdd");T.wait_for_timeout(300);t1=T.inner_text("#sheetBox h2");T.click("#skNo");T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#agAdd");T.wait_for_timeout(300);t2=T.inner_text("#sheetBox h2")
  ok(t1==t2=="일정 · 할 일 추가","두 단추가 같은 창 (‘일정 · 할 일 추가’)");T.click("#skNo");T.wait_for_timeout(200)
  T.locator("#agList .ev[data-ev=a3]").click();T.wait_for_timeout(300);ok(T.locator("#evDone").count()==1,"일정 창에 마감(완료) 칸");T.check("#evDone");T.click("#evOk");T.wait_for_timeout(300)
  ok(evs(T)["a3"].get("done") is True,"일정 창에서 마감")
  T.click(".navb[data-v=set]");T.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)");T.wait_for_timeout(200)
  ok("san2sul.github.io/teachers-life" in T.inner_text("#verMaker") and "무단" in T.inner_text("#verMaker"),"앱 정보에 공식 주소 · 저작권")
  tx=T.evaluate("fetch('terms.html').then(r=>r.text())");ok("저작권과 공식 주소" in tx,"이용약관에 저작권 조항")
  tx=T.evaluate("fetch('LICENSE').then(r=>r.status+' '+(r.ok?'':'')).then(x=>x)");lt=T.evaluate("fetch('LICENSE').then(r=>r.text())");ok(tx.startswith("200") and "All rights reserved" in lt,"LICENSE 파일")
  c.close()
  c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",anyhost)
  T=c.new_page();T.on("pageerror",lambda e:errs.append("X:"+str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://copy.example.com/teachers-life/index.html");T.wait_for_timeout(1500)
  ok(T.locator("#offWarn").count()==1 and "공식 앱이 아닙니다" in T.inner_text("#offWarn"),"다른 주소에서 열면 ‘공식 앱이 아닙니다’ 경고")
  ok(T.get_attribute("#offWarn a","href")=="https://san2sul.github.io/teachers-life/","공식 앱 열기 링크")
  T.screenshot(path="shot/t154_warn.png")
  T.click("#offWarn .x");T.wait_for_timeout(200);ok(T.locator("#offWarn").count()==0,"이번에는 닫기")
  T.reload();T.wait_for_timeout(1200);ok(T.locator("#offWarn").count()==0,"같은 창에서는 다시 안 뜸")
  c.close();b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
