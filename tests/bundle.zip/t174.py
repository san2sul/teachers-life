src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "flowCfg":{"auto":True},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
import openpyxl,os
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",accept_downloads=True);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.on("dialog",lambda d:d.accept("김선생"));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  log=lambda:json.loads(T.evaluate("localStorage.getItem('att-app-rlog')||'[]'"))
  T.click(".navb[data-v=att]");T.wait_for_timeout(200);ok(log()==[],"기본은 꺼짐 — 아무것도 기록 안 함")
  T.click("#topBtns .setb");T.wait_for_timeout(300);T.evaluate("document.getElementById('d-rl').open=true");T.wait_for_timeout(200)
  ok("학생 이름 · 학번 · 연락처는 기록하지 않고" in T.inner_text("#rlBody") and "참여 ID" in T.inner_text("#rlBody"),"설정 → 연구용 사용 기록 안내")
  T.click("#rlBody [data-rl='1']");T.wait_for_timeout(200);ok(T.evaluate("localStorage.getItem('att-app-rlon')")=="1","켜기")
  # 출석 체크: 열고 → 잠그기
  T.click(".navb[data-v=att]");T.wait_for_timeout(1200);T.click("#lockBtn");T.wait_for_timeout(200)
  a=[r for r in log() if r["k"]=="att"];ok(a and a[0]["n"]==2 and a[0]["sec"] is not None and "가람" not in json.dumps(a,ensure_ascii=False),"출석 체크 시작→잠금 시간 · 명단 수(이름 없음) "+str(a[:1]))
  # 연락
  T.click(".navb[data-v=call]");T.wait_for_timeout(200);T.evaluate("()=>{const a=document.createElement('a');a.href='sms:01000000000';a.id='rlA';a.textContent='x';a.onclick=e=>e.preventDefault();document.getElementById('v-call').appendChild(a)}");T.click("#rlA");T.wait_for_timeout(100)
  ok(any(r["k"]=="contact" and r["how"]=="문자" for r in log()) and "01000000000" not in json.dumps(log()),"문자 누름 기록(번호는 기록 안 함)")
  # 진도 · 수업 흐름
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400);T.click("#mnPnAtt");T.wait_for_timeout(600);T.click("#pnFullBox [data-pc='a2|d']");T.wait_for_timeout(200);T.click("#pnFullX");T.wait_for_timeout(200)
  ok(any(r["k"]=="pn" and r["st"]=="d" for r in log()),"진도 기록(마침)")
  T.click(".navb[data-v=att]");T.wait_for_timeout(800);T.click("#flLine [data-flpick]");T.wait_for_timeout(300);T.click("#sheetBox [data-fp='b:3']");T.click("#flUse");T.wait_for_timeout(1300)
  H="#sheetBox .flsheetnow";T.click("#flLine [data-fls]");T.wait_for_timeout(500)
  T.click(H+" [data-flplus]");T.wait_for_timeout(1200);T.click(H+" [data-flnext]");T.wait_for_timeout(1200)
  if T.is_visible("#ctool"):T.click("#ctX");T.wait_for_timeout(600)
  if T.is_visible("#sheet"):T.click("#skNo");T.wait_for_timeout(200)
  fa=[r["a"] for r in log() if r["k"]=="flow"];ok("틀 고름" in fa and "＋2분" in fa and "다음" in fa,"수업 흐름 조작 기록 "+str(fa))
  ok("2026-10-28|t1:2:3" in json.loads(T.evaluate("localStorage.getItem('att-app-rlfp')||'{}'")),"수업 흐름 진행 중인 수업 기억")
  # 관찰
  T.click(".navb[data-v=att]");T.wait_for_timeout(200);T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(300)
  k1=T.evaluate("document.querySelector('#obsBar [data-k]').dataset.k");sid=T.evaluate("document.querySelector('#obsList [data-s]').dataset.s")
  T.click("#obsBar [data-k='%s']"%k1);T.click("#obsList [data-s='%s']"%sid);T.wait_for_timeout(100);T.click("#obsBar [data-k='%s']"%k1);T.click("#obsList [data-e='%s']"%sid);T.wait_for_timeout(300);T.click("#obNow [data-rmk='%s']"%k1);T.wait_for_timeout(200);T.click("#skNo")
  oa=[r["a"] for r in log() if r["k"]=="obs"];ok("빠른 체크 넣기" in oa and "항목 빼기(✕)" in oa,"관찰 넣기 · 빼기 "+str(oa))
  # 수업이 끝난 뒤 수업 흐름 계획 대 실제
  T.evaluate("()=>{const P=JSON.parse(localStorage.getItem('att-app-rlfp'));Object.values(P).forEach(p=>{p.date='2026-10-27'});localStorage.setItem('att-app-rlfp',JSON.stringify(P))}")
  T.reload();T.wait_for_timeout(4000)
  fe=[r for r in log() if r["k"]=="flowEnd"];ok(fe and fe[0]["tpl"].startswith("3단계") and [s_["n"] for s_ in fe[0]["steps"]]==["도입","전개","정리"] and fe[0]["steps"][0]["plan"]==5,"수업이 끝나면 단계별 계획 대 실제 "+(json.dumps(fe[0]["steps"],ensure_ascii=False) if fe else ""))
  # 설문 · 엑셀
  T.click("#topBtns .setb");T.wait_for_timeout(300);T.evaluate("document.getElementById('d-rl').open=true");T.wait_for_timeout(200);T.click("#rlSus");T.wait_for_timeout(200)
  for i,v in enumerate([5,1,5,1,5,1,5,1,5,1]):T.click("#sheetBox [data-sq='%d|%d']"%(i,v));T.wait_for_timeout(30)
  T.click("#susOk");T.wait_for_timeout(200);su=[r for r in log() if r["k"]=="sus"];ok(su and su[0]["score"]==100,"사용성 설문(SUS) 100점 계산")
  ok("[교사의생활 SUS]" in T.inner_text("#sheetBox"),"5.82.2: 설문 저장 뒤 결과 보내기 창");T.click("#skNo");T.wait_for_timeout(200)
  with T.expect_download() as dl:T.click("#rlXl")
  path=os.path.abspath("rl.xlsx");dl.value.save_as(path);wb=openpyxl.load_workbook(path)
  ok(dl.value.suggested_filename.startswith("연구용사용기록_T") and {"요약","출석 체크","연락","진도 기록","수업 관찰","수업 흐름(수업별)","수업 흐름 조작","화면 · 도구","사용성 설문","원자료"}<=set(wb.sheetnames),"연구 기록 엑셀(시트 10개) "+dl.value.suggested_filename)
  allt=" ".join(str(c.value) for ws in wb for row in ws.iter_rows() for c in row if c.value is not None)
  ok(not any(n in allt for n in ["가람","가온","다솜","10101","10102"]),"엑셀에 학생 이름 · 학번 없음")
  ok("도입 5→" in allt,"수업별 단계 계획→실제 표시")
  T.click("#rlBody [data-rl='0']");T.wait_for_timeout(100);n0=len(log());T.click(".navb[data-v=tt]");T.wait_for_timeout(200);ok(len(log())==n0,"끄면 기록 멈춤")
  # 앱 배포: 주소 · 설치 안내 복사
  T.evaluate("window.__clip='';navigator.clipboard.writeText=t=>{window.__clip=t;return Promise.resolve()}")
  T.click("#topBtns .setb");T.wait_for_timeout(300);T.evaluate("[...document.querySelectorAll('#v-set details')].forEach(d=>{if(d.querySelector('#appCopy'))d.open=true})");T.wait_for_timeout(200);T.click("#appCopy");T.wait_for_timeout(300)
  g=T.evaluate("window.__clip||''")
  ok("앱 주소: https://tl.test/" in g and "수업 흐름" in g and "아래 메뉴" in g and "0. 앱 사용 순서" in g and "Safari" in g,"주소 · 설치 안내: 새 메뉴 · 기능 · 사용 순서 안내 "+g[:40].replace("\n"," "))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
