src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
# 5.91 안정화 1차: 여러 날 행사 끝날 · 백업 알림 띠 · 학년 보관 범위 · 기기 전용 자료 백업 · 보는 기간 동기화
r1=[["10101","가람"],["10102","가온"]];r0=[["20101","나래"]]
def state():
  cells={"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-27","time":"11:00","label":"3교시 물리학","p":{"10101":True}}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c0","data":{"v":3,"cls":"작년 3반","year":2025,"term":"2학기","roster":r0,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s0","date":"2025-10-01","time":"09:00","label":"1교시","p":{"20101":True}}]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[{"id":"acx1","date":"2026-10-28","start":"08:30","end":"","cat":"교무 업무","title":"현장체험학습 (~10월 30일)","memo":"학사일정 파일에서 가져옴","clsId":"","alarm":-1,"important":False,"done":False},
      {"id":"acx2","date":"2026-12-30","start":"08:30","end":"","cat":"교무 업무","title":"겨울 방학 (~1월 2일)","memo":"","clsId":"","alarm":-1,"important":False,"done":False}],
    "evals":[],"tasks":[{"id":"tk0","k":"hw","n":"작년 과제","due":"2025-10-02","cls":["c0"],"miss":{},"at":"2025-09-30T00:00:00Z","year":2025,"term":"2학기"}],
    "recs":[{"id":"r0","k":"day","at":"2025-05-10T10:00","place":"","blocks":[{"id":"b","t":"p","x":"작년 글"}],"media":[]}],
    "plans":[{"id":"pl0","subj":"과학","year":2025,"term":"2학기","cls":["c0"],"end":"2026-02-10","units":[{"id":"u1","n":"1. 물질","ch":[{"id":"a1","t":"원자"}]}],"pg":{"c0":{"a1":{"st":"d","d":"2025-10-01"}}}},
      {"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘","ch":[{"id":"b1","t":"속력"}]}],"pg":{}}],
    "flows":[{"id":"f1","n":"내 틀","steps":[{"id":"x","n":"도입","m":10,"al":"vib","memo":"","tool":"","fix":False}]}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0');localStorage.setItem('att-app-diary',JSON.stringify({'2026-10-27':{'m':3}}));localStorage.setItem('att-app-tktpl-hw','과제 안내 문구')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2,accept_downloads=True);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1500)
  # 2 · 자료 5: 학사일정의 여러 날 행사 → 끝날
  ev={e["id"]:e for e in root(T)["events"]}
  ok(ev["acx1"].get("endDate")=="2026-10-30" and ev["acx1"]["title"]=="현장체험학습","‘(~10월 30일)’ 제목 → 끝날 2026-10-30 "+str(ev["acx1"]))
  ok(ev["acx2"].get("endDate")=="2027-01-02" and ev["acx2"]["title"]=="겨울 방학","해를 넘기는 행사도 끝날 2027-01-02")
  # 4: 출석부를 쓰는 동안 백업 알림 띠를 띄우지 않음
  ok(T.evaluate("document.documentElement.dataset.view")=="att","출석부에서 시작")
  T.wait_for_timeout(4500);ok(T.locator(".newbar.bknag").count()==0,"출석부 화면에서는 백업 알림 띠가 나오지 않음")
  T.click(".navb[data-v=tt]");T.wait_for_timeout(16500)
  ok(T.locator(".newbar.bknag").count()==1 and T.is_visible(".newbar.bknag"),"출석부를 벗어나면 띠가 나옴")
  T.click(".navb[data-v=att]");T.wait_for_timeout(300)
  ok(T.locator(".newbar.bknag").count()==0 or not T.is_visible(".newbar.bknag"),"띠가 떠 있어도 출석부로 오면 숨김")
  ok(T.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--nbpad').trim()") in ("0px",""),"숨긴 띠만큼 아래 여백을 두지 않음")
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  # 자료 2 · 3: 백업 파일에 기기 전용 자료와 보는 기간
  with T.expect_download() as dl:
    if T.locator(".newbar.bknag").count():T.click(".newbar.bknag .go")
    else:T.evaluate("()=>document.getElementById('backupFile').click()")
  bk=json.loads(open(dl.value.path(),encoding="utf-8").read())
  ex=bk.get("extra",{})
  ok("att-app-diary" in ex and "att-app-tktpl-hw" in ex and bk.get("period",{}).get("year")==2026,"백업에 기분 일기 · 과제 안내 템플릿 · 보는 기간 "+str(list(ex)))
  ok("school:master" not in json.dumps(ex),"학교 관리 원본은 넣지 않음")
  # 14 · 자료 1: 학년 보관 — 진도표 · 과제는 함께, 생활 기록은 선택(기본 끔), 흐름 틀은 사본
  def openarc():T.evaluate("()=>{document.getElementById('sheet').hidden=true;document.querySelector('.navb[data-v=set]').click();const d=document.getElementById('d-arc');d.open=true;d.dispatchEvent(new Event('toggle'))}");T.wait_for_timeout(300)
  openarc()
  ok(T.locator("#arcRec").count()==1 and not T.is_checked("#arcRec"),"생활 기록 함께 보관: 기본 끔")
  row=T.inner_text("#arcBody .arcrow >> nth=0");ok("진도표 1개" in row and "과제 1개" in row,"보관 후보에 진도표 · 과제 수 "+row.replace("\n"," "))
  T.click("[data-arcmk='2025']");T.wait_for_timeout(200);T.click("#skOk");T.wait_for_timeout(2500)
  R=root(T);ok([x["id"] for x in R["plans"]]==["pl1"] and R["tasks"]==[] and [x["id"] for x in R["recs"]]==["r0"] and [x["id"] for x in R["flows"]]==["f1"],"보관: 작년 진도표 · 과제는 옮기고, 생활 기록 · 흐름 틀은 남김")
  T.evaluate("document.getElementById('sheet').hidden=true");openarc()
  T.click("[data-arcre='2025']");T.wait_for_timeout(200);T.click("#skOk");T.wait_for_timeout(2500)
  R=root(T);pl0=[x for x in R["plans"] if x["id"]=="pl0"]
  ok(pl0 and pl0[0]["pg"]["c0"]["a1"]["st"]=="d" and [x["id"] for x in R["tasks"]]==["tk0"],"되살리기: 진도표(진도 기록 포함) · 과제가 돌아옴")
  # 생활 기록 함께 보관 켜기
  T.evaluate("document.getElementById('sheet').hidden=true");openarc();T.check("#arcRec");T.wait_for_timeout(200)
  ok("생활 기록 1개" in T.inner_text("#arcBody .arcrow >> nth=0"),"켜면 생활 기록도 보관 후보에")
  # 복원: 백업 파일로 바꾸기 → 기분 일기 · 보는 기간 되살아남
  T.evaluate("localStorage.removeItem('att-app-diary');localStorage.removeItem('att-app-tktpl-hw')")
  bk["period"]={"year":2025,"term":"2학기"}
  T.evaluate("t=>{document.getElementById('sheet').hidden=true;const f=new File([t],'x.json',{type:'application/json'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('restoreFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",json.dumps(bk));T.wait_for_timeout(800)
  T.click("#rsReplace");T.wait_for_timeout(200);T.click("#rsReplace");T.wait_for_timeout(800)
  ok(json.loads(T.evaluate("localStorage.getItem('att-app-diary')")or"{}").get("2026-10-27",{}).get("m")==3 and T.evaluate("localStorage.getItem('att-app-tktpl-hw')")=="과제 안내 문구","백업 바꾸기: 기분 일기 · 템플릿 되살아남")
  ok(root(T).get("period",{}).get("year")==2025,"백업 바꾸기: 보는 기간도 백업대로")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
