src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"]],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def flush(T):T.wait_for_timeout(560)
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script("window.__goSpy=[];window.__fileSpy=[];window.__printSpy=[];")
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-wrk','day');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  ok(T.locator(".wrnew [data-wn]").count()==1 and not any(x in T.inner_text(".wrnew") for x in ["수업자료","설문","화이트보드","서류 받기","포스트잇"]) and T.locator("[data-wt2]").count()==0,"일상 기록 새 글 단추 하나 (수업자료 · 설문 · 화이트보드 · 서류 받기 없음)")
  T.screenshot(path="shot/t138_kinds.png")
  cdp=c.new_cdp_session(T)
  def tdrag(x1,y1,x2,y2):
    bb=T.locator("#wdS").bounding_box();k=bb["width"]/1000;X=lambda v:bb["x"]+v*k;Y=lambda v:bb["y"]+v*k
    cdp.send("Input.dispatchTouchEvent",{"type":"touchStart","touchPoints":[{"x":X(x1),"y":Y(y1)}]})
    for s2 in range(1,7):cdp.send("Input.dispatchTouchEvent",{"type":"touchMove","touchPoints":[{"x":X(x1+(x2-x1)*s2/6),"y":Y(y1+(y2-y1)*s2/6)}]})
    cdp.send("Input.dispatchTouchEvent",{"type":"touchEnd","touchPoints":[]});T.wait_for_timeout(100)
  # ---- 글 안의 포스트잇 블록
  T.evaluate("document.querySelector('[data-key=\"w:day\"]').click()");T.wait_for_timeout(150);T.click("#wrCard [data-wn=day]");T.wait_for_timeout(400);T.fill("#wrTi","3단원 질문 모으기")
  def slash(sp):
    T.click("#wrEd .wbadd");T.keyboard.type("/",delay=5);T.wait_for_timeout(200);T.click(f"#wrSlash [data-sp={sp}]");T.wait_for_timeout(200)
  slash("pi");T.keyboard.type("빛은 왜 꺾일까?",delay=5);slash("pi");T.keyboard.type("무지개는?",delay=5);flush(T)
  r=root(T)["recs"][-1];P_=[x for x in r["blocks"] if x["t"]=="pi"];ok(len(P_)==2 and "무지개" in json.dumps(P_,ensure_ascii=False),"글에 포스트잇 2장")
  T.locator("#wrEd .wb.pi .wpic").nth(1).click();T.wait_for_timeout(100);flush(T)
  r=root(T)["recs"][-1];ok([x for x in r["blocks"] if x["t"]=="pi"][1].get("pc")=="#ffd6e0","포스트잇 색 바꾸기")
  T.screenshot(path="shot/t138_pi.png")
  # ---- 글 안의 링크 카드
  T.click("#wrEd .wbadd");T.click("[data-wc=ins]");T.click("#wrTool [data-bo=bm]");T.wait_for_timeout(300);T.fill("#bmU","neis.go.kr");T.fill("#bmT","나이스");T.fill("#bmN","업무 포털");T.click("#bmOk");T.wait_for_timeout(300);flush(T)
  r=root(T)["recs"][-1];bm=[x for x in r["blocks"] if x["t"]=="bm"];ok(len(bm)==1 and bm[0]["u"]=="https://neis.go.kr" and bm[0]["ti"]=="나이스","링크 카드 넣기 (주소 고침)")
  T.click("#wrEd .wbmo");T.wait_for_timeout(100);ok("https://neis.go.kr" in T.evaluate("window.__goSpy"),"링크 카드 누르면 열기")
  T.click("#wrEd .wbme");T.wait_for_timeout(200);T.fill("#bmT","나이스 (교육행정)");T.click("#bmOk");T.wait_for_timeout(300);flush(T)
  ok([x for x in root(T)["recs"][-1]["blocks"] if x["t"]=="bm"][0]["ti"]=="나이스 (교육행정)","링크 카드 고치기")
  T.screenshot(path="shot/t138_bm.png")
  T.click("#skNo");T.wait_for_timeout(300)
  # ---- 즐겨찾기 (글)
  rows=T.locator("#wrCard .wrrow");n0=rows.count()
  T.click("#wrCard [data-wf=fav]");T.wait_for_timeout(200);ok(T.locator("#wrCard .wrrow").count()==0,"즐겨찾기 없음")
  T.click("#wrCard [data-wf='']");T.wait_for_timeout(200)
  T.evaluate("(()=>{const rs=[...document.querySelectorAll('#wrCard .wrrow')];const r=rs[rs.length-1];r._sw&&0})()")
  def swipe(sel,nth):
    T.locator(sel).nth(nth).evaluate("e=>e.scrollIntoView({block:'center'})");T.wait_for_timeout(150);bb=T.locator(sel).nth(nth).bounding_box();x=bb["x"]+bb["width"]*.8;y=bb["y"]+bb["height"]/2
    cdp.send("Input.dispatchTouchEvent",{"type":"touchStart","touchPoints":[{"x":x,"y":y}]})
    for i in range(1,9):cdp.send("Input.dispatchTouchEvent",{"type":"touchMove","touchPoints":[{"x":x-280*i/8,"y":y}]});T.wait_for_timeout(16)
    cdp.send("Input.dispatchTouchEvent",{"type":"touchEnd","touchPoints":[]});T.wait_for_timeout(350)
  def tap(label):
    bb=T.locator(".swacts>button",has_text=label).bounding_box();T.touchscreen.tap(bb["x"]+bb["width"]/2,bb["y"]+bb["height"]/2);T.wait_for_timeout(400)
  swipe("#wrCard .wrrow",n0-1);tap("즐겨찾기");ok(sum(1 for r in root(T)["recs"] if r.get("fav"))==1,"밀어서 즐겨찾기")
  ok(T.locator("#wrCard [data-wf=fav]").count()==1 and T.locator("#wrCard .wrrow").first.get_attribute("data-wr")==[r for r in root(T)["recs"] if r.get("fav")][0]["id"],"즐겨찾기 글이 맨 위")
  # ---- 웹 페이지 · 발표 · 인쇄 그리기에 포스트잇 · 링크 카드
  blocks=[x for x in root(T)["recs"] if x.get("title")=="3단원 질문 모으기"][0]["blocks"]
  T.evaluate("()=>window.WRV?1:new Promise(res=>{const sc=document.createElement('script');sc.src='wrview.js';sc.onload=res;document.head.appendChild(sc)})")
  html=T.evaluate("L=>WRV.blocksHTML(L,{})",blocks)
  ok(html.count('class="wvpi"')==2 and 'class="wvpis"' in html and 'class="wvbm" href="https://neis.go.kr"' in html,"보기 · 발표 · 인쇄: 포스트잇 묶음 · 링크 카드")
  # ---- 예전 링크 모음 → ‘링크 모음’ 글로 옮김
  st=root(T);st["links"]=[{"id":"l1","u":"https://www.edunet.net","t":"에듀넷","c":"수업 자료","at":"2026-10-01"},{"id":"l2","u":"https://neis.go.kr","t":"나이스","c":"업무","f":1,"at":"2026-10-02"}]
  T.evaluate("s=>localStorage.setItem('att-app-v2',s)",json.dumps(st));T.reload();T.wait_for_timeout(1500)
  R_=root(T);lk=[x for x in R_["recs"] if x.get("title")=="링크 모음"];ok(len(lk)==1 and not R_.get("links") and lk[0].get("fav") and len([b for b in lk[0]["blocks"] if b["t"]=="bm"])==2,"예전 링크 모음은 ‘링크 모음’ 글(★)로 옮김")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
