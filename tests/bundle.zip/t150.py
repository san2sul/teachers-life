src=open('audit2.py').read();exec(src.split("sizes=")[0])
import base64
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"]],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-22T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
HW="(()=>{window.HandwritingStroke=class{constructor(){this.p=[]}addPoint(q){this.p.push(q)}};navigator.queryHandwritingRecognizer=async()=>({});navigator.createHandwritingRecognizer=async()=>({startDrawing:()=>{const s=[];return{addStroke:x=>s.push(x),getPrediction:async()=>[{text:s.length>=2?'안녕하세요\\n반갑습니다':''}],clear:()=>{}}},finish:()=>{}})})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def rec(T):return root(T)["recs"][-1]
def blocks(T):return rec(T)["blocks"]
def sel(T,sel,a,b):T.evaluate("([s,a,b])=>{const el=document.querySelector(s);const w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let n,pos=0,st=null,en=null;while(n=w.nextNode()){const L=n.nodeValue.length;if(!st&&a<=pos+L)st=[n,a-pos];if(!en&&b<=pos+L)en=[n,b-pos];pos+=L}const r=document.createRange();r.setStart(...st);r.setEnd(...en);el.focus();const S=getSelection();S.removeAllRanges();S.addRange(r)}",[sel,a,b])
def flush(T):T.wait_for_timeout(550)
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",permissions=["clipboard-read","clipboard-write"]);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(HW)
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-wrk','day');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.evaluate("document.querySelector('[data-key=\"w:day\"]').click()");T.wait_for_timeout(150);T.click("#wrCard [data-wn=day]");T.wait_for_timeout(400)
  vis=lambda s:T.evaluate(f"[...document.querySelectorAll('{s}')].filter(e=>e.offsetParent).length")
  ok(T.locator("#wrBars [data-wc]").count()==5,"편집 도구 다섯 묶음 (자주 · 문단 · 넣기 · 꾸미기 · 도구)")
  nb=vis("#wrBars button");ok(nb<=20,"한 번에 보이는 단추 %d개 (전에는 41개)"%nb)
  ok(vis("#wrFav [data-run]")==9 and T.get_attribute("[data-wc=fav]","aria-pressed")=="true","처음에는 ⭐ 자주: 기본 8개 + 모든 기능")
  ov=T.evaluate("(()=>{const e=document.querySelector('#wrBars .wrtabs');return e.scrollWidth-e.clientWidth})()");ok(ov<=1,"탭 줄이 화면 폭 안에 들어감")
  T.screenshot(path="shot/t150_fav.png")
  T.click("[data-wc=para]");T.wait_for_timeout(150)
  ok(vis("#wrBars [data-pan=para] button")==10 and vis("#wrFav button")==0 and vis("#wrFmt button")==0,"¶ 문단: 문단 단추만 펼침")
  T.click("#wrEd .wbt");T.keyboard.type("오늘 실험 정리",delay=5);flush(T)
  sel(T,"#wrEd .wbt",0,2);T.wait_for_timeout(250)
  ok(vis("#wrFmt button")==17 and vis("#wrBars [data-pan=para] button")==0,"글자를 고르면 꾸미기 도구가 저절로")
  T.screenshot(path="shot/t150_fmt.png")
  T.click("#wrFmt [data-fm=bold]");flush(T);ok("<b>" in blocks(T)[0].get("h","") or "<strong>" in blocks(T)[0].get("h",""),"바로 굵게")
  T.keyboard.press("End");T.wait_for_timeout(250);ok(vis("#wrBars [data-pan=para] button")==10,"선택을 풀면 보던 묶음(문단)으로")
  T.click("#wrTool [data-bt=h2]");T.wait_for_timeout(250);ok(T.inner_text("[data-wc=para] i")=="H2","¶ 탭에 지금 블록 종류(H2)")
  # 기능 찾기
  T.click("[data-wcmd]");T.wait_for_timeout(200);ok(T.locator("#wrCmd").is_visible(),"🔍 기능 찾기 열기")
  T.fill("#wrCmdQ","ㅍ");T.wait_for_timeout(150);L=T.inner_text("#wrCmdL");ok("표" in L and "포스트잇" in L,"초성(ㅍ)으로 찾기")
  T.fill("#wrCmdQ","형광펜");T.wait_for_timeout(150);ok(T.locator("#wrCmdL [data-ci]").first.inner_text().find("음영")>=0,"다른 이름(형광펜 → 음영)으로 찾기")
  T.fill("#wrCmdQ","표");T.keyboard.press("Enter");T.wait_for_timeout(400);flush(T)
  ok(any(x["t"]=="table" for x in blocks(T)) and not T.locator("#wrCmd").is_visible(),"Enter로 바로 실행 (표 넣기)")
  T.click("#wrEd .wb.h2 .wbt");T.keyboard.press("End");T.keyboard.press("Control+k");T.wait_for_timeout(200);ok(T.locator("#wrCmd").is_visible(),"Ctrl+K로 기능 찾기")
  T.keyboard.type("할 일",delay=5);T.keyboard.press("Enter");T.wait_for_timeout(300);flush(T);ok(any(x["t"]=="todo" for x in blocks(T)),"찾기로 블록 바꾸기(할 일), 커서 자리 그대로")
  # 자주 쓰는 기능
  for i in range(3):T.click("[data-wc=ins]");T.click("#wrTool [data-bo=math]");T.wait_for_timeout(200);T.keyboard.press("Escape");T.wait_for_timeout(150)
  T.click("[data-wc=fav]");T.wait_for_timeout(150);ok(T.get_attribute("#wrFav [data-run]","data-run")=="bo:math","많이 쓴 기능(수식)이 ⭐ 자주 맨 앞으로")
  T.click("[data-wc=tool]");T.wait_for_timeout(100)
  T.click("#skNo");T.wait_for_timeout(300);T.locator("#wrCard [data-wo]").first.click();T.wait_for_timeout(400)
  ok(T.get_attribute("[data-wc=tool]","aria-pressed")=="true" and vis("#wrTool [data-ex]")==1,"마지막에 쓰던 묶음을 기억")
  T.set_viewport_size({"width":360,"height":740});T.wait_for_timeout(200)
  ov=T.evaluate("(()=>{const e=document.querySelector('#wrBars .wrtabs');return e.scrollWidth-e.clientWidth})()");ok(ov<=1,"폭 360px에서도 탭 줄이 넘치지 않음")
  T.screenshot(path="shot/t150_tool.png")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
