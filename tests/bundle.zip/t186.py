src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  ses=lambda:[x for x in root(T)["list"][0]["data"]["sessions"] if x["id"]=="s1"][0]
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400);T.locator("#cmAtt").dispatch_event("click");T.wait_for_timeout(500)
  T.locator("#list .st").first.click();T.wait_for_timeout(300)
  s=ses();ok("10101" not in s["p"] and s.get("tm",{}).get("10101") and s["lg"][-1][:2]==["10101","결석"],"학생 칸을 누르면 그 시각을 남김 "+str(s.get("lg")))
  t0=T.inner_text("#list .st >> nth=0");ok("11:2" in t0,"학생 칸에 누른 시각 표시 "+t0.replace("\n"," "))
  T.screenshot(path="shot/t186_tile.png")
  T.locator("#list .st").first.click();T.wait_for_timeout(300);s=ses();ok(len(s["lg"])==2 and s["lg"][-1][1]=="출석","다시 누르면 출석으로 · 기록 2개")
  T.click("#attLog");T.wait_for_timeout(300);txt=T.inner_text("#sheetBox")
  import re
  ok("앱 조작 기록" in txt and "공식 출결 증빙이 아닙니다" in txt and len(re.findall(r"11:2\d:\d\d",txt))==2 and txt.index("출석")<txt.rindex("결석"),"🕒 기록: 초 단위 시각 · 최근 것부터 "+txt.replace("\n"," ")[:160])
  T.screenshot(path="shot/t186_log.png");T.click("#skNo");T.wait_for_timeout(200)
  T.click("#allOut");T.wait_for_timeout(300);s=ses();ok(len(s["lg"])==4 and all(x[1]=="결석" for x in s["lg"][-2:]),"전원 결석도 학생마다 시각 기록")
  T.reload();T.wait_for_timeout(1200);s=ses();ok(len(s.get("lg",[]))==4 and s.get("tm",{}).get("10101"),"앱을 다시 열어도 체크 시각 · 기록이 남음 "+str(len(s.get("lg",[]))))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
