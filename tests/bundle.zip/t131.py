src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ROS=[[f"101{i:02d}",f"학생{i:02d}"] for i in range(1,31)]
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ROS,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],
    "staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
def dev(b,mobile=True,man=None,touch_early=False):
  kw=dict(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul")
  if mobile:kw.update(is_mobile=True,has_touch=True,device_scale_factor=2)
  c=b.new_context(**kw);c.route("**/*",handler)
  if man:c.route("**/manifest.webmanifest*",lambda r:r.fulfill(json={"name":"x","version":man}))
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)))
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','obs');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900);return T
def openTs(T):T.click("#obsTsBox [data-ts='']");T.wait_for_timeout(300)
def vis(T,sel):return T.evaluate("s=>{const e=document.querySelector(s);if(!e||e.hidden)return false;const r=e.getBoundingClientRect();return r.height>0&&r.top>=0&&r.bottom<=innerHeight+1}",sel)
errs=[]
with sync_playwright() as p:
  b=p.chromium.launch()
  T=dev(b);openTs(T)
  ok(not T.locator("#sheet").is_hidden(),"tag summary sheet opened")
  ok(T.evaluate("document.querySelector('#sheetBox').firstElementChild.id")=="skX","× is first in the sheet")
  ok(vis(T,"#skX"),"× visible at the top without scrolling")
  ok(T.evaluate("(()=>{const b=document.querySelector('#sheetBox');return b.scrollHeight>b.clientHeight+50})()"),"sheet is long (needs scrolling)")
  ok(T.evaluate("!!document.querySelector('#skNo').closest('.skfoot')"),"닫기 row is a sticky footer")
  ok(vis(T,"#skNo"),"닫기 visible at the bottom without scrolling")
  ok(T.evaluate("document.querySelector('#sheetBox').classList.contains('skmore')"),"footer shows shadow while more content below")
  # one scroll area: inner lists don't scroll on their own
  ok(T.evaluate("[...document.querySelectorAll('#sheetBox .tslist')].every(e=>e.scrollHeight<=e.clientHeight+1)"),"inner list not a separate scroll area")
  T.evaluate("(()=>{const d=document.createElement('div');d.className='plist';d.id='pl';d.innerHTML='<p>x</p>'.repeat(80);const f=document.querySelector('#sheetBox>.skfoot');f.before(d)})()");T.wait_for_timeout(100)
  ok(T.evaluate("getComputedStyle(document.getElementById('pl')).maxHeight")=="none","phone: nested list max-height removed")
  ok(T.evaluate("getComputedStyle(document.body).overflow")=="hidden","phone: page behind sheet doesn't scroll")
  T.evaluate("document.querySelector('#sheetBox').scrollTop=99999");T.wait_for_timeout(150)
  print(T.evaluate("['#skX','#skNo'].map(s=>{const r=document.querySelector(s).getBoundingClientRect();return [r.top,r.bottom,innerHeight]})"))
  ok(vis(T,"#skX") and vis(T,"#skNo"),"× and 닫기 still visible after scrolling to the end")
  T.screenshot(path="shot/t131_end.png")
  ok(T.evaluate("document.querySelector('#sheetBox').classList.contains('sktop')"),"× gets shadow once scrolled")
  T.click("#skX");T.wait_for_timeout(250);ok(T.locator("#sheet").is_hidden(),"× closes the sheet")
  ok(T.evaluate("getComputedStyle(document.body).overflow")!="hidden","page scroll restored")
  openTs(T);ok(T.evaluate("document.querySelector('#sheetBox').scrollTop")==0,"reopened sheet starts at top")
  T.keyboard.press("Escape");T.wait_for_timeout(250);ok(T.locator("#sheet").is_hidden(),"Esc closes the sheet")
  T.wait_for_timeout(300);u0=T.url;openTs(T);T.wait_for_timeout(200);T.go_back();T.wait_for_timeout(400)
  ok(T.locator("#sheet").is_hidden() and "index.html" in T.url,"back button closes the sheet and stays in the app")
  openTs(T);T.click("#skNo");T.wait_for_timeout(500);ok(T.evaluate("!(history.state&&history.state.sk)"),"closing by button removes the back step")
  # ask() style confirm: × triggers 취소 (no action)
  T.click(".navb[data-v=att]");T.wait_for_timeout(200)
  T.evaluate("document.querySelector('#amode [data-m=write]').click()");T.wait_for_timeout(200)
  T.click("[data-wn=day]");T.wait_for_timeout(200);T.click("#wrEd .wbt");T.keyboard.type("임시",delay=10);T.click("#wrCancel");T.wait_for_timeout(200)
  ok(vis(T,"#skX"),"× on a confirm dialog");T.click("#skX");T.wait_for_timeout(250)
  ok(not T.locator("#sheet").is_hidden() and "임시" in T.inner_text("#sheetBox"),"× on confirm = 계속 쓰기 (nothing lost)")
  T.screenshot(path="shot/t131_editor.png")
  b2=p.chromium.launch()
  # desktop: no forced overflow, nested lists keep their own height
  D=dev(b2,mobile=False);openTs(D);ok(vis(D,"#skX") and vis(D,"#skNo"),"desktop: × and 닫기 visible")
  D.keyboard.press("Escape");D.wait_for_timeout(200);ok(D.locator("#sheet").is_hidden(),"desktop: Esc closes")
  # update: new version found right after opening → switch automatically
  U=dev(b2,mobile=False,man="9.0.0");U.wait_for_timeout(3500);ok("?r=" in U.url,"new version right after launch → auto refresh")
  V=dev(b2,mobile=False,man="9.0.0");V.mouse.click(5,300);V.wait_for_timeout(3000)
  ok("?r=" not in V.url and V.locator(".newbar:has-text('9.0.0')").count()==1,"if already in use → update banner instead")
  ok(V.evaluate("typeof window.__updAuto")=="function","update helper present")
  b.close();b2.close()

ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
