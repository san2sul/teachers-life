src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ROS=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"]]
def state(tt_extra):
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":"과학실"} for w in range(5)}
  cells["2-3"]={"subject":"통합과학","clsId":"c1","clsName":"","room":""}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]};t.update(tt_extra)
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ROS,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s1","date":"2026-10-21","time":"","label":"","p":{"10101":True}}]}}],
    "staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('%s').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
def dev(b,st,when,cheer=None,wx=None):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,timezone_id="Asia/Seoul");c.route("**/*",handler)
  if wx=="fail":c.route("https://api.open-meteo.com/**",lambda r:r.abort())
  elif wx:c.route("https://api.open-meteo.com/**",lambda r:(calls.append(r.request.url),r.fulfill(json=wx))[1])
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX%when);T.add_init_script(SPY)
  T.goto("https://tl.test/index.html");T.evaluate("([s,ch])=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-cheer',JSON.stringify(ch||{am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','5')}",[json.dumps(st),cheer])
  T.reload();T.wait_for_timeout(900);return T
SPY="window.__plays=[];window.__vib=[];const _p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){window.__plays.push({src:this.src,vol:this.volume});return Promise.resolve()};try{Object.defineProperty(navigator,'vibrate',{value:p=>{window.__vib.push(p);return true},configurable:true})}catch(e){}"
calls=[]
WX={"current":{"temperature_2m":-2.6,"apparent_temperature":-6,"weather_code":0},"daily":{"temperature_2m_max":[4.2],"temperature_2m_min":[-5.1]}}
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def tk(T):return root(T).get("tasks",[])
def two(extra=None):
  ST=state({"from":"2026-08-24","to":"2026-12-31"})
  c1=ST["list"][0];c1["data"]["roster"]=[[f"101{i:02d}",n] for i,n in enumerate(["가람","나래","다솜","라온"],1)]
  c2=copy.deepcopy(c1);c2["id"]="c2";c2["data"]["cls"]="1학년 2반";c2["data"]["roster"]=[[f"102{i:02d}",n] for i,n in enumerate(["마루","바다","사랑"],1)];c2["data"]["sessions"]=[]
  c3=copy.deepcopy(c2);c3["id"]="c3";c3["data"]["cls"]="1학년 3반";c3["data"]["roster"]=[["10301","아름"]]
  ST["list"]=[c1,c2,c3]
  if extra:extra(ST)
  return ST
def obsv(T,cid):
  T.evaluate("id=>{const c=S.list.find(x=>x.id===id);}",cid) if False else None
  T.click(".navb[data-v=att]");T.wait_for_timeout(100)
  T.evaluate("id=>{localStorage.setItem('att-app-amode','obs')}",cid)
def go_cls(T,name):
  T.click(".navb[data-v=att]");T.wait_for_timeout(150);T.click("#clsBtn") if T.locator("#clsBtn").count() else T.click("#cls")
  T.wait_for_timeout(200);T.click(f"#sheetBox :text-is('{name}')");T.wait_for_timeout(200)
  if T.is_visible("#sheet"):T.click("#skNo")
  T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(200)
with sync_playwright() as p:
  b=p.chromium.launch()
  E=dev(b,two(),"2026-10-22T10:30:00+09:00")
  # ---- 공통(시간표)에서 만들기 · 학급 배분
  E.click(".navb[data-v=att]");E.wait_for_timeout(150);E.evaluate("document.querySelector('[data-key=\"m:task\"]').click()");E.wait_for_timeout(200);ok(E.is_visible("#ttTasks") and "평가" in E.inner_text("#ttTasks") and "평가" in E.inner_text("#cls"),"출석 → 평가 · 과제 tab (common area)")
  ok(sorted(E.evaluate("[...document.querySelectorAll('#amode .chip')].map(b=>b.textContent)"))==sorted(["출석부","수업 관찰","출석 통계","평가 점수","학생 서명","생활 기록","업무 기록","일상 기록","학생 정보"]),"third tab next to 출석 체크 · 관찰 기록")
  E.click("#ttTkNew");E.wait_for_timeout(150);ok([x.strip() for x in E.evaluate("[...document.querySelectorAll('#tkK [data-k]')].map(b=>b.textContent)")]==["수행평가","형성평가","정기시험","과제"],"kinds: 수행평가 · 형성평가 · 정기시험 · 과제")
  E.fill("#tkN","1차 실험 보고서");E.click("#tkOk");E.evaluate("()=>{if(document.getElementById('tkScNx')){document.getElementById('skNo').click();const g=document.getElementById('tkSaGo');if(g)g.click()}}");E.wait_for_timeout(100);ok("학급을 하나 이상" in E.inner_text("#toast"),"must choose classes")
  E.click("#tkC [data-c='c1']");E.click("#tkC [data-c='c2']");E.click("#tkOk");E.evaluate("()=>{if(document.getElementById('tkScNx')){document.getElementById('skNo').click();const g=document.getElementById('tkSaGo');if(g)g.click()}}");E.wait_for_timeout(200)
  t=tk(E);ok(len(t)==1 and t[0]["k"]=="perf" and t[0]["cls"]==["c1","c2"],"created for chosen classes 1반 · 2반")
  hub=E.inner_text("#sheetBox");ok("1학년 1반" in hub and "1학년 2반" in hub and "1학년 3반" not in hub,"hub lists assigned classes only")
  E.click("[data-hc='c1']");E.wait_for_timeout(150);E.click("[data-tg='10101']");E.click("[data-tg='10102']");E.wait_for_timeout(100);E.click("#skNo");E.wait_for_timeout(150)
  ok("미참여 2명" in E.inner_text("#sheetBox"),"hub shows per-class count after checking");E.click("#skNo")
  E.screenshot(path="s542_tt.png")
  # 형성평가 · 과제 too
  E.click("#ttTkNew");E.click("#tkK [data-k=form]");E.fill("#tkN","2단원 확인 퀴즈");E.click("#tkAllC");E.click("#tkOk");E.evaluate("()=>{if(document.getElementById('tkScNx')){document.getElementById('skNo').click();const g=document.getElementById('tkSaGo');if(g)g.click()}}");E.wait_for_timeout(200);E.click("#skNo")
  ok([x for x in tk(E) if x["n"]=="2단원 확인 퀴즈"][0]["cls"]==["c1","c2","c3"],"‘모두’ assigns all classes")
  E.click("#ttTkNew");E.click("#tkK [data-k=hw]");ok("과제명" in E.inner_text("#sheetBox") and "제출 마감일" in E.inner_text("#sheetBox"),"과제: 과제명 · 마감일");E.fill("#tkN","3단원 학습지");E.click("#tkC [data-c='c2']");E.click("#tkOk");E.evaluate("()=>{if(document.getElementById('tkScNx')){document.getElementById('skNo').click();const g=document.getElementById('tkSaGo');if(g)g.click()}}");E.wait_for_timeout(200);E.click("#skNo")
  E.click("#ttTasks [data-tkf=form]");E.wait_for_timeout(100);ok(E.locator("#ttTasks .tkrow").count()==1,"filter by kind")
  E.click("#ttTasks [data-tkf='']");E.wait_for_timeout(100);E.screenshot(path="s542_tab.png")
  # ---- 학급 관찰 기록과 연동
  go_cls(E,"1학년 1반")
  card=E.inner_text("#tkCard");print("  1반:",card.replace("\n"," | "));ok("1차 실험 보고서" in card and "2단원 확인 퀴즈" in card and "3단원 학습지" not in card,"class view shows only this class's items")
  ok("공통 2개 학급" in card and "미참여 2명" in card,"same records as common area")
  E.click("#tkCard .tkrow:has-text('1차 실험')");E.wait_for_timeout(150);ok("미참여" in E.inner_text("[data-tg='10101']"),"checks made in 시간표 appear in class");E.click("[data-tg='10103']");E.wait_for_timeout(100)
  E.click("#tkEditB");E.wait_for_timeout(150);sh=E.inner_text("#sheetBox");ok("(공통)에서 고칩니다" in sh and E.locator("#tkOk").count()==0 and E.locator("#tkC").count()==0,"shared item: class view can't rename or reassign other classes")
  E.click("#skNo");E.wait_for_timeout(100);E.click("#skNo")
  ok([x for x in tk(E) if x["n"]=="1차 실험 보고서"][0]["miss"]["c1"].get("10103")=="m","class-view check saved to the shared record")
  # create in class → this class only
  E.click("#tkNew");E.wait_for_timeout(100);ok(E.locator("#tkC").count()==0,"class view: no class picker");E.fill("#tkN","1반 보충 과제");E.click("#tkK [data-k=hw]");E.fill("#tkN","1반 보충 과제");E.click("#tkOk");E.evaluate("()=>{if(document.getElementById('tkScNx')){document.getElementById('skNo').click();const g=document.getElementById('tkSaGo');if(g)g.click()}}");E.wait_for_timeout(150);E.click("#skNo")
  x=[x for x in tk(E) if x["n"]=="1반 보충 과제"][0];ok(x["cls"]==["c1"],"created in class → assigned to this class only")
  E.click(".navb[data-v=att]");E.wait_for_timeout(150);E.evaluate("document.querySelector('[data-key=\"m:task\"]').click()");E.wait_for_timeout(200);ok("1반 보충 과제" in E.inner_text("#ttTasks") and "1학년 1반" in E.inner_text("#ttTasks .tkrow:has-text('1반 보충')"),"appears in common area")
  # common area: add class 2 to it → shows in 2반
  E.click("#ttTasks .tkrow:has-text('1반 보충')");E.click("#hbEdit");E.click("#tkC [data-c='c2']");E.click("#tkOk");E.evaluate("()=>{if(document.getElementById('tkScNx')){document.getElementById('skNo').click();const g=document.getElementById('tkSaGo');if(g)g.click()}}");E.wait_for_timeout(150);E.click("#skNo")
  go_cls(E,"1학년 2반");ok("1반 보충 과제" in E.inner_text("#tkCard"),"assigning in common area reflects in class view")
  # class view: remove shared item from this class only
  E.click("#tkCard .tkrow:has-text('1차 실험')");E.click("#tkEditB");E.click("#tkDel");E.click("#tkDel");E.wait_for_timeout(150)
  x=[x for x in tk(E) if x["n"]=="1차 실험 보고서"][0];ok(x["cls"]==["c1"] and "c2" not in x["miss"] and x["miss"]["c1"].get("10101")=="m","removed from 2반 only; 1반 data untouched")
  ok("1차 실험" not in E.inner_text("#tkCard"),"gone from 2반 view")
  # class view: delete own (single-class) item → deleted everywhere
  E.click("#tkNew");E.fill("#tkN","2반 발표");E.click("#tkOk");E.evaluate("()=>{if(document.getElementById('tkScNx')){document.getElementById('skNo').click();const g=document.getElementById('tkSaGo');if(g)g.click()}}");E.wait_for_timeout(150);E.click("#tkEditB");E.click("#tkDel");E.click("#tkDel");E.wait_for_timeout(150)
  ok(not any(x["n"]=="2반 발표" for x in tk(E)),"class-only item deleted completely")
  # common area: delete → gone from classes, undo
  E.click(".navb[data-v=att]");E.wait_for_timeout(150);E.evaluate("document.querySelector('[data-key=\"m:task\"]').click()");E.wait_for_timeout(200);E.click("#ttTasks .tkrow:has-text('2단원')");E.click("#hbEdit");E.click("#tkDel");E.click("#tkDel");E.wait_for_timeout(150)
  ok(not any(x["n"]=="2단원 확인 퀴즈" for x in tk(E)),"deleted in common area");E.click("#utoast button");E.wait_for_timeout(150);ok(any(x["n"]=="2단원 확인 퀴즈" for x in tk(E)),"undo delete")
  # reassign: removing a class that has checks asks first
  E.click("#ttTasks .tkrow:has-text('1차 실험')");E.click("#hbEdit");E.click("#tkC [data-c='c1']");E.click("#tkC [data-c='c3']");E.click("#tkOk");E.evaluate("()=>{if(document.getElementById('tkScNx')){document.getElementById('skNo').click();const g=document.getElementById('tkSaGo');if(g)g.click()}}");E.wait_for_timeout(150)
  ok("체크 기록도 함께 지워집니다" in E.inner_text("#sheetBox"),"warns before dropping a class with checks");E.click("#skOk");E.wait_for_timeout(150)
  x=[x for x in tk(E) if x["n"]=="1차 실험 보고서"][0];ok(x["cls"]==["c3"] and "c1" not in x["miss"],"reassigned to 3반")
  E.reload();E.wait_for_timeout(800);ok(len(tk(E))==4,"persists after reload")
  E.click(".navb[data-v=rec]");E.wait_for_timeout(150);ok(E.is_visible("#ttTasks"),"평가 · 과제 tab remembered after reload")
  E.click("#tkMine");E.wait_for_timeout(100);ok(E.locator("#ttTasks .tkrow").count()<4,"‘이 학급만’ filter")
  E.click(".navb[data-v=tt]");E.wait_for_timeout(200);ok(E.locator("#v-tt #ttTasks").count()==0,"no longer in 시간표")
  b.close()
  # ---- 5.41 학급 자료 옮기기
  def legacy(ST):ST["list"][0]["data"]["tasks"]=[{"id":"old1","k":"hw","n":"예전 과제","due":"2026-10-20","miss":{"10101":"m"},"at":"2026-10-20T00:00:00Z"}]
  b=p.chromium.launch();G=dev(b,two(legacy),"2026-10-22T10:30:00+09:00");go_cls(G,"1학년 1반")
  ok("예전 과제" in G.inner_text("#tkCard"),"5.41 class items still shown");G.wait_for_timeout(200)
  r=root(G);ok(any(x["id"]=="old1" and x["cls"]==["c1"] and x["miss"]["c1"]["10101"]=="m" for x in r.get("tasks",[])) and not r["list"][0]["data"].get("tasks"),"migrated into the common list")
  b.close()
print("fails",F);print(errs)
