src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s0","date":"2026-10-26","time":"10:00","label":"2교시 물리학","p":{"10101":True,"10102":False},"src":"t1:0:2"},{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses,"obs":[{"id":"o1","sid":"10102","date":"2026-10-26","tags":{"a2":1},"memo":"","at":1}]}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "flowCfg":{"auto":True},"flows":[{"id":"f1","n":"세부 시험 흐름","steps":[{"id":"s1","n":"도입","m":5,"al":"vib"},{"id":"s2","n":"전개","m":35,"al":"vib","subs":[{"id":"u1","n":"개념 설명","m":10},{"id":"u2","n":"탐구 활동","m":15,"al":"vib"},{"id":"u3","n":"토의 · 토론","m":10}]},{"id":"s3","n":"정리","m":10,"al":"vib"}]}],"flowSub":{"물리학":"f1"},"events":[{"id":"e9","date":"2026-10-26","endDate":"2026-10-28","start":"12:55","end":"13:30","cat":"학생 면담","title":"기간 상담 주간","memo":"","clsId":"","alarm":-1,"important":True,"done":False},{"id":"e1","date":"2026-10-28","start":"16:00","end":"","cat":"기타","title":"알림 있는 일정","memo":"","clsId":"","alarm":10,"important":False,"done":False}],"notes":{"t1:0:2:2026-10-26":{"progress":"1-2 가속도 (반만)","memo":"실험 보고서 걷기","date":"2026-10-26","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":2,"updated":1}},"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"},"a2":{"st":"h","d":"2026-10-26","k":"t1:0:2:2026-10-26"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
errs=[]
def tt(T):return root(T)["tt"]["list"][0]
def d1(T):return root(T)["list"][0]["data"]
def cellT(T,d,p):return T.inner_text("table.ttg .tc[data-d='%d'][data-p='%d']"%(d,p))
errs=[]
D5=["2026-10-26","2026-10-27","2026-10-28","2026-10-29","2026-10-30"]
def acts(T):return {k:v["n"] for k,v in root(T)["tt"]["list"][0].get("acts",{}).items() if k.startswith("lunch|")}
def row(T):return [T.inner_text("table.ttg button[data-slot='lunch'][data-date='%s']"%d) for d in D5]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},has_touch=True,service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1200)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  if T.locator("[data-tm=week]").count():T.click("[data-tm=week]");T.wait_for_timeout(300)
  r0=row(T);ok(["기간 상담" in x for x in r0]==[True,True,True,False,False],"기간 일정(10/26~28): 시간표 점심 칸에 사흘 모두 보임 "+str(r0))
  ok(T.locator("table.ttg .imp-dot").count()==3,"중요 표시도 기간의 날마다")
  T.click("[data-tm=day]");T.wait_for_timeout(300);ok("기간 상담 주간" in T.inner_text("#ttGrid"),"하루 보기(10/28)에도 기간 일정");T.click("[data-tm=week]");T.wait_for_timeout(300)
  T.click("table.ttg button[data-slot='lunch'][data-date='2026-10-27']");T.wait_for_timeout(300);ok("기간 상담 주간" in T.inner_text("#sheetBox .evlist"),"가운데 날 칸을 눌러도 그 일정이 보임");T.click("#skNo");T.wait_for_timeout(200)
  T.click("table.ttg button[data-slot='lunch'][data-date='2026-10-26']");T.wait_for_timeout(300)
  ok(T.get_attribute("#actDays [data-wd='0']","aria-pressed")=="true" and T.locator("#actDays [aria-pressed=true]").count()==1,"처음엔 누른 요일(월)만 골라져 있음")
  T.fill("#actN","점심 상담");T.locator("#actN").focus()
  T.click("#actAll");T.wait_for_timeout(100)
  ok(T.locator("#actDays [data-wd][aria-pressed=true]").count()==5 and "월~금" in T.inner_text("#actOk"),"‘월~금 모두’ → 다섯 요일 모두 골라지고 저장 단추에 ‘월~금’ "+T.inner_text("#actOk"))
  T.screenshot(path="shot/t183_days.png")
  T.click("#actOk");T.wait_for_timeout(300)
  ok(acts(T)=={"lunch|%d"%x:"점심 상담" for x in range(5)} and all("점심 상담" in r for r in row(T)),"월~금 모두 저장되고 시간표 다섯 칸에 보임 "+str(row(T)))
  T.click("table.ttg button[data-slot='lunch'][data-date='2026-10-28']");T.wait_for_timeout(300)
  ok(T.locator("#actDays [data-wd][aria-pressed=true]").count()==5,"다시 열면 같은 활동이 있는 요일이 골라져 있음")
  T.click("#actDays [data-wd='0']");T.click("#actDays [data-wd='4']");T.wait_for_timeout(100);ok("화 · 수 · 목" in T.inner_text("#actOk"),"요일 하나씩 빼기 "+T.inner_text("#actOk"))
  T.click("#actOk");T.wait_for_timeout(300)
  ok(set(acts(T))=={"lunch|1","lunch|2","lunch|3"},"뺀 요일(월 · 금)은 지워지고 화~목만 남음 "+str(acts(T)))
  T.click("table.ttg button[data-slot='lunch'][data-date='2026-10-26']");T.wait_for_timeout(300)
  ok(T.is_visible("#actDel") and "화 금" not in T.inner_text("#actNow") and "화 점심 상담" in T.inner_text("#actNow"),"활동 없는 요일을 눌러도 지금 넣은 요일이 보이고 지우기 단추 있음")
  T.click("#actDays [data-wd='0']");T.click("#actDays [data-wd='1']");T.click("#actDays [data-wd='2']");T.wait_for_timeout(100);T.click("#actDel");T.wait_for_timeout(300)
  ok(set(acts(T))=={"lunch|3"},"고른 요일(화 · 수)만 지우기 "+str(acts(T)))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
