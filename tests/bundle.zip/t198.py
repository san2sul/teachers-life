src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
# 5.93.4 ‘출석 체크 이어서’는 기록 · 관찰이 아니라 그 반 출석부로
# (참고) 5.91 안정화 2 · 3차: 수업 설정 한 곳 · 지우기 방식 · 학생 창 · 오늘 화면 정리 · 숨은 동작 안내 · 용어
r1=[["10101","가람"],["10102","가온"],["10103","나래"]]
def state():
  cells={"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"3-4":{"subject":"물리학","clsId":"c1","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[{"id":"e1","date":"2026-10-28","start":"15:00","end":"16:00","cat":"학생 면담","title":"가람 면담","memo":"","clsId":"","alarm":-1,"important":False,"done":False}],
    "evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘","ch":[{"id":"a1","t":"속력"},{"id":"a2","t":"가속도"}]}],"pg":{}}],
    "period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','todo');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1500)
  mode=lambda:T.evaluate("localStorage.getItem('att-app-amode')")
  def back_to_write():
    T.click(".navb[data-v=rec]");T.wait_for_timeout(500)
    if mode()!="write":T.evaluate("()=>{const e=document.querySelector('[data-key=\\'w:day\\']');if(e)e.click()}");T.wait_for_timeout(300)
  back_to_write();ok(mode()=="write","기록 메뉴를 마지막으로 씀 ("+str(mode())+")")
  # 1. 시간표 칸 → 출석 체크 이어서
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  if T.is_visible("#ttProg"):T.click("#ttPnBtn");T.wait_for_timeout(300)
  if not T.is_visible(".tc[data-d='2'][data-p='3']"):T.click(".ttmode [data-tm=week]");T.wait_for_timeout(300)
  T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400)
  ok("이어서" in T.inner_text("#cmAtt"),"칸 창: "+T.inner_text("#cmAtt"))
  T.click("#cmAtt");T.wait_for_timeout(700)
  ok(T.evaluate("document.documentElement.dataset.view")=="att" and mode()=="att" and T.is_visible("#list .st") and "1학년 1반" in T.inner_text("#cls"),"시간표 ‘출석 체크 이어서’ → 그 반 출석부(기록 아님) "+str(mode()))
  ok("3교시" in T.inner_text("#sesCard"),"그 수업 출석 체크가 골라짐")
  # 2. 오늘 화면 수업 줄 → 같은 창 → 출석 체크 이어서
  back_to_write();T.click(".navb[data-v=todo]");T.wait_for_timeout(500)
  row=T.locator("#v-todo .tdl.now, #v-todo .tdl").first
  if row.count():
    row.click();T.wait_for_timeout(500)
    if T.locator("#cmAtt").count() and T.is_visible("#cmAtt"):T.click("#cmAtt")
    T.wait_for_timeout(700)
    ok(T.evaluate("document.documentElement.dataset.view")=="att" and mode()=="att" and T.is_visible("#list .st"),"오늘 화면 수업 → 출석부(기록 아님) "+str(mode()))
  else:ok(False,"오늘 화면에 수업 줄이 없음")
  # 3. 오늘 ‘지금 수업’ 카드 → 수업 열기
  back_to_write();T.click(".navb[data-v=todo]");T.wait_for_timeout(500)
  if T.locator("#v-todo .nowhero [data-nhgo]").count():
    T.click("#v-todo .nowhero [data-nhgo]");T.wait_for_timeout(700)
    ok(T.evaluate("document.documentElement.dataset.view")=="att" and mode()=="att" and T.is_visible("#list .st"),"지금 수업 카드 → 출석부(기록 아님)")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
