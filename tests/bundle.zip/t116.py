src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy,re
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def M(T,key="school:master"):return T.evaluate("k=>new Promise(r=>{const q=indexedDB.open('teachers-life-media');q.onsuccess=()=>{const g=q.result.transaction('m').objectStore('m').get('kv:'+k);g.onsuccess=()=>r(g.result?JSON.parse(g.result):null)}})",key)
def st(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
EMPTY={"active":"c0","list":[{"id":"c0","data":{"v":3,"cls":"","roster":[],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
ADM=copy.deepcopy(EMPTY);ADM["tt"]["acal"]=[{"g":"x1","from":"2026-11-04","to":"2026-11-04","title":"체육대회","kind":"event"},{"g":"x2","from":"2026-11-19","to":"2026-11-19","title":"수능 휴업","kind":"cancel"},{"g":"x3","from":"2025-11-19","to":"2025-11-19","title":"작년 행사","kind":"event"}]
def dev(b,state,touch=False):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,has_touch=touch);c.route("**/*",handler);T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)))
  T.goto("https://tl.test/index.html");T.evaluate("s=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');if(!localStorage.getItem('att-app-ui'))localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));if(!localStorage.getItem('att-app-clsal'))localStorage.setItem('att-app-clsal','0');localStorage.setItem('att-app-setup','1')}",json.dumps(state));T.reload();T.wait_for_timeout(700);return T
def admin_setup(T,school="물리고등학교"):
  T.click(".navb[data-v=set]");T.evaluate("()=>{document.getElementById('d-school').open=true}");T.click("#schOpen");T.check("#schAgree");T.click("#schOnBtn");T.wait_for_timeout(400)
  T.set_input_files("#schFile","schf/v1.xlsx");T.wait_for_timeout(1200);T.click("#schGo");T.wait_for_timeout(400)
  T.fill("#schName",school);T.evaluate("document.getElementById('schName').dispatchEvent(new Event('change'))");T.wait_for_timeout(300)
def setpage(T):T.evaluate("()=>{document.getElementById('sheet').hidden=true;document.querySelector('.navb[data-v=set]').click();document.getElementById('d-pack').open=true}");T.wait_for_timeout(150)
def openfile(T,text):
  setpage(T);T.evaluate("t=>{const f=new File([t],'pack.json',{type:'application/json'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('packFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",text);T.wait_for_timeout(900)
def by(s,n):return [c for c in s["list"] if c["data"].get("cls")==n]
with sync_playwright() as p:
  b=p.chromium.launch()
  A=dev(b,ADM);admin_setup(A)
  A.click("[data-st=asg]");A.wait_for_timeout(200);A.set_input_files("#asgFile","schf/asg_list.xlsx");A.wait_for_timeout(1000);A.click("#asgGo");A.wait_for_timeout(400)
  ok("2건" in A.inner_text("label:has(#opAc)"),"admin card shows this year's 학사일정 count (2, last year's excluded)")
  ok(A.is_hidden("#pickOpt"),"pick options hidden until 선택 방식 chosen")
  A.check("#opMP");A.wait_for_timeout(150);ok(A.is_visible("#pickOpt") and A.is_checked("#opMA"),"both modes on")
  with A.expect_download() as dl:A.click("#packMake")
  A.wait_for_timeout(600);pack=open(dl.value.path(),encoding="utf-8").read();P=json.loads(pack);m=M(A)
  nk=len(set((s["grade"],s["cls"]) for s in m["students"] if s.get("st","재학")=="재학"))
  ok(len(P["entries"])==3 and P["pick"] and len(P["pick"]["classes"])==nk and P["pick"]["common"]["ct"],"one file carries both: %d personal entries + %d class sections"%(len(P["entries"]),len(P["pick"]["classes"])))
  names=[s["name"] for s in m["students"]][:60];ok(not any(n in pack for n in names) and "010-" not in pack and "체육대회" not in pack,"nothing readable in the file (names, phones, 학사일정)")
  code=m.get("pickCode");ok(code and re.match(r"^[0-9A-Z]{4}-[0-9A-Z]{4}$",code) and A.inner_text("#pickCode")==code,"school code made and shown: "+str(code))
  kcodes={t["name"]:t["code"] for t in m["staff"] if t.get("code")}
  # ---- teacher B: sets own classes first ----
  B=dev(b,EMPTY,touch=True);setpage(B)
  ok("아직 정하지 않았습니다" in B.inner_text("#packBody"),"my classes empty at first")
  B.click("#myCls");B.fill("#mcHr","1학년 2반");B.click("#mcAdd");B.fill("[data-sj='0']","물리학");B.fill("[data-cl='0']","1-1, 103");B.click("#mcOk");B.wait_for_timeout(200)
  mc=json.loads(B.evaluate("localStorage.getItem('att-app-myclasses')"));ok(mc=={"hr":"1-2","teach":[{"subj":"물리학","cls":["1-1","1-3"]}]},"my classes saved: "+json.dumps(mc,ensure_ascii=False))
  openfile(B,pack);B.click("#pkOk");B.wait_for_timeout(200);sh=B.inner_text("#sheetBox");ok("개인 코드로 받기" in sh and "학교 공용 코드" in sh,"both modes offered")
  B.click("#pmP");B.wait_for_timeout(200)
  on=B.evaluate("[...document.querySelectorAll('#pcList [aria-pressed=true]')].map(b=>b.dataset.k)");ok(sorted(on)==["1-1","1-2","1-3"],"my classes pre-selected: "+str(on))
  ok(B.evaluate("document.getElementById('pcHr').value")=="1-2","homeroom pre-selected")
  B.fill("#pcCode",kcodes["김물리"]);B.click("#pcGo");B.wait_for_timeout(700);ok("맞지 않습니다" in B.inner_text("#pcMsg"),"personal code does not open the school-code part")
  B.fill("#pcCode",code.lower());B.click("#pcGo");B.wait_for_timeout(900);sh=B.inner_text("#sheetBox");print("  preview:",sh[:300].replace("\n"," | "))
  ok("선택 방식" in sh and "1학년 1반" in sh and "1학년 3반" in sh and "2학년" not in sh,"only chosen classes opened")
  ok("연락처 포함" not in sh and "학사일정 2건" in sh and "교직원 연락망" not in sh,"pick default: no contacts, 학사일정 included")
  B.click("#pkApply");B.wait_for_timeout(600);s=st(B)
  sc=[c for c in s["list"] if c["data"].get("sch")];ok(len(sc)==3,"3 classes created")
  ok(by(s,"1학년 2반")[0]["data"]["sch"]["role"]=="담임" and by(s,"1학년 1반")[0]["data"]["sch"]["subj"]==["물리학"],"roles/subjects from my settings")
  ok(all(not c["data"]["phones"] for c in sc),"no phone numbers in pick mode")
  t11=by(s,"1학년 1반")[0]["data"]["teachers"];print("  1-1 teachers:",t11)
  ok(any(t["name"]=="김물리" and t["role"]=="담임" for t in t11) and all(t.get("src")=="school" and not t["phone"] for t in t11),"subject/homeroom teachers of the class filled (no phones)")
  ev=[e for e in s["events"] if e["title"].startswith("체육대회")];ok(len(ev)==1 and ev[0]["date"]=="2026-11-04","학사일정 → 일정 (체육대회)")
  chg=[c for t in s["tt"]["list"] for c in t.get("chg",[]) if c.get("reason")=="수능 휴업"];ok(len(chg)>=1,"학사일정 → 시간표 휴업 변동")
  ok(not any(e["title"].startswith("작년") for e in s["events"]),"last year's 학사일정 not sent")
  R=json.loads(B.evaluate("localStorage.getItem('att-app-schpack')"));ok(R["mode"]=="pick" and len(R["cls"])==3 and len(R["acal"])==2,"receipt records what came in")
  # Google calendar path: event exportable via ICS
  ok(B.evaluate("typeof icsOf==='function'||typeof evIcs==='function'||!!document.querySelector('[id*=ics],[id*=Ics],[id*=gcal]')"),"calendar export present")
  # attendance on homeroom
  B.click(".navb[data-v=att]");B.wait_for_timeout(200);B.evaluate("()=>{const b=document.getElementById('startSes');if(!b.closest('[hidden]'))b.click();else document.querySelector('#tabs .tab.add').click()}");B.wait_for_timeout(300)
  nses=len(by(st(B),"1학년 2반")[0]["data"]["sessions"]);ok(nses>=1,"attendance recorded on homeroom")
  # ---- reset ----
  setpage(B);sh=B.inner_text("#packBody");ok("선택 방식" in sh and "학급 3개" in sh and "학사일정 2건" in sh,"received-info summary shown")
  B.click("#pkReset");B.wait_for_timeout(200);sh=B.inner_text("#sheetBox");ok("기록이 있는 학급 1개" in sh and "1학년 2반" in sh,"reset explains record-holding class is kept")
  B.click("#rsGo");B.click("#rsGo");B.wait_for_timeout(400);s=st(B)
  ok(not by(s,"1학년 1반") and not by(s,"1학년 3반"),"empty received classes removed")
  k2=by(s,"1학년 2반");ok(k2 and len(k2[0]["data"]["sessions"])==nses and not k2[0]["data"].get("sch") and not k2[0]["data"]["teachers"],"homeroom kept with its attendance, school link + received teachers removed")
  ok(not [e for e in s["events"] if e["title"].startswith("체육대회")] and not [c for t in s["tt"]["list"] for c in t.get("chg",[]) if c.get("reason")=="수능 휴업"] and not s["tt"].get("acal"),"received 학사일정 removed (events + timetable changes)")
  ok(B.evaluate("localStorage.getItem('att-app-schpack')") is None,"receipt cleared when everything reset")
  # ---- 다시 받기 (stored pack) ----
  setpage(B);ok("지난 학교 묶음 다시 받기" in B.inner_text("#packBody"),"after full reset: 다시 받기 still offered")
  B.click("#pkRedo");B.wait_for_timeout(500);B.click("#pmP");B.wait_for_timeout(200);B.fill("#pcCode",code);B.click("#pcGo");B.wait_for_timeout(900)
  ok("이미 있는 학급" in B.inner_text("#sheetBox"),"re-receive: existing homeroom recognised");B.click("#pkApply");B.wait_for_timeout(600);s=st(B)
  ok(len([c for c in s["list"] if c["data"].get("sch")])==3 and len(by(s,"1학년 2반"))==1 and len(by(s,"1학년 2반")[0]["data"]["sessions"])==nses,"re-received: 3 classes, no duplicate, attendance kept")
  # ---- undo ----
  setpage(B);B.click("#pkUndo");B.wait_for_timeout(300);ok("받기 전으로" in B.inner_text("#sheetBox"),"undo confirm");B.click("#skOk");B.wait_for_timeout(500);s=st(B)
  ok(len([c for c in s["list"] if c["data"].get("sch")])==0 and len(by(s,"1학년 2반"))==1 and not [e for e in s["events"] if e["title"].startswith("체육대회")],"undo: back to state before this receive")
  B.reload();B.wait_for_timeout(600);ok(len([c for c in st(B)["list"] if c["data"].get("sch")])==0,"undo persisted after reload")
  # ---- assign mode also carries 학사일정 + class teachers ----
  C=dev(b,EMPTY);openfile(C,pack);C.click("#pkOk");C.wait_for_timeout(200);C.click("#pmA");C.wait_for_timeout(200)
  C.click("#pkList [data-t] >> text=이수학");C.fill("#pkCode",kcodes["이수학"]);C.click("#pkGo");C.wait_for_timeout(900);sh=C.inner_text("#sheetBox")
  ok("이수학 선생님께 온 학급" in sh and "학사일정 2건" in sh and "배정 방식" in sh,"assign mode: 학사일정 included")
  C.click("#pkApply");C.wait_for_timeout(500);s=st(C);t22=by(s,"2학년 2반")[0]["data"]["teachers"]
  ok(not any(t["name"]=="이수학" for t in t22) and len(t22)>=1,"own name excluded from class teachers: "+str([t["name"] for t in t22]))
  ok(json.loads(C.evaluate("localStorage.getItem('att-app-schpack')"))["mode"]=="assign","assign receipt")
  # stripping the pick section breaks the signature
  O=json.loads(pack);O.pop("pick");openfile(C,json.dumps(O,ensure_ascii=False))
  ok("열 수 없는" in C.inner_text("#sheetBox"),"removing the pick section breaks the signature → refused")
  b.close()
print("fails",F);print(errs)
