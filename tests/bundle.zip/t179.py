src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses,"obs":[{"id":"o1","sid":"10102","date":"2026-10-26","tags":{"a2":1},"memo":"","at":1}]}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "flowCfg":{"auto":True},"flows":[{"id":"f1","n":"세부 시험 흐름","steps":[{"id":"s1","n":"도입","m":5,"al":"vib"},{"id":"s2","n":"전개","m":35,"al":"vib","subs":[{"id":"u1","n":"개념 설명","m":10},{"id":"u2","n":"탐구 활동","m":15,"al":"vib"},{"id":"u3","n":"토의 · 토론","m":10}]},{"id":"s3","n":"정리","m":10,"al":"vib"}]}],"flowSub":{"물리학":"f1"},"events":[{"id":"e1","date":"2026-10-28","start":"16:00","end":"","cat":"기타","title":"알림 있는 일정","memo":"","clsId":"","alarm":10,"important":False,"done":False}],"notes":{"t1:0:2:2026-10-26":{"progress":"1-2 가속도 (반만)","memo":"실험 보고서 걷기","date":"2026-10-26","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":2,"updated":1}},"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"},"a2":{"st":"h","d":"2026-10-26","k":"t1:0:2:2026-10-26"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},has_touch=True,is_mobile=True,service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  cdp=c.new_cdp_session(T)
  def touch(sel,dx=-260,nth=0):
    T.locator(sel).nth(nth).evaluate("e=>e.scrollIntoView({block:'center'})");T.wait_for_timeout(150)
    bb=T.locator(sel).nth(nth).bounding_box();x=bb["x"]+bb["width"]*0.8;y=bb["y"]+bb["height"]/2
    cdp.send("Input.dispatchTouchEvent",{"type":"touchStart","touchPoints":[{"x":x,"y":y}]})
    for i in range(1,9):cdp.send("Input.dispatchTouchEvent",{"type":"touchMove","touchPoints":[{"x":x+dx*i/8,"y":y}]});T.wait_for_timeout(16)
    cdp.send("Input.dispatchTouchEvent",{"type":"touchEnd","touchPoints":[]});T.wait_for_timeout(350)
  def acts():return T.evaluate("[...document.querySelectorAll('.swacts:not([hidden])>button')].map(b=>b.textContent.trim())")
  def tap(label):
    bb=T.locator(".swacts>button",has_text=label).bounding_box();T.touchscreen.tap(bb["x"]+bb["width"]/2,bb["y"]+bb["height"]/2);T.wait_for_timeout(450)
  ev=lambda i:[e for e in root(T)["events"] if e["id"]==i][0]
  # 4. 수업 흐름 세부 과정 — 지금(11:20) 전개 › 탐구 활동
  T.click(".navb[data-v=todo]");T.wait_for_timeout(1300)
  fb=T.inner_text("#v-todo .nowhero [data-flowbox]").replace("\n"," ");ok("전개" in fb and "2/3 탐구 활동" in fb and "다음 · 토의 · 토론" in fb,"수업 흐름 카드: 지금 세부 과정 · 남은 시간 · 다음 "+fb[:120])
  # 1. 관찰 → 그때 수업 상황
  T.click(".navb[data-v=att]");T.wait_for_timeout(200);T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(300)
  T.click("#obsBar [data-k=a1]");T.wait_for_timeout(150);T.click("#obsList [data-s='10101']");T.wait_for_timeout(300)
  r=[x for x in root(T)["list"][0]["data"]["obs"] if x["sid"]=="10101"][0];lg=r.get("lg",[])
  ok(len(lg)==1 and lg[0]["t"]=="11:20" and "3교시 물리학" in lg[0]["c"] and "1-2" in lg[0]["c"] and "전개 › 탐구 활동" in lg[0]["c"],"관찰에 시각 · 교시 · 진도 · 수업 단계 › 세부 과정 "+str(lg))
  T.click("#obsBar [data-k=a1]");T.wait_for_timeout(150);T.click("#obsList [data-e='10101']") if T.locator("#obsList [data-e='10101']").count() else T.click("#obsList [data-s='10101']");T.wait_for_timeout(300)
  box=T.inner_text("#sheetBox")
  ok("언제 · 어느 학습에서" in box and "11:20" in box and "탐구 활동" in box and T.locator("#obCtx").count()==1,"학생 관찰 창: 언제 · 어느 학습에서 목록 · 지금 수업 넣기")
  ok(T.locator("#obNow [data-dec]").count()==1,"5.83.1: 1회만 넣어도 −1 단추")
  T.click("#obCtx");ok("[11:20 3교시 물리학" in T.input_value("#obMemo"),"메모에 지금 수업 넣기 "+T.input_value("#obMemo")[:60])
  T.click("#sheetBox [data-dec], #sheetBox .obx >> nth=0") if T.locator("#sheetBox .obx").count() else None;T.wait_for_timeout(300)
  r=[x for x in root(T)["list"][0]["data"]["obs"] if x["sid"]=="10101"];ok(not r or not r[0].get("lg"),"잘못 누른 것 빼면 시각 기록도 함께 빠짐 "+str(r[0].get("lg") if r else None))
  T.click("#skNo");T.wait_for_timeout(200)
  # 5.83.2 빠른 체크 중 학생 칸에서 바로 −1
  T.click("#obsBar [data-k=a1]");T.wait_for_timeout(150);T.click("#obsList [data-s='10101']");T.wait_for_timeout(200);T.click("#obsList [data-s='10101']");T.wait_for_timeout(200)
  rr=lambda sid:([x for x in root(T)["list"][0]["data"]["obs"] if x["sid"]==sid and x["date"]=="2026-10-28"] or [None])[0]
  ok(rr("10101")["tags"]["a1"]==2 and T.locator("#obsList [data-m='10101']").count()==1 and T.locator("#obsList [data-m='10102']").count()==0,"빠른 체크로 넣은 학생 칸에만 −1")
  T.click("#obsList [data-m='10101']");T.wait_for_timeout(250);r1=rr("10101");ok(r1["tags"]["a1"]==1 and len(r1.get("lg",[]))==1,"학생 칸 −1 → 1회 빠짐(시각 기록도) "+str(r1))
  T.click("#obsList [data-m='10101']");T.wait_for_timeout(250);ok(rr("10101") is None and T.locator("#obsList [data-m='10101']").count()==0,"한 번 더 −1 → 기록 없음 · −1 사라짐")
  T.click("#utoast button");T.wait_for_timeout(250);ok(rr("10101") and rr("10101")["tags"]["a1"]==1,"되돌리기")
  T.click("#obsBar [data-k=a1]");T.wait_for_timeout(150)
  # 지난 기록에 손으로 시각 · 수업 넣기
  T.click("#obsList [data-e='10102']") if T.locator("#obsList [data-e='10102']").count() else T.click("#obsList [data-s='10102']");T.wait_for_timeout(300)
  T.fill("#obDate","2026-10-26");T.locator("#obDate").dispatch_event("change");T.wait_for_timeout(400)
  ok(T.locator("#obLgBox [data-lga]").count()==1 and "시각 · 수업 상황이 없는 기록" in T.inner_text("#obLgBox"),"지난 기록(시각 없음)에 ＋ 시각 · 수업 넣기")
  T.click("#obLgBox [data-lga]");T.wait_for_timeout(200);lo=T.evaluate("[...document.querySelectorAll('#obLgBox [data-lgo]')].map(b=>b.textContent)");ok(lo and "2교시 물리학" in lo[0],"그날(10/26 월) 이 학급 수업 고르기 "+str(lo))
  T.click("#obLgBox [data-lgo='0']");T.wait_for_timeout(150);ok(T.input_value("#lgT")=="10:00" and "2교시 물리학" in T.input_value("#lgC"),"수업 고르면 시각 · 수업 상황 채움 "+T.input_value("#lgC"))
  st=T.evaluate("[...document.querySelectorAll('#obLgBox [data-lgs]')].map(b=>b.textContent)");ok("전개 › 탐구 활동" in st,"수업 흐름 단계 › 세부 과정 고르기 "+str(st))
  T.click("#obLgBox [data-lgs='%d']"%st.index("전개 › 탐구 활동"));T.fill("#lgT","10:25");T.click("#lgOk");T.wait_for_timeout(250)
  o=[x for x in root(T)["list"][0]["data"]["obs"] if x["sid"]=="10102" and x["date"]=="2026-10-26"][0];ok(o.get("lg") and o["lg"][0]["t"]=="10:25" and "전개 › 탐구 활동" in o["lg"][0]["c"] and o["lg"][0].get("m")==1,"손으로 넣은 시각 · 수업 저장 "+str(o.get("lg")))
  T.click("#obLgBox [data-lge='0']");T.wait_for_timeout(150);T.fill("#lgC","직접 쓴 수업 상황: 실험 보고서 발표");T.click("#lgOk");T.wait_for_timeout(250)
  o=[x for x in root(T)["list"][0]["data"]["obs"] if x["sid"]=="10102" and x["date"]=="2026-10-26"][0];ok(o["lg"][0]["c"]=="직접 쓴 수업 상황: 실험 보고서 발표","✎ 고치기 · 직접 쓰기")
  T.click("#obCtxP");T.wait_for_timeout(150);T.click("#obCtxPick [data-mco='0']");T.wait_for_timeout(150);ok("[2교시 물리학" in T.input_value("#obMemo"),"지난 날 메모에도 수업 골라 넣기 "+T.input_value("#obMemo")[:40])
  T.click("#skNo");T.wait_for_timeout(200)
  # 4. 틀 편집: 세부 과정 넣기
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#ttPnBtn");T.wait_for_timeout(300);T.click("#flMgrB");T.wait_for_timeout(300);T.click("#flNew2");T.wait_for_timeout(300)
  T.click("#sheetBox .fled[data-j='0'] summary");T.wait_for_timeout(150)
  sug=T.evaluate("[...document.querySelectorAll('#sheetBox .fled[data-j=\"0\"] [data-sadd]')].map(b=>b.dataset.sadd)");ok("인사" in sug and "출석 확인" in sug and "이번 차시 안내" in sug,"도입 단계 추천: "+str(sug))
  T.click("#sheetBox .fled[data-j='0'] [data-sadd='인사']");T.wait_for_timeout(150);T.click("#sheetBox .fled[data-j='0'] [data-sadd='출석 확인']");T.wait_for_timeout(150)
  ok(T.locator("#sheetBox .fled[data-j='0'] .flsr2").count()==2 and T.evaluate("document.querySelector('#sheetBox .fled[data-j=\"0\"] details').open"),"세부 과정 2개 · 펼친 채로")
  T.select_option("#sheetBox .fled[data-j='0'] .flsr2 >> nth=1 >> [data-sk=al]","snd")
  sug1=T.evaluate("[...document.querySelectorAll('#sheetBox .fled[data-j=\"1\"] [data-sadd]')].map(b=>b.dataset.sadd)");ok("개념 설명" in sug1 and "에듀테크 활동" in sug1 and "토의 · 토론" in sug1,"전개 단계 추천: "+str(sug1))
  T.fill("#flN","세부 과정 틀");T.click("#flOk");T.wait_for_timeout(400)
  f=[x for x in root(T)["flows"] if x["n"]=="세부 과정 틀"];ok(f and [u["n"] for u in f[0]["steps"][0]["subs"]]==["인사","출석 확인"] and f[0]["steps"][0]["subs"][1]["al"]=="snd" and f[0]["steps"][0]["subs"][0]["al"]=="","저장: 세부 과정 · 고른 것만 알림 "+str(f[0]["steps"][0].get("subs") if f else None))
  T.keyboard.press("Escape");T.wait_for_timeout(200);T.keyboard.press("Escape");T.wait_for_timeout(200)
  # 3. 기간 일정
  T.click(".navb[data-v=todo]");T.wait_for_timeout(300);T.click("#tdAdd");T.wait_for_timeout(300)
  T.fill("#evTitle","체험학습 주간");T.fill("#evDate","2026-10-27");T.check("#evMulti");T.fill("#evEndD","2026-10-30");T.wait_for_timeout(100)
  ok("4일 동안" in T.inner_text("#evRngN"),"기간 안내 "+T.inner_text("#evRngN"))
  T.click("#evOk");T.wait_for_timeout(300);e=[x for x in root(T)["events"] if x["title"]=="체험학습 주간"][0]
  ok(e.get("endDate")=="2026-10-30","끝 날짜 저장")
  T.reload();T.wait_for_timeout(900);e=[x for x in root(T)["events"] if x["title"]=="체험학습 주간"][0];ok(e.get("endDate")=="2026-10-30","다시 열어도 끝 날짜 유지")
  T.click(".navb[data-v=todo]");T.wait_for_timeout(400);ok("체험학습 주간" in T.inner_text("#v-todo") and "10/27~10/30" in T.inner_text("#v-todo"),"기간 중인 오늘(10/28) 할 일에 보임 · 기간 표시")
  # 구글 캘린더: 먼저 저장하고 닫음
  T.click("#tdAdd");T.wait_for_timeout(300);T.fill("#evTitle","구글 보낼 일정");T.fill("#evStart","15:00")
  with c.expect_page() as pg:T.click("#evGcal")
  np=pg.value;ok("calendar.google.com" in np.url,"구글 캘린더 새 창 "+np.url[:50]);np.close()
  ok(T.locator("#sheet").is_hidden() and any(x["title"]=="구글 보낼 일정" for x in root(T)["events"]),"구글 캘린더로 가기 전에 저장하고 창 닫음")
  T.bring_to_front();T.evaluate("window.dispatchEvent(new Event('focus'))");T.wait_for_timeout(800);ok(T.is_visible("#v-todo") and T.evaluate("document.body.style.display")=="","돌아오면 화면 다시 그림(빈 화면 아님)")
  # 오늘 목록 밀어서 알림 끄기 · 켜기 · 수정 · 삭제
  row="#v-todo .td:has-text('알림 있는 일정')"
  touch(row);a=acts();ok("알림 끄기" in a and "수정" in a and "삭제" in a,"밀면 완료 · 알림 끄기 · 수정 · 삭제 "+str(a))
  tap("알림 끄기");ok(ev("e1")["alarm"]==-1 and ev("e1").get("alarmPrev")==10,"알림 끔")
  touch(row);ok("알림 켜기" in acts(),"다시 밀면 알림 켜기");tap("알림 켜기");ok(ev("e1")["alarm"]==10,"알림 다시 켬(10분 전)")
  # 2. 기록 화면 학급 줄
  T.click(".navb[data-v=rec]");T.wait_for_timeout(300);T.evaluate("document.querySelector('[data-key=\"w:day\"]').click()");T.wait_for_timeout(300)
  ok(not T.is_visible("#clsSub") and T.is_disabled("#clsBtn"),"기록 화면: 학급 고르기 줄 없음")
  T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(300);ok(T.is_visible("#clsSub") and not T.is_disabled("#clsBtn"),"수업 관찰로 가면 학급 줄 다시")
  # 5. 글쓰기 아래 단추
  T.evaluate("document.querySelector('[data-key=\"w:day\"]').click()");T.wait_for_timeout(300);T.click("#wrCard [data-wn=day]");T.wait_for_timeout(300)
  ok(T.locator("#wrTi").count()==0,"일상 기록: 제목 칸 없음(첫 줄이 제목)")
  ft=T.evaluate("(()=>{const f=document.querySelector('#sheetBox .wrfoot');return f?[...f.querySelectorAll('button')].map(b=>b.textContent.trim()).concat([f.classList.contains('skfoot')?'sticky':'flow',getComputedStyle(f).position]):null})()")
  ok(ft and ft[:2]==["취소","완료"] and ft[2]=="flow" and ft[3]!="sticky","글쓰기 아래 단추: 취소 · 완료만, 글 흐름 안 "+str(ft))
  ok(T.evaluate("(()=>{const m=document.getElementById('wrMed'),f=document.querySelector('#sheetBox .wrfoot');return !!(m&&f&&m.compareDocumentPosition(f)&4)})()"),"첨부 안내 다음에 아래 단추")
  T.click("#wrEd .wbt");T.keyboard.type("첫 줄 제목",delay=5);T.wait_for_timeout(200);T.click("#skNo");T.wait_for_timeout(300)
  touch("#wrCard .wrrow[data-wr]");a=acts();ok("전달" in a and "삭제" in a,"글 목록을 밀면 전달 · 삭제 "+str(a));T.keyboard.press("Escape");T.wait_for_timeout(200)
  # 7. 생활 기록 여러 학생 자료 참고
  T.evaluate("document.querySelector('[data-key=\"w:stu\"]').click()");T.wait_for_timeout(300);T.click("#wrCard [data-wn=stu] >> nth=0");T.wait_for_timeout(300)
  T.fill("#wrN","2");T.wait_for_timeout(150)
  T.fill("#wrStus [data-si='0'][data-sk=sid]","10101");T.locator("#wrStus [data-si='0'][data-sk=sid]").dispatch_event("change")
  T.fill("#wrStus [data-si='1'][data-sk=sid]","10102");T.locator("#wrStus [data-si='1'][data-sk=sid]").dispatch_event("change");T.wait_for_timeout(250)
  tabs=T.evaluate("[...document.querySelectorAll('#wrRef [data-refs]')].map(b=>b.dataset.refs)");ok(tabs==["10101","10102"],"학생 2명이면 자료 참고 이름 단추 2개 "+str(tabs))
  T.click("#wrRef [data-refs='10102']");T.wait_for_timeout(200);ok(T.get_attribute("#wrRef [data-refs='10102']","aria-pressed")=="true" and T.get_attribute("#wrRefAll","data-sid")=="10102","둘째 학생 자료로 바뀜")
  T.click("#wrRefAll");T.wait_for_timeout(400)
  ok(T.is_visible("#stuBackW") and T.locator("#stuBack").count()==0,"학생 화면 전체 보기 → ‹ 쓰던 기록으로 단추")
  T.click("#stuBackW");T.wait_for_timeout(500)
  ok(T.is_visible("#sheet") and T.locator("#wrRef").count()==1 and T.locator("#wrStus [data-si='1'][data-sk=sid]").input_value()=="10102","쓰던 생활 기록 창으로 돌아옴(학생 2명 그대로)")
  ok(T.locator("#wrCard [data-ws]").count()==0,"기록 목록에 전달 단추 없음(밀어서 전달)")
  T.click("#wrCancel");T.wait_for_timeout(300)
  if T.is_visible("#sheet"):T.evaluate("document.getElementById('sheet').hidden=true");T.wait_for_timeout(200)
  # 5.83.1: 이 학급 수업이 없는 날 — 지금 수업 넣기 이유 안내
  T.evaluate("(()=>{const s=JSON.parse(localStorage.getItem('att-app-v2'));s.tt.list[0].cells={};localStorage.setItem('att-app-v2',JSON.stringify(s))})()");T.reload();T.wait_for_timeout(900)
  T.click(".navb[data-v=att]");T.wait_for_timeout(200);T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(300)
  T.click("#obsList [data-e='10102']") if T.locator("#obsList [data-e='10102']").count() else T.click("#obsList [data-s='10102']");T.wait_for_timeout(400)
  ok(T.locator(".obctx button[disabled]").count()==1 and "수업이 없어" in T.inner_text(".obctx"),"수업 없는 날: 지금 수업 넣기 단추는 흐리게 · 이유 안내 "+T.inner_text(".obctx")[:60])
  T.keyboard.press("Escape");T.wait_for_timeout(200);T.evaluate("document.getElementById('sheet').hidden=true")
  # 6. 화면 켜 두기 설정
  T.click("#topBtns .setb");T.wait_for_timeout(300);T.click("#d-ui summary");T.wait_for_timeout(150);ok(T.locator("#d-ui [data-ui=wake] .chip").count()==2 and T.get_attribute("#d-ui [data-ui=wake] [data-v='']","aria-pressed")=="true","화면 꺼짐: 켜 두기(기본) · 기기 설정대로")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
