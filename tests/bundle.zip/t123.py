src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ROS=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"]]
def state(tt_extra):
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":"과학실"} for w in range(5)}
  cells["2-3"]={"subject":"통합과학","clsId":"c1","clsName":"","room":""}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]};t.update(tt_extra)
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ROS,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s1","date":"2026-10-21","time":"","label":"","p":{"10101":True}}]}}],
    "staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('%s').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
def dev(b,st,when,cheer=None,wx=None):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,timezone_id="Asia/Seoul");c.route("**/*",handler)
  if wx=="fail":c.route("https://api.open-meteo.com/**",lambda r:r.abort())
  elif wx:c.route("https://api.open-meteo.com/**",lambda r:(calls.append(r.request.url),r.fulfill(json=wx))[1])
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX%when);T.add_init_script(SPY)
  T.goto("https://tl.test/index.html");T.evaluate("([s,ch])=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-cheer',JSON.stringify(ch||{am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','5')}",[json.dumps(st),cheer])
  T.reload();T.wait_for_timeout(900);return T
SPY="window.__plays=[];window.__vib=[];const _p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){window.__plays.push({src:this.src,vol:this.volume});return Promise.resolve()};try{Object.defineProperty(navigator,'vibrate',{value:p=>{window.__vib.push(p);return true},configurable:true})}catch(e){}"
calls=[]
WX={"current":{"temperature_2m":-2.6,"apparent_temperature":-6,"weather_code":0},"daily":{"temperature_2m_max":[4.2],"temperature_2m_min":[-5.1]}}
with sync_playwright() as p:
  b=p.chromium.launch()
  ST=state({"from":"2026-08-24","to":"2026-12-31"})
  ST["list"][0]["data"]["snote"]={"10102":[{"id":"n1","k":"warn","t":"앞자리 배치 필요","at":"2026-10-20T01:00:00Z"},{"id":"n2","k":"prom","t":"다음 시간 발표 기회","at":"2026-10-21T01:00:00Z"}]}
  ST["list"][0]["data"]["low"]={"10104":1}
  E=dev(b,ST,"2026-10-22T10:30:00+09:00")
  E.click(".navb[data-v=att]");E.wait_for_timeout(200);E.evaluate("()=>{const b=document.getElementById('startSes');if(b&&!b.closest('[hidden]'))b.click();else document.querySelector('#tabs .tab.add').click()}");E.wait_for_timeout(300)
  ok(E.evaluate("getComputedStyle(document.querySelector('#list .st')).userSelect")=="none" and E.evaluate("getComputedStyle(document.querySelector('#list .st .tnm')).userSelect")=="none","long-press no longer selects text on tiles")
  t=E.locator("#list .st >> nth=1");bb=t.bounding_box();E.mouse.move(bb["x"]+20,bb["y"]+20);E.mouse.down();E.wait_for_timeout(800);E.mouse.up();E.wait_for_timeout(200)
  ok(E.evaluate("String(getSelection())")=="","nothing selected after long-press")
  if E.is_visible("#sheet"):E.click("#skNo")
  on0=E.evaluate("document.querySelectorAll('#list .st.on').length")
  E.click("#list .st >> nth=1 >> [data-snv]");E.wait_for_timeout(200)
  ok(E.is_visible("#sheet") and "앞자리 배치 필요" in E.inner_text("#sheetBox"),"tap on mark opens the notes")
  ok(E.evaluate("document.querySelectorAll('#list .st.on').length")==on0,"tap on mark did not toggle attendance");E.click("#skNo")
  E.click("#list .st >> nth=0");E.wait_for_timeout(100);ok(E.evaluate("document.querySelectorAll('#list .st.on').length")!=on0,"tap elsewhere still toggles attendance")
  ok(E.is_visible("#snAllBtn") and "2명" in E.inner_text("#snAllBtn"),"overview button with count")
  E.click("#snAllBtn");E.wait_for_timeout(200);ov=E.inner_text("#sheetBox");ok("나래" in ov and "앞자리 배치 필요" in ov and "다음 시간 발표 기회" in ov and "라온" in ov and "최성보" in ov,"overview lists notes and 최성보 for the class")
  E.screenshot(path="s540_ov.png")
  E.click("[data-ov='10104']");E.wait_for_timeout(200);ok("라온 짧은 메모" in E.inner_text("#sheetBox"),"overview → student notes");E.click("#skNo");E.wait_for_timeout(150);ok("메모 · 최성보" in E.inner_text("#sheetBox"),"back returns to overview");E.click("#skNo")
  E.screenshot(path="s540_att.png")
  E.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");E.wait_for_timeout(200);E.click("#obsList [data-s='10103']");E.wait_for_timeout(200)
  ok(E.is_visible("#obSn") and not E.is_checked("#obLow"),"observation sheet has 최성보 + 짧은 메모 block")
  E.fill("#obMemo","관찰 메모 작성 중");E.check("#obLow");E.wait_for_timeout(100)
  E.click("[data-obk=prom]");E.fill("#obSnT","과제 다시 내기로 함");E.click("#obSnAdd");E.wait_for_timeout(150)
  ok(E.input_value("#obMemo")=="관찰 메모 작성 중","unsaved observation memo kept while adding a note")
  dd=json.loads(E.evaluate("localStorage.getItem('att-app-v2')"))["list"][0]["data"]
  ok(dd["low"].get("10103")==1 and dd["snote"]["10103"][0]["k"]=="prom" and dd["snote"]["10103"][0]["t"]=="과제 다시 내기로 함","saved immediately from observation sheet")
  E.screenshot(path="s540_obs.png")
  E.click("[data-obd]");E.wait_for_timeout(100);ok(json.loads(E.evaluate("localStorage.getItem('att-app-v2')"))["list"][0]["data"]["snote"]["10103"][0].get("done"),"지킴 from observation sheet")
  E.click("#obOk");E.wait_for_timeout(200);ok(any(r["memo"]=="관찰 메모 작성 중" for r in json.loads(E.evaluate("localStorage.getItem('att-app-v2')"))["list"][0]["data"]["obs"]),"observation still saves normally")
  E.click("#obsList [data-s='10103']");E.wait_for_timeout(200);E.uncheck("#obLow");E.wait_for_timeout(100);ok("10103" not in (json.loads(E.evaluate("localStorage.getItem('att-app-v2')"))["list"][0]["data"].get("low") or {}),"최성보 unchecked from observation sheet");E.click("#skNo")
  E.click("#obsList [data-snv='10102']");E.wait_for_timeout(200);ok("나래 짧은 메모" in E.inner_text("#sheetBox"),"mark in observation list opens notes")
  b.close()
print("fails",F);print(errs)
