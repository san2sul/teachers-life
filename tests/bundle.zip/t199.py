src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
# 5.93.5 시간표 칸에서 일정 넣기(공강 · 수업 칸)
# (참고) 5.91 안정화 2 · 3차: 수업 설정 한 곳 · 지우기 방식 · 학생 창 · 오늘 화면 정리 · 숨은 동작 안내 · 용어
r1=[["10101","가람"],["10102","가온"],["10103","나래"]]
def state():
  cells={"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"3-4":{"subject":"물리학","clsId":"c1","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[{"id":"e1","date":"2026-10-28","start":"15:00","end":"16:00","cat":"학생 면담","title":"가람 면담","memo":"","clsId":"","alarm":-1,"important":False,"done":False}],
    "evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘","ch":[{"id":"a1","t":"속력"},{"id":"a2","t":"가속도"}]}],"pg":{}}],
    "period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','todo');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1500)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  if T.is_visible("#ttProg"):T.click("#ttPnBtn");T.wait_for_timeout(300)
  if not T.is_visible(".tc[data-d='2'][data-p='1']"):T.click(".ttmode [data-tm=week]");T.wait_for_timeout(300)
  # 1. 공강(빈 칸) → 일정 넣기
  T.click(".tc[data-d='2'][data-p='1']");T.wait_for_timeout(400)
  ok(T.locator("#cmEv").count()==1 and "일정" in T.inner_text("#cmEv") and "pri" in T.get_attribute("#cmEv","class"),"빈 칸 창: ‘이 시간에 일정 넣기’가 맨 앞 "+T.inner_text("#sheetBox").replace("\n"," ")[:120])
  T.click("#cmEv");T.wait_for_timeout(400)
  ok(T.input_value("#evStart")=="09:00" and T.input_value("#evEnd")=="09:50" and T.input_value("#evDate")=="2026-10-28","일정 창: 그 날짜 · 그 교시 시간(09:00~09:50)이 미리 채워짐")
  ok("on" in (T.get_attribute("#evCats [data-c='학생 면담']","class") or "") or T.get_attribute("#evCats [data-c='학생 면담']","aria-pressed")=="true","분류는 학생 면담")
  T.fill("#evTitle","나래 진로 상담");T.click("#evOk");T.wait_for_timeout(500)
  ev=[e for e in json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))["events"] if e["title"]=="나래 진로 상담"]
  ok(ev and ev[0]["start"]=="09:00" and ev[0]["end"]=="09:50" and ev[0]["date"]=="2026-10-28","일정 저장 "+str(ev[:1]))
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  ok("나래 진로" in T.inner_text(".tc[data-d='2'][data-p='1']"),"시간표 빈 칸에 📅 일정 표시 "+T.inner_text(".tc[data-d='2'][data-p='1']").replace("\n"," "))
  T.screenshot(path="shot/t199_grid.png")
  # 다시 누르면 그 시간 일정 목록 → 눌러 고치기
  T.click(".tc[data-d='2'][data-p='1']");T.wait_for_timeout(400)
  ok(T.locator("#sheetBox [data-cev]").count()==1,"칸 창에 이 시간 일정 1개")
  T.screenshot(path="shot/t199_empty.png")
  T.click("#sheetBox [data-cev]");T.wait_for_timeout(400);ok(T.input_value("#evTitle")=="나래 진로 상담","눌러서 그 일정 고치기");T.click("#skNo") if T.locator("#skNo").count() else None;T.evaluate("document.getElementById('sheet').hidden=true")
  # 2. 수업 칸에서도 일정 넣기(그 학급이 미리 골라짐)
  T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400)
  ok(T.locator("#cmEv").count()==1 and T.locator("#cmAtt").count()==1,"수업 칸 창에도 ‘일정 넣기’(출석 단추는 그대로)")
  T.click("#cmEv");T.wait_for_timeout(400)
  ok(T.input_value("#evStart")=="11:00" and T.input_value("#evCls")=="c1","수업 칸: 그 시간 · 그 학급이 미리 채워짐 "+T.input_value("#evCls"))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
