src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{"t1:2:3:2026-10-28":{"progress":"2-1 온도와 열","pAuto":True,"date":"2026-10-28","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":3,"updated":1},"t1:0:2:2026-10-26":{"progress":"1-2 가속도(반만)","pAuto":True,"date":"2026-10-26","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":2,"updated":1}},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"},"a2":{"st":"h","d":"2026-10-26","k":"t1:0:2:2026-10-26"},"b1":{"st":"d","d":"2026-10-28","s":"s1","k":"t1:2:3:2026-10-28"}},"c2":{"a1":{"st":"d","d":"2026-10-27"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  pg=lambda:plan(T)["pg"].get("c1",{})
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400)
  ok(T.is_visible("#mnPn") and T.locator("#pnFxL").count()==1,"수업 메모 진도에 ↺ 바로잡기 단추")
  ok("2-1 온도와 열" in T.inner_text("#mnPn .pncmp"),"앞선 진도(2-1)가 이 수업으로 잘못 들어간 상태")
  # 지난 수업에 반만 한 1-2를 이 수업 진도로 옮기기
  T.click("#mnPn [data-uo='u1']") if T.locator("#mnPn [data-pmv='a2']").count()==0 else None;T.wait_for_timeout(200)
  ok(T.locator("#mnPn [data-pmv='a2']").count()==1,"다른 날 기록된 차시에 ‘↪ 이 수업으로’")
  T.click("#mnPn [data-pmv='a2']");T.wait_for_timeout(300)
  ok(pg()["a2"].get("k")=="t1:2:3:2026-10-28" and pg()["a2"]["st"]=="h","1-2를 이 수업 기록으로 옮김(반만 그대로)")
  ok(root(T)["notes"].get("t1:0:2:2026-10-26",{}).get("progress","")=="","옮긴 뒤 10/26 수업 메모의 자동 진도 글도 맞춰짐")
  T.click("#utoast button");T.wait_for_timeout(300);ok(pg()["a2"].get("k")=="t1:0:2:2026-10-26" and "가속도" in root(T)["notes"].get("t1:0:2:2026-10-26",{}).get("progress",""),"옮기기 되돌리기(10/26 메모 진도 글도)")
  # 5.87.1: 메모에서 다른 날 기록된 차시를 눌러도 이 수업 진도로 기록
  T.click("#mnPn [data-pc='a2|d']");T.wait_for_timeout(300)
  ok(pg()["a2"].get("k")=="t1:2:3:2026-10-28" and pg()["a2"]["st"]=="d" and [e.get("k") for e in pg()["a2"].get("h",[])]==["t1:0:2:2026-10-26"] and "1-2" in T.inner_text("#mnPn .pncmp"),"10/26 반만 + 오늘 마침: 두 수업 기록이 모두 남음 "+str(pg()["a2"]))
  ok("10월 26일 반만" in T.inner_text("#mnPn .pnrow.me"),"차시 줄에 다른 날 기록도 보임")
  T.click("#mnPn [data-pc='a2|']");T.wait_for_timeout(300);ok(pg()["a2"].get("k")=="t1:0:2:2026-10-26" and pg()["a2"]["st"]=="h" and "h" not in pg()["a2"],"‘안 함’은 이 수업 기록만 지움(10/26 반만 그대로)")
  T.click("#mnPn [data-pc='a1|d']");T.wait_for_timeout(300);ok(pg()["a1"].get("k")=="t1:2:3:2026-10-28" and pg()["a1"]["h"][0]["d"]=="2026-10-21","다른 날 마침인 차시도 이 수업 기록을 따로 더함");T.click("#mnPn [data-pc='a1|']");T.wait_for_timeout(300)
  # 바로잡기: 실제로는 1-2까지 마침
  T.click("#pnFxL");T.wait_for_timeout(300)
  ok("진도 바로잡기" in T.inner_text("#sheetBox") and "2-1 온도와 열" in T.inner_text(".pnfxnow"),"바로잡기 창: 지금 기록 2-1")
  T.click("#sheetBox [data-fx='1']");T.wait_for_timeout(200);T.click("#sheetBox [data-fxs='d']");T.wait_for_timeout(200)
  sm=T.inner_text("#pnFxSum");ok("지움 2-1" in sm and "바꿈 1-2" in sm,"고른 차시(1-2 마침) 미리 보기: "+sm)
  T.screenshot(path="shot/t184_fix.png")
  T.click("#pnFxOk");T.wait_for_timeout(400)
  g=pg();ok("b1" not in g and g["a2"]["st"]=="d" and g["a2"]["k"]=="t1:0:2:2026-10-26" and g["a1"]["st"]=="d","바로잡기: 2-1 지움, 1-2 마침(10/26 수업 그대로), 1-1 그대로 "+str(g))
  ok(T.is_visible("#mnPn") and "아직 기록 없음" in T.inner_text("#mnPn .pncmp"),"바로잡은 뒤 수업 메모로 돌아오고 이 수업 실제 진도는 비워짐")
  ok(root(T)["notes"].get("t1:2:3:2026-10-28",{}).get("progress","")=="","이 수업 메모의 자동 진도 글(2-1)도 지워짐")
  ok(plan(T)["pg"]["c2"]["a1"]["st"]=="d","다른 반 진도는 그대로")
  T.click("#utoast button");T.wait_for_timeout(400);ok("b1" in pg() and pg()["a2"]["st"]=="h" and "2-1" in root(T)["notes"].get("t1:2:3:2026-10-28",{}).get("progress",""),"바로잡기 되돌리기(메모 진도 글도)")
  # 진도 현황에서 반마다 바로잡기 · 기록 없던 앞 차시 채우기
  T.click("#skNo");T.wait_for_timeout(200)
  if T.is_visible("#sheet"):T.evaluate("document.getElementById('sheet').hidden=true")
  T.click("#ttPnBtn");T.wait_for_timeout(300)
  ok(T.locator("[data-pnfx]").count()==2,"진도 현황: 반마다 ↺ 단추")
  T.click("[data-pnfx='c2']");T.wait_for_timeout(300);T.click("#sheetBox [data-fx='2']");T.wait_for_timeout(200)
  ok("마침으로 채움 1-2, 1-3" in T.inner_text("#pnFxSum"),"기록 없던 앞 차시는 마침으로 채움 "+T.inner_text("#pnFxSum"))
  T.click("#pnFxOk");T.wait_for_timeout(300);g2=plan(T)["pg"]["c2"]
  ok(set(g2)=={"a1","a2","a3"} and g2["a3"].get("fx")==1 and "1-3" in T.inner_text("#ttProg") or "2-1" in T.inner_text("#ttProg"),"2반 1-3까지 바로잡음 "+str(g2))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
