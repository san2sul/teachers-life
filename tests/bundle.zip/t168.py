src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ros=[["10101","가람"],["10102","가온"],["10103","나래"],["10104","다솜"]]
def state():
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ros,"phones":{},"emails":{},"teachers":[],"msg":"m",
     "sessions":[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True,"10103":True},"src":"t1:2:3"}]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":{"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-5":{"subject":"물리학","clsId":"c1","clsName":"","room":""}},"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','todo');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def d1(T):return root(T)["list"][0]["data"]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click(".navb[data-v=att]");T.wait_for_timeout(200);T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(300)
  ok(T.locator("#m-obs [data-ov]").count()==2,"수업 관찰에 ▦ 격자 · ☰ 목록 단추")
  T.click("#m-obs [data-ov=grid]");T.wait_for_timeout(200)
  n=len(d1(T)["roster"]);ok(T.locator("#obsList .otile").count()==n and T.locator("#obsList .orow").count()==0 and T.get_attribute("#m-obs [data-ov=grid]","aria-pressed")=="true","격자 보기: 학생 칸 %d개"%n)
  cols=T.evaluate("getComputedStyle(document.getElementById('obsList')).gridTemplateColumns.split(' ').length");ok(cols>=3,"출석부처럼 여러 칸 (%d열)"%cols)
  T.screenshot(path="shot/t168_grid0.png")
  T.click("#obsList .otile >> nth=0");T.wait_for_timeout(250);ok(T.is_visible("#sheet"),"항목을 고르지 않고 누르면 그 학생 기록 창");T.click("#sheet .skx") if T.locator("#sheet .skx").is_visible() else T.keyboard.press("Escape");T.wait_for_timeout(250)
  if T.is_visible("#sheet"):T.evaluate("document.getElementById('sheet').hidden=true")
  T.click("#obsBar [data-k=a1]");T.wait_for_timeout(150);T.click("#obsList .otile >> nth=1");T.wait_for_timeout(200)
  sid=d1(T)["roster"][1][0];have=[r for r in d1(T).get("obs",[]) if r["sid"]==sid and r["date"]=="2026-10-28" and r["tags"].get("a1")]
  ok(have and "has" in T.get_attribute("#obsList .otile >> nth=1","class") and T.locator("#obsList .otile >> nth=1").locator(".otgs i").count()>=1,"항목을 고른 뒤 칸을 누르면 바로 넣고 칸에 표시")
  T.screenshot(path="shot/t168_grid.png")
  T.reload();T.wait_for_timeout(900);T.click(".navb[data-v=att]");T.wait_for_timeout(200);T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(300)
  ok(T.locator("#obsList .otile").count()==n,"다시 열어도 격자 보기 그대로")
  T.click("#m-obs [data-ov=list]");T.wait_for_timeout(200);ok(T.locator("#obsList .orow").count()==n and T.locator("#obsList .otile").count()==0 and "has" in T.get_attribute("#obsList .orow >> nth=1","class"),"☰ 목록 보기로 돌아가기(기록 표시 그대로)")
  T.evaluate("document.querySelector('[data-key=\"m:att\"]').click()");T.wait_for_timeout(200);ok(T.locator("#list.grid").count()==1 or T.locator("#list").count()==1,"출석부 보기는 따로")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
