src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"],["10103","나래"],["10104","다온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":False,"10103":False,"10104":False},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{"10102":"010-1111-2222","10103":"010-3333-4444","10104":"010-5555-6666"},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{"t1:0:2:2026-10-26":{"progress":"1-2 가속도 (반만)","memo":"실험 보고서 걷기","date":"2026-10-26","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":2,"updated":1}},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"},"a2":{"st":"h","d":"2026-10-26","k":"t1:0:2:2026-10-26"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click("#topBtns .setb");T.wait_for_timeout(400);T.click("#d-rl summary");T.wait_for_timeout(200)
  ok(T.is_disabled("#rlSend") and T.is_visible("#rlCol"),"설문 전: 결과 보내기 꺼짐 · 받은 결과 모으기 있음")
  T.click("#rlSus");T.wait_for_timeout(200)
  for i,v in enumerate([5,1,5,1,5,1,5,2,4,1]):T.click("#sheetBox [data-sq='%d|%d']"%(i,v))
  T.click("#susOk");T.wait_for_timeout(300)
  box=T.inner_text("#sheetBox");rid=T.evaluate("localStorage.getItem('att-app-rlid')")
  ok("설문을 저장했습니다" in box and "[교사의생활 SUS] ID "+rid in box and "95점" in box and "답 5,1,5,1,5,1,5,2,4,1" in box,"설문 저장 → 바로 결과 보내기 창(참여 ID · 점수 · 답) "+box.replace("\n"," ")[:160])
  T.evaluate("window.__goSpy=[]");T.fill("#rlTo","010-1234-5678");T.click("#rsSms");T.wait_for_timeout(100)
  g=T.evaluate("window.__goSpy");ok(len(g)==1 and g[0].startswith("sms:") and "01012345678" in g[0] and "SUS" in __import__("urllib.parse").parse.unquote(g[0]),"문자로 보내기: 받을 번호 · 결과 글 "+g[0][:60])
  T.fill("#rlTo","teacher@school.kr");T.click("#rsMail");T.wait_for_timeout(100)
  g=T.evaluate("window.__goSpy");ok(len(g)==2 and g[1].startswith("mailto:teacher%40school.kr") and "subject=" in g[1],"메일로 보내기 "+g[1][:60])
  ok(T.locator("#rsCopy").count()==1,"결과 복사 단추")
  T.click("#skNo");T.wait_for_timeout(200);ok(T.evaluate("localStorage.getItem('att-app-rlto')")=="teacher@school.kr","받을 사람 기억")
  ok(not T.is_disabled("#rlSend"),"설문 뒤 결과 보내기 켜짐");T.click("#rlSend");T.wait_for_timeout(200);ok(T.locator("#sheetBox .rlcode div").count()==1 and T.input_value("#rlTo")=="teacher@school.kr","설정에서 결과 보내기(받을 사람 그대로)");T.click("#skNo");T.wait_for_timeout(200)
  # 받는 쪽: 모으기
  T.click("#rlCol");T.wait_for_timeout(200)
  txt="""교사의 생활 사용성 설문(SUS) 결과입니다.
[교사의생활 SUS] ID TAAA111 · 2026-10-29 · 100점 · 답 5,1,5,1,5,1,5,1,5,1 · v5.82.2
안녕하세요 잘 받았습니다
[교사의생활 SUS] ID TBBB222 · 2026-10-29 · 50점 · 답 3,3,3,3,3,3,3,3,3,3 · v5.82.2
[교사의생활 SUS] ID TAAA111 · 2026-10-29 · 100점 · 답 5,1,5,1,5,1,5,1,5,1 · v5.82.2
[교사의생활 SUS] ID TAAA111 · 2026-11-12 · 75점 · 답 4,2,4,2,4,2,4,2,4,2 · v5.82.2
[교사의생활 SUS] ID TCCC333 · 2026-10-29 · 0점 · 답 1,5,1,5,1,5,1,5,1,5 · v5.82.2 · 체험"""
  T.fill("#rcT",txt);T.wait_for_timeout(200);sm=T.inner_text("#rcSum")
  ok("4건" in sm and "참여 2명" in sm and "평균 75점" in sm and "체험 모드 결과 1건" in sm,"붙여 넣기 → 결과 줄만 · 중복 한 번 · 체험 제외 평균 "+sm.replace("\n"," ")[:120])
  with T.expect_download() as dl:T.click("#rcXl")
  f=dl.value;pth="__TL_WORK__/sus_col.xlsx";f.save_as(pth)
  import openpyxl;wb=openpyxl.load_workbook(pth);ok(wb.sheetnames==["요약","결과","전후 변화","문항"] and f.suggested_filename.startswith("사용성설문_모음_"),"엑셀: 요약 · 결과 · 전후 변화 · 문항 "+str(wb.sheetnames))
  cells=[str(c.value) for row in wb["전후 변화"].iter_rows() for c in row if c.value is not None];ok("TAAA111" in cells and "-25" in "|".join(cells),"전후 변화: TAAA111 100 → 75 (−25)")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
