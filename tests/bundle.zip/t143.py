src=open('audit2.py').read();exec(src.split("sizes=")[0])
import re,urllib.parse,base64,io
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"],["10102","나래"],["10103","다솜"]],"phones":{"10101":"010-1111-2222","10102":"010-3333-4444"},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def flush(T):T.wait_for_timeout(560)
def form(r):return [x for x in root(r)["recs"] if x["k"]=="form"]
# a small PNG
from PIL import Image
im=Image.new("RGB",(800,600),(200,230,250));buf=io.BytesIO();im.save(buf,"PNG");PNG=buf.getvalue()
open("rx.png","wb").write(PNG)
def sign(P,k):
  bb=P.locator(f"#pad_{k} canvas").bounding_box();P.mouse.move(bb["x"]+20,bb["y"]+30);P.mouse.down()
  for i in range(1,12):P.mouse.move(bb["x"]+20+i*20,bb["y"]+30+(i%3)*12)
  P.mouse.up()
def fill_absence(P,no=None,nm=None,attach=True):
  if no is not None:P.fill("#f_no",no);P.fill("#f_nm",nm)
  P.select_option("#f_kind","질병결석");P.fill("#f_from","2026-10-21");P.fill("#f_to","2026-10-22");P.fill("#f_reason","고열로 병원 진료");P.select_option("#f_doc","진료확인서")
  if attach:P.set_input_files("#fpick","rx.png");P.wait_for_timeout(500)
  P.fill("#f_pname","김보호");P.select_option("#f_prel","모");P.fill("#f_ptel","010-9999-8888");P.check("#agree");P.locator("#pad_st").scroll_into_view_if_needed();sign(P,"st");P.locator("#pad_pa").scroll_into_view_if_needed();sign(P,"pa")
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul",accept_downloads=True);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script("window.__goSpy=[];window.__fileSpy=[];window.__printSpy=[];")
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click("[data-wn=form]");T.wait_for_timeout(400)
  ok(T.locator("[data-ft]").count()==4 and T.locator("[data-ft=consent]").count()==1,"서류 종류 4가지 (동의서 추가)")
  T.click("[data-ft=consent]");T.wait_for_timeout(300)
  ok("학생 · 학부모 동의서 (성적 이의신청 기간 교외체험학습)" in T.inner_text("#sheetBox") and not T.is_checked("#fmReq") and T.locator("#fpOs").count()==1,"동의서: 이의 신청 기간 칸 · 증빙 선택")
  T.fill("#fpYr","2026");T.select_option("#fpSem","2");T.select_option("#fpCha","2");T.fill("#fpOs","2026-12-14");T.dispatch_event("#fpOs","change");T.fill("#fpOe","2026-12-16");T.dispatch_event("#fpOe","change");T.fill("#fmSch","한빛고등학교");flush(T)
  pre=form(T)[0]["fm"].get("pre",{});ok(pre.get("os")=="2026-12-14" and pre.get("sem")=="2" and pre.get("yr")=="2026","이의 신청 기간 저장")
  T.screenshot(path="shot/t143_set.png")
  T.click("[data-tab=send]");T.wait_for_timeout(300);T.click("[data-fs='10101']");T.wait_for_timeout(400)
  body=urllib.parse.unquote(T.evaluate("window.__goSpy")[-1].split("body=")[1]);link=re.search(r"(https?://\S*form\.html#f=\S+)",body).group(1)
  ok("동의서" in body,"동의서 안내 문자")
  P=c.new_page();P.on("pageerror",lambda e:errs.append("form:"+str(e)));P.add_init_script(FIX);P.goto(link);P.wait_for_timeout(800)
  ok("성적 이의 신청 기간" in P.inner_text("#ti") and P.input_value("#f_os")=="2026-12-14" and P.get_attribute("#f_os","readonly") is not None and P.input_value("#f_sem")=="2","선생님이 정한 기간 미리 채움 (고칠 수 없음)")
  ok(P.locator(".fchk input").count()==1,"동의 체크 1개 (학교 양식 문구)")
  P.fill("#f_from","2026-12-14");P.fill("#f_to","2026-12-17");P.fill("#f_sph","010-2222-3333")
  P.fill("#f_pname","김보호");P.select_option("#f_prel","모");P.fill("#f_ptel","010-9999-8888");P.check("#agree");sign(P,"st");sign(P,"pa")
  P.click("#go");P.wait_for_timeout(300);ok("확인 사항 체크" in P.inner_text("#err"),"동의에 체크해야 제출")
  P.screenshot(path="shot/t143_form.png",full_page=True)
  P.check("#f_c1");P.click("#go");P.wait_for_timeout(1500);ok(not P.locator("#done").is_hidden(),"동의서 만들기")
  with P.expect_download() as dl:P.click("#dl")
  html=open(dl.value.path(),encoding="utf-8").read();open("consent.html","w",encoding="utf-8").write(html);P.close()
  ok("학생 · 학부모 동의서" in html and "확인 · 동의함" in html,"동의서 파일")
  T.click("[data-tab=recv]");T.wait_for_timeout(300);T.set_input_files("#fmFile","consent.html");T.wait_for_timeout(1500);flush(T)
  r=form(T)[0];d=r["subs"][0]["d"];ok(len(r["subs"])==1 and d.get("c1")=="1" and d.get("os")=="2026-12-14" and d.get("sph")=="010-2222-3333","동의서 넣기")
  T.click("[data-sv]");T.wait_for_timeout(800);t=T.inner_text(".fmov")
  ok("성적 이의 신청 기간" in t and "4일간" in t and T.locator("[data-fvm]").count()==0,"동의서 보기 (학교 양식 없으면 앱 양식)")
  T.screenshot(path="shot/t143_view.png")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
