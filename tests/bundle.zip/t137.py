src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"]],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
SPY="window.__goSpy=[];window.__printSpy=[];window.__fileSpy=[];"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def rec(T):return root(T)["recs"][-1]
def blocks(T):return rec(T)["blocks"]
def flush(T):T.wait_for_timeout(560)
def sel(T,sel,a,b,nth=0):T.evaluate("([s,a,b,n])=>{const el=document.querySelectorAll(s)[n];const w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let x,pos=0,st=null,en=null;while(x=w.nextNode()){const L=x.nodeValue.length;if(!st&&a<=pos+L)st=[x,a-pos];if(!en&&b<=pos+L)en=[x,b-pos];pos+=L}const r=document.createRange();r.setStart(...st);r.setEnd(...en);el.focus();const S=getSelection();S.removeAllRanges();S.addRange(r)}",[sel,a,b,nth])
def caret(T,sel,pos,nth=0):sel_(T,sel,pos,nth)
def sel_(T,s,pos,nth):T.evaluate("([s,p,n])=>{const el=document.querySelectorAll(s)[n];const w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let x,acc=0,t=null;while(x=w.nextNode()){if(p<=acc+x.nodeValue.length){t=[x,p-acc];break}acc+=x.nodeValue.length}const r=document.createRange();if(t)r.setStart(...t);else{r.selectNodeContents(el);r.collapse(false)}r.collapse(true);el.focus();const S=getSelection();S.removeAllRanges();S.addRange(r)}",[s,pos,nth])
def newpage(c):
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));return T
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":430,"height":900},service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=newpage(c);T.add_init_script(FIX);T.add_init_script(SPY)
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-wrk','day');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.evaluate("document.querySelector('[data-key=\"w:day\"]').click()");T.wait_for_timeout(150);T.click("#wrCard [data-wn=day]");T.wait_for_timeout(300);
  # ---- 엔터 · 새 문단
  T.click("#wrEd .wbt");T.keyboard.type("첫째 문단",delay=5);T.keyboard.press("Enter");T.keyboard.type("둘째",delay=5);flush(T)
  ok([x["x"] for x in blocks(T)]==["첫째 문단","둘째"],"엔터 → 새 문단")
  cdp=c.new_cdp_session(T)
  for t in ["ㅅ","세","셋"]:cdp.send("Input.imeSetComposition",{"text":t,"selectionStart":1,"selectionEnd":1})
  T.keyboard.press("Enter");T.wait_for_timeout(200);cdp.send("Input.insertText",{"text":"넷"});flush(T)
  ok([x["x"] for x in blocks(T)][-2:]==["둘째셋","넷"],"한글 조합 중 엔터도 새 문단: "+str([x["x"] for x in blocks(T)]))
  # native paragraph (keyboard that bypasses beforeinput)
  T.evaluate("(()=>{const el=[...document.querySelectorAll('#wrEd .wbt')].pop();el.innerHTML='넷<div>다섯</div>';el.dispatchEvent(new InputEvent('input',{inputType:'insertParagraph',bubbles:true}))})()");flush(T)
  ok([x["x"] for x in blocks(T)][-2:]==["넷","다섯"],"자판이 문단을 직접 넣어도 나눔: "+str([x["x"] for x in blocks(T)]))
  T.keyboard.press("End");T.keyboard.press("Shift+Enter");T.keyboard.type("같은 문단",delay=5);flush(T)
  ok(blocks(T)[-1]["x"]=="다섯\n같은 문단","Shift+엔터는 줄만 바꿈: "+repr(blocks(T)[-1]["x"]))
  n0=len(blocks(T));caret(T,"#wrEd .wbt",2,0);T.click("[data-wc=fmt]");T.click("#wrFmt [data-fm=nl]");flush(T)
  ok(len(blocks(T))==n0+1 and blocks(T)[0]["x"]=="첫째" and blocks(T)[1]["x"]==" 문단","↵ 새 문단 단추")
  # ---- 문단 모양
  caret(T,"#wrEd .wbt",1,1);T.click("[data-wc=fmt]");T.click("#wrFmt [data-fm=para]");T.wait_for_timeout(250)
  ok(T.locator(".wpara").count()==1,"문단 · 간격 창")
  for k,v in [("lh","2"),("sb","18"),("sa","10"),("al","center"),("fs","1.25"),("ff","serif"),("fi","1")]:T.click(f".wpara [data-k='{k}'][data-v='{v}']");T.wait_for_timeout(80)
  T.click(".wpara [data-ind='1']");T.wait_for_timeout(80);flush(T)
  s=blocks(T)[1].get("s",{});ok(s.get("lh")=="2" and s.get("sb")==18 and s.get("sa")==10 and s.get("al")=="center" and s.get("fs")=="1.25" and s.get("ff")=="serif" and s.get("fi")==1 and s.get("ind")==1,"이 문단: 줄 간격 · 앞뒤 간격 · 정렬 · 크기 · 글꼴 · 들여쓰기: "+str(s))
  st=T.evaluate("(()=>{const r=document.querySelectorAll('#wrEd .wb')[1],t=r.querySelector('.wbt'),c=getComputedStyle(t),rc=getComputedStyle(r);return[c.textAlign,c.fontFamily,rc.marginTop,c.textIndent,rc.paddingLeft]})()")
  ok(st[0]=="center" and "serif" in st[1] and st[2]=="18px","편집 화면에 바로 보임: "+str(st))
  T.click(".wpara [data-sc=d]");T.wait_for_timeout(100)
  for k,v in [("lh","1.15"),("pg","10"),("pad","24"),("fs","1.125")]:T.click(f".wpara [data-k='{k}'][data-v='{v}']");T.wait_for_timeout(80)
  flush(T);d=rec(T).get("st",{});ok(d.get("lh")=="1.15" and d.get("pg")==10 and d.get("pad")==24 and d.get("fs")=="1.125","글 전체: 줄 간격 · 문단 사이 · 여백 · 크기: "+str(d))
  ok(T.evaluate("getComputedStyle(document.getElementById('wrEd')).paddingLeft")=="24px","여백 적용")
  T.locator(".wpara .wovb").screenshot(path="shot/t137_para.png")
  T.click("#wpOk");T.wait_for_timeout(150)
  # split carries paragraph style
  caret(T,"#wrEd .wbt",6,1);T.keyboard.press("End");T.keyboard.press("Enter");T.keyboard.type("이어짐",delay=5);flush(T)
  ok(blocks(T)[2].get("s",{}).get("al")=="center","엔터로 만든 문단도 같은 모양")
  # ---- 글자 크기 · 자간 · 글꼴(골라서)
  sel(T,"#wrEd .wbt",0,2,0);T.click("[data-wc=fmt]");T.click("#wrFmt [data-fm=fsz]");T.wait_for_timeout(120);T.click(".wpal [data-v='1.5em']");flush(T)
  sel(T,"#wrEd .wbt",0,2,0);T.click("[data-wc=fmt]");T.click("#wrFmt [data-fm=lsp]");T.wait_for_timeout(120);T.click(".wpal [data-v='0.1em']");flush(T)
  sel(T,"#wrEd .wbt",0,2,0);T.click("[data-wc=fmt]");T.click("#wrFmt [data-fm=ff]");T.wait_for_timeout(120);T.click(".wpal [data-v='monospace']");flush(T)
  h=blocks(T)[0].get("h","");ok("font-size:1.5em" in h.replace(" ","") and "letter-spacing:0.1em" in h.replace(" ","") and "monospace" in h,"글자 크기 · 자간 · 글꼴: "+h)
  # ---- 링크
  sel(T,"#wrEd .wbt",0,2,0);T.click("[data-wc=fmt]");T.click("#wrFmt [data-fm=link]");T.wait_for_timeout(200);T.fill("#wlU","www.example.com");T.click("#wlOk");flush(T)
  ok('href="https://www.example.com"' in blocks(T)[0].get("h",""),"링크 넣기")
  T.click("#wrEd .wbt >> nth=0 >> a");T.wait_for_timeout(200);T.click(".wlbub [data-l=o]");T.wait_for_timeout(100)
  ok("https://www.example.com" in T.evaluate("window.__goSpy"),"링크 누르면 열기")
  # ---- 되돌리기 · 다시
  T.click("#wrEd .wbt >> nth=0");T.keyboard.press("End");T.keyboard.type("추가함",delay=5);flush(T)
  ok(blocks(T)[0]["x"].endswith("추가함"),"(쓰기)")
  T.click("#wrTool [data-hx=u]");flush(T);ok(not blocks(T)[0]["x"].endswith("추가함"),"↶ 되돌리기")
  T.click("#wrTool [data-hx=r]");flush(T);ok(blocks(T)[0]["x"].endswith("추가함"),"↷ 다시")
  # ---- 강조 상자 · 오늘 날짜
  T.click("#wrEd .wbadd");T.keyboard.type("/",delay=5);T.wait_for_timeout(200);T.click("#wrSlash [data-sp=date]");flush(T)
  ok(blocks(T)[-1]["x"].startswith("2026. 10. 23. (금)"),"/ → 오늘 날짜: "+blocks(T)[-1]["x"])
  T.click("[data-wc=para]");T.click("#wrTool [data-bt=call]");T.keyboard.type("꼭 기억!",delay=5);flush(T);ok(blocks(T)[-1]["t"]=="call","💡 강조 상자")
  # ---- 찾아 바꾸기 · 글자 수
  T.click("[data-wc=tool]");T.click("#wrTool [data-fr]");T.wait_for_timeout(200);T.fill("#wfQ","문단");T.wait_for_timeout(100);ok("곳에서 찾았습니다" in T.inner_text("#wfN"),"찾기: "+T.inner_text("#wfN"))
  T.fill("#wfR","단락");T.click("#wfOk");flush(T);ok(not any("문단" in x["x"] for x in blocks(T) if "x" in x) and any("단락" in x.get("x","") for x in blocks(T)),"모두 바꾸기")
  T.click("#wfNo");ok("글자" in T.inner_text("#wrCnt") and "낱말" in T.inner_text("#wrCnt"),"글자 수: "+T.inner_text("#wrCnt"))
  # ---- 표 · 수식 · 그림 넣고 내보내기
  T.click("[data-wc=ins]");T.click("#wrTool [data-bo=table]");T.wait_for_timeout(200);T.keyboard.type("가",delay=5);T.keyboard.press("Tab");T.keyboard.type("나",delay=5);flush(T)
  T.click("[data-wc=ins]");T.click("#wrTool [data-bo=math]");T.wait_for_timeout(200);T.fill("#wmT","a^{2}+b^{2}=c^{2}");T.click("#wmOk");T.wait_for_timeout(500)
  with T.expect_file_chooser() as fc:T.click("[data-wc=ins]");T.click("#wrTool [data-bo=img]")
  fc.value.set_files("wr_photo.jpg");T.wait_for_timeout(1000);T.click("[data-wc=ins]");T.click("#wrTool [data-bo=draw]");T.wait_for_timeout(300)
  bb=T.locator("#wdS").bounding_box();k=bb["width"]/1000;T.click(".wdtools [data-t=rect]");T.mouse.move(bb["x"]+100*k,bb["y"]+100*k);T.mouse.down();T.mouse.move(bb["x"]+300*k,bb["y"]+200*k,steps=5);T.mouse.up()
  T.click(".wdtools [data-t=note]");bb=T.locator("#wdS").bounding_box();T.mouse.click(bb["x"]+500*k,bb["y"]+100*k);T.wait_for_timeout(150);T.fill("#wdT","포스트잇 메모");T.click("#wdTok");T.wait_for_timeout(150)
  T.click(".wdtop [data-a=ok]");T.wait_for_timeout(300);flush(T)
  ok(any(i["k"]=="note" for x in blocks(T) if x["t"]=="draw" for i in x["items"]),"도화지 포스트잇")
  T.click("[data-wc=tool]");T.click("#wrTool [data-ex]");T.wait_for_timeout(200);ok(T.locator(".wexp [data-x]").count()==5,"내보내기 메뉴 5가지")
  T.click(".wexp [data-x=print]");T.wait_for_timeout(1500);pr=T.evaluate("window.__printSpy");ok(len(pr)==1 and "단락" in pr[0] and "wvtbl" in pr[0] and "katex" in pr[0],"인쇄 · PDF (표 · 수식 포함)")
  T.click("[data-wc=tool]");T.click("#wrTool [data-ex]");T.wait_for_timeout(200);T.click(".wexp [data-x=doc]");T.wait_for_timeout(2500)
  fs=T.evaluate("window.__fileSpy");ok(len(fs)==1 and fs[0]["name"].endswith(".doc") and fs[0]["name"].startswith("첫째") and "multipart/related" in fs[0]["text"] and fs[0]["size"]>3000,"Word(.doc) 파일: "+(fs[0]["name"] if fs else ""))
  T.click("[data-wc=tool]");T.click("#wrTool [data-ex]");T.wait_for_timeout(200);T.click(".wexp [data-x=html]");T.wait_for_timeout(2500)
  fs=T.evaluate("window.__fileSpy");ok(len(fs)==2 and fs[1]["name"].endswith(".html") and "<!doctype html>" in fs[1]["text"],"웹 페이지 파일(.html)")
  T.click("[data-wc=tool]");T.click("#wrTool [data-ex]");T.wait_for_timeout(200);T.click(".wexp [data-x=link]");T.wait_for_timeout(2500)
  url=T.input_value("#wwU");ok("/view.html#v=z1." in url,"웹 링크 만들기: %d자"%len(url))
  T.locator(".wweb .wovb").screenshot(path="shot/t137_link.png")
  T.click("#wwNo")
  # ---- view.html에서 열기
  V=newpage(c);V.goto(url.replace("https://tl.test/","https://tl.test/"));V.wait_for_timeout(1500)
  ok("첫째" in V.inner_text("#doc h1"),"웹 페이지: 제목(5.83: 첫 줄)")
  ok(V.locator("#doc .wvtbl").count()==1 and V.locator("#doc .wmathb .katex").count()==1 and V.locator("#doc .wvfig img[src^='data:image']").count()==1 and V.locator("#doc .wvdraw svg").count()==1,"웹 페이지: 표 · 수식 · 그림 · 도화지")
  ok(V.locator("#doc a[href='https://www.example.com']").count()==1 and "center" in V.evaluate("getComputedStyle(document.querySelectorAll('#doc .wvp')[1]).textAlign"),"웹 페이지: 링크 · 문단 모양")
  V.screenshot(path="shot/t137_view.png",full_page=True)
  V.click("#pres");V.wait_for_timeout(500);ok(V.locator(".wvpres").count()==1,"웹 페이지: 발표");V.keyboard.press("Escape");V.wait_for_timeout(200)
  bad=newpage(c);bad.goto("https://tl.test/view.html#v=z1.AAAA");bad.wait_for_timeout(700);ok(not bad.locator("#err").is_hidden(),"망가진 링크는 안내")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
