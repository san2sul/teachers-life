src=open('audit2.py').read();exec(src.split("sizes=")[0])
import re,urllib.parse
F=[]
def swSend(P,sel):
  L=P.locator(sel).first;L.evaluate("e=>e.scrollIntoView({block:'center'})");P.wait_for_timeout(150);bb=L.bounding_box();x=bb["x"]+bb["width"]*0.8;y=bb["y"]+bb["height"]/2
  P.mouse.move(x,y);P.mouse.down();P.mouse.move(x-260,y,steps=12);P.mouse.up();P.wait_for_timeout(300)
  P.locator(".swacts>button",has_text="전달").click();P.wait_for_timeout(300)

def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
# 5.93.2 첨부 파일까지 보내기: 문자 · 메일 링크엔 파일이 안 붙어 → Gmail로 바로 · 앱에 첨부(공유) · 내려받아 메일 창
STAFF=[{"name":"김과학","phone":"010-1000-0001","dept":"교무부","role":"교무부장","subj":"과학"},{"name":"이수학","phone":"010-1000-0002","dept":"연구부","role":"수업","subj":"수학"},
       {"name":"박국어","phone":"010-1000-0003","dept":"교무부","role":"학적","subj":"국어"},{"name":"최물리","phone":"010-1000-0004","dept":"과학정보부","role":"부장","subj":"과학"}]
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"]],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":STAFF,"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def flush(T):T.wait_for_timeout(560)
def spy(T):return T.evaluate("window.__goSpy")
import base64
PNG=base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==")
open("att_a.png","wb").write(PNG);open("att_b.pdf","wb").write(b"%PDF-1.4\n%test pdf\n")
SHARE="""window.__share=[];navigator.canShare=function(d){return true};navigator.share=function(d){window.__share.push({files:(d.files||[]).map(f=>f.name+':'+f.size),text:d.text||''});return Promise.resolve()};
try{Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:function(t){window.__clip=t;return Promise.resolve()}}})}catch(e){}"""
GM=[]
def gm(route,req):
  GM.append(req.post_data or "");route.fulfill(json={"id":"m1"})
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul",accept_downloads=True);c.route("**/*",handler)
  c.route("https://gmail.googleapis.com/**",gm)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script("window.__goSpy=[];window.__fileSpy=[];window.__printSpy=[];");T.add_init_script(SHARE)
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-wrk','day');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.evaluate("localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-wrk','day')");T.reload();T.wait_for_timeout(900)
  T.evaluate("document.querySelector('[data-key=\"w:day\"]').click()");T.wait_for_timeout(150);T.click("#wrCard [data-wn=day]");T.wait_for_timeout(400)
  T.click("#wrEd .wbt");T.keyboard.type("학부모 상담 자료 전달",delay=5);flush(T)
  for f in ["att_a.png","att_b.pdf"]:
    with T.expect_file_chooser() as fc:T.click("[data-wm=file]")
    fc.value.set_files(f);T.wait_for_timeout(700)
  ok(len(root(T)["recs"][-1].get("media",[]))==2,"글에 첨부 2개")
  T.click("#skNo");T.wait_for_timeout(300);swSend(T,"#wrCard .wrrow[data-wr]")
  ok("첨부 2개" in T.inner_text("#sheetBox"),"전달 창: 첨부 2개 안내")
  T.fill("#wsTo","parent@ex.kr, teacher@ex.kr");T.click("[data-wsh=mail]");T.wait_for_timeout(500)
  ok(T.locator("#sheetBox .wsatt").count()==1 and len(spy(T))==0,"이메일 → 바로 메일 앱이 아니라 ‘첨부까지 보내는 방법’ 고르기 "+T.inner_text("#sheetBox .wsatt").replace("\n"," ")[:160] if T.locator("#sheetBox .wsatt").count() else "")
  T.screenshot(path="shot/t197_mail.png")
  ok(T.locator("[data-wa=gmail]").count()==0,"Gmail 끔(기본)일 때는 Gmail 단추 없음")
  T.click("[data-wa=app]");T.wait_for_timeout(600)
  sh=T.evaluate("window.__share");ok(len(sh)==1 and len(sh[0]["files"])==2 and "att_a.png" in sh[0]["files"][0] and "학부모 상담" in sh[0]["text"],"메일 앱에 첨부: 글 + 파일 2개를 공유 "+str(sh))
  ok(T.evaluate("window.__clip")=="parent@ex.kr, teacher@ex.kr","받는 사람 주소를 미리 복사 "+str(T.evaluate("window.__clip")))
  ok(any("첨부 2개" in x.get("to","") for x in root(T)["recs"][-1].get("sent",[])),"전달 기록에 첨부 수")
  # 문자도 같은 방식
  T.fill("#wsTo","010-1234-5678");T.click("[data-wsh=sms]");T.wait_for_timeout(500)
  ok(T.locator("#sheetBox .wsatt").count()==1 and "문자" in T.inner_text("#sheetBox .wsatt"),"문자 → 첨부 방법 고르기")
  T.click("[data-wa=plain]");T.wait_for_timeout(400);g=spy(T)[-1];ok(g.startswith("sms:") and "첨부" in urllib.parse.unquote(g),"‘첨부 없이 글만’ → 예전처럼 문자(첨부 목록만)")
  # Gmail 켜진 기기: 한 명씩 첨부까지 바로
  T.evaluate("()=>{localStorage.setItem('att-app-gmail','1');const g=JSON.parse(localStorage.getItem('att-app-gsync')||'{}');Object.assign(g,{token:'tok',exp:Date.now()+3e6,gmail:true,email:'me@ex.kr'});localStorage.setItem('att-app-gsync',JSON.stringify(g))}")
  T.reload();T.wait_for_timeout(900);swSend(T,"#wrCard .wrrow[data-wr]")
  T.fill("#wsTo","parent@ex.kr, teacher@ex.kr");T.click("[data-wsh=mail]");T.wait_for_timeout(500)
  ok(T.locator("[data-wa=gmail]").count()==1,"Gmail 켜진 기기: ‘Gmail로 첨부까지 바로 보내기’")
  T.click("[data-wa=gmail]");T.wait_for_timeout(2500)
  ok(len(GM)==2,"받는 사람마다 한 통씩(서로 주소가 보이지 않게) %d"%len(GM))
  m=GM[0] if GM else ""
  ok("multipart/mixed" in m and "Content-Disposition: attachment" in m and m.count("Content-Disposition: attachment")==2 and base64.b64encode(PNG).decode()[:40] in m.replace("\r\n",""),"메일 본문에 실제 파일 2개(base64)")
  ok("To: parent@ex.kr" in m,"받는 사람")
  # 파일 공유가 안 되는 컴퓨터: 내려받고 메일 창
  T.evaluate("navigator.canShare=undefined;navigator.share=undefined")
  T.fill("#wsTo","parent@ex.kr");T.click("[data-wsh=mail]");T.wait_for_timeout(500)
  ok("내려받" in T.inner_text("#sheetBox .wsatt"),"공유 안 되는 기기: ‘첨부 내려받고 메일 창 열기’")
  dls=[];T.on("download",lambda d:dls.append(d.suggested_filename))
  T.click("[data-wa=app]");T.wait_for_timeout(2000)
  ok(len(dls)==2 and spy(T)[-1].startswith("mailto:parent"),"첨부 2개 내려받기 + 메일 창 "+str(dls))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
