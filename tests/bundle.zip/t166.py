src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[],"to":"2026-11-04"}],"active":"t1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
import openpyxl,os
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",accept_downloads=True);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.on("dialog",lambda d:d.accept("김선생"));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#ttPnBtn");T.wait_for_timeout(300);T.click("#pnMk");T.wait_for_timeout(300)
  ok(T.locator("#pnEnd").count()==0 and "학기 끝" in T.inner_text("#pnEndI"),"학기 끝 날짜 칸 없음(시간표 따름)")
  # 한글 조합 입력: 미리보기만 다시 그리고 입력 칸은 그대로
  T.click("#pnTx");cd=c.new_cdp_session(T);T.evaluate("window.__t0=document.getElementById('pnTx')")
  for w in ["힘과","운동"]:
    for k in range(1,len(w)+1):
      part=w[:k];cd.send("Input.imeSetComposition",{"text":part[-1],"selectionStart":1,"selectionEnd":1});T.wait_for_timeout(250)
      cd.send("Input.insertText",{"text":part[-1]});T.wait_for_timeout(250)
    T.keyboard.press("Enter") if w=="힘과" else None
  T.wait_for_timeout(600)
  ok(T.input_value("#pnTx")=="힘과\n운동" and T.evaluate("window.__t0===document.getElementById('pnTx')&&document.activeElement===window.__t0"),"진도표 고치기: 한글 입력이 끊기지 않음 "+repr(T.input_value("#pnTx")))
  ok("1단원 1차시" in T.inner_text("#pnPv") or "단원" in T.inner_text("#pnPv"),"미리보기는 따라 바뀜 "+T.inner_text("#pnPv").split("\n")[0])
  T.evaluate("window.__tlKb=1");T.click("#pnS");T.wait_for_timeout(300);ok(not T.is_visible("#pnOk"),"입력 중에는 아래 단추(삭제 · 취소 · 저장) 숨김")
  T.evaluate("window.__tlKb=0;document.activeElement.blur()");T.wait_for_timeout(300);ok(T.is_visible("#pnOk"),"입력을 마치면 다시 보임")
  T.fill("#pnTx","");T.wait_for_timeout(500)
  with T.expect_download() as dl:T.click("#pnTpl")
  fn=dl.value.suggested_filename;path=os.path.abspath("tpl_"+fn.replace("/","_"));dl.value.save_as(path)
  ok(fn=="수업진도표_양식_물리학.xlsx","양식 파일 이름 "+fn)
  wb=openpyxl.load_workbook(path);ws=wb["진도표"];hdr=[c.value for c in ws[4]]
  ok(hdr[:3]==["단원","차시","계획 날짜 (선택)"] and "1학년 1반" in hdr and "1학년 2반" in hdr and "쓰는 법" in wb.sheetnames,"양식: 단원 · 차시 · 계획 날짜 · 반 열 "+str(hdr))
  # 채우기
  ws.delete_rows(5,ws.max_row)
  i1=hdr.index("1학년 1반")+1;i2=hdr.index("1학년 2반")+1
  data=[["1. 힘과 운동","속력과 속도","2026-10-20","마침 2026-10-21","마침"],["","가속도","2026-10-27","반만 10/28",""],["","뉴턴 법칙","",""," "],["2. 열","온도와 열","","",""]]
  for r in data:
    row=[None]*len(hdr);row[0],row[1],row[2]=r[0],r[1],r[2];row[i1-1]=r[3];row[i2-1]=r[4];ws.append(row)
  up=os.path.abspath("filled.xlsx");wb.save(up)
  T.set_input_files("#pnFi",up);T.wait_for_timeout(1200)
  ok("2단원 4차시" in T.inner_text("#sheetBox") and "계획 날짜 2개" in T.inner_text("#sheetBox") and "진도 기록 3개" in T.inner_text("#sheetBox"),"올리기: 미리보기 + 함께 넣을 계획 · 기록 수")
  ok(T.input_value("#pnS")=="물리학","교과 이름")
  T.click("#pnOk");T.wait_for_timeout(400)
  pl=[x for x in root(T)["plans"] if x["subj"]=="물리학"][0];ch=[c for u in pl["units"] for c in u["ch"]]
  ok([c["t"] for c in ch]==["속력과 속도","가속도","뉴턴 법칙","온도와 열"] and ch[0].get("wk")=="2026-10-20" and ch[1].get("wk")=="2026-10-27","진도표 + 계획 날짜")
  g1=pl["pg"]["c1"];g2=pl["pg"]["c2"]
  ok(g1[ch[0]["id"]]=={"st":"d","d":"2026-10-21"} and g1[ch[1]["id"]]=={"st":"h","d":"2026-10-28"} and g2[ch[0]["id"]]["st"]=="d" and g2[ch[0]["id"]]["d"]=="2026-10-28","반별 진도 기록(날짜 · 날짜 없으면 오늘)")
  # 현재 진도표 + 기록 내려받기 → 그대로 다시 읽힘
  T.click("#ttProg [data-pns='물리학']") if T.locator("#ttProg [data-pns='물리학']").count() else None;T.wait_for_timeout(200)
  with T.expect_download() as dl:T.click("#pnXp")
  path2=os.path.abspath("cur.xlsx");dl.value.save_as(path2);ws2=openpyxl.load_workbook(path2)["진도표"]
  vals=[[c.value for c in r] for r in ws2.iter_rows(min_row=5)]
  ok(vals[0][:3]==["1. 힘과 운동","속력과 속도","2026-10-20"] and "마침 2026-10-21" in vals[0] and "반만 2026-10-28" in vals[1],"진도표 + 기록 엑셀 "+str(vals[0]))
  # 기록부 내려받기 → 기록 지우고 → 기록부 올리기로 되살림
  with T.expect_download() as dl:T.click("#pnXl")
  path3=os.path.abspath("log.xlsx");dl.value.save_as(path3)
  T.evaluate("()=>{const r=JSON.parse(localStorage.getItem('att-app-v2'));r.plans.forEach(p=>p.pg={});localStorage.setItem('att-app-v2',JSON.stringify(r))}");T.reload();T.wait_for_timeout(900)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#ttPnBtn") if not T.is_visible("#ttProg") else None;T.wait_for_timeout(300)
  T.click("#pnEd");T.wait_for_timeout(300);T.set_input_files("#pnFi",path3);T.wait_for_timeout(1200)
  ok("진도 기록 3개" in T.inner_text("#sheetBox"),"수업 진도 기록부 올리기 → 기록 3개")
  T.click("#pnOk");T.wait_for_timeout(400)
  pl=[x for x in root(T)["plans"] if x["subj"]=="물리학"][0];ch=[c for u in pl["units"] for c in u["ch"]]
  ok(pl["pg"]["c1"][ch[1]["id"]]=={"st":"h","d":"2026-10-28"} and pl["pg"]["c2"][ch[0]["id"]]["st"]=="d" and [c["t"] for c in ch]==["속력과 속도","가속도","뉴턴 법칙","온도와 열"],"기록부로 기록 되살림 · 진도표는 그대로")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
