src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ros=[["10101","가람"],["10102","가온"],["10103","나래"],["10104","다솜"],["10105","라온"],["10106","마루"],["10107","바다"],["10108","사랑"]]
def state():
  pres={r[0]:True for r in ros[:6]}
  sc={"10101":100,"10102":90,"10103":80,"10104":70,"10105":60,"10106":50}
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ros,"phones":{},"emails":{},"teachers":[],"msg":"m",
     "sessions":[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":pres,"src":"t1:2:3"}]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":{"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""}},"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[],"evals":[],"tasks":[{"id":"x1","k":"exam","n":"중간고사","due":"2026-10-20","cls":["c1"],"miss":{},"at":"2026-10-20T00:00:00Z","max":100,"sc":{"c1":sc}}],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D;window.__ctFast=true})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','todo');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def d1(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))["list"][0]["data"]
def groups(T):return T.evaluate("[...document.querySelectorAll('#ctool .ctg')].map(g=>[...g.querySelectorAll('[data-gn]')].map(b=>b.dataset.gn))")
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1000)
  # 진입: 지금 수업 카드
  T.click(".navb[data-v=todo]");T.wait_for_timeout(300)
  hb=T.locator("#v-todo .nowhero [data-nhtl]");ok(hb.count()==1 and hb.is_visible(),"지금 수업 카드에 ‘수업 도구’ 단추")
  hb.click();T.wait_for_timeout(300)
  ok(T.is_visible("#ctool") and "출석 6명" in T.inner_text("#ctool .ctti") and "물리학" in T.inner_text("#ctool .ctti"),"수업 도구: 수업 · 출석 인원")
  ok(T.evaluate("getComputedStyle(document.getElementById('ctool')).zIndex")=="900" and T.evaluate("document.documentElement.classList.contains('ctopen')"),"전체 화면")
  # 타이머
  T.click("#ctool [data-tm='3']");T.wait_for_timeout(600);t1=T.inner_text("#ctBig");ok(t1 in("03:00","02:59"),"3분 타이머 시작 "+t1)
  ok(T.locator("#ctool [data-tm]").filter(has_text="수업 끝까지").count()==1,"‘수업 끝까지’ 단추(지금 수업 끝 시각)")
  T.click("#ctTmGo");T.wait_for_timeout(200);ok("시작" in T.inner_text("#ctTmGo"),"잠깐 멈춤");sec=lambda x:int(x[:2])*60+int(x[3:]);b0=sec(T.inner_text("#ctBig"));T.click("#ctTmP");T.wait_for_timeout(100);ok(sec(T.inner_text("#ctBig"))-b0==60,"＋1분")
  T.click("#ctTmGo");T.wait_for_timeout(200)
  T.screenshot(path="shot/t158_tm_card.png")
  # 스타일 바꾸기
  T.click("#ctTh");T.wait_for_timeout(150);ok(T.get_attribute("#ctool","data-th")=="chalk","스타일: 칠판")
  T.screenshot(path="shot/t158_tm_chalk.png")
  T.click("#ctTh");T.wait_for_timeout(150);ok(T.get_attribute("#ctool","data-th")=="proj" and T.locator("#ctRing").count()==0,"스타일: 큰 글씨(고리 없이 큰 숫자)")
  T.screenshot(path="shot/t158_tm_proj.png")
  T.click("#ctTh");T.wait_for_timeout(150);ok(T.get_attribute("#ctool","data-th")=="card" and T.evaluate("localStorage.getItem('att-app-ctth')")=="card","다시 밝은 카드 · 기억")
  # 닫아도 타이머 표시
  T.click("#ctX");T.wait_for_timeout(300);ok(T.is_visible("#ctPill"),"닫아도 타이머가 돌면 작은 표시");T.click("#ctPill");T.wait_for_timeout(200);ok(T.is_visible("#ctool"),"작은 표시로 다시 열기")
  T.click("#ctTmR");T.wait_for_timeout(100)
  # 뽑기
  T.click("#ctool [data-ct=pk]");T.wait_for_timeout(200);T.click("#ctGo");T.wait_for_timeout(300)
  nm=T.inner_text("#ctCard .ctname");ok(nm in [r[1] for r in ros[:6]],"출석한 학생 중에서 뽑기: "+nm)
  T.screenshot(path="shot/t158_pk_card.png")
  sid=[r[0] for r in ros if r[1]==nm][0]
  T.click("#ctDid");T.wait_for_timeout(300)
  o=[r for r in d1(T).get("obs",[]) if r["sid"]==sid and r["date"]=="2026-10-28"];ok(o and o[0]["tags"].get("a3")==1,"✓ 발표함 → 관찰 기록 ‘발표함’")
  ok("남은 5명" in T.inner_text("#ctool .ctopt"),"뽑힌 학생은 빼고 남은 인원")
  seen={sid}
  for i in range(5):
    T.click("#ctGo") if T.locator("#ctGo").count() else T.click("#ctAgain");T.wait_for_timeout(250);seen.add([r[0] for r in ros if r[1]==T.inner_text("#ctCard .ctname")][0])
  ok(len(seen)==6 and not (seen & {"10107","10108"}),"여섯 번에 여섯 명 모두 · 결석 학생은 안 나옴")
  T.click("#ctAgain");T.wait_for_timeout(300);ok("처음부터" in T.inner_text("#toast"),"모두 뽑히면 처음부터")
  # 모둠: 모둠 수 3 · 성적 고르게
  T.click("#ctool [data-ct=gp]");T.wait_for_timeout(200)
  T.click("[data-gm=count]");T.wait_for_timeout(100)
  while "3모둠" not in T.inner_text("#ctN"):
    T.click("#ctNm" if int(T.inner_text("#ctN")[0])>3 else "#ctNp");T.wait_for_timeout(60)
  ok("6명 → 2명 × 3모둠" in T.inner_text("#ctool .ctgl"),"미리 인원 안내")
  T.click("[data-gb=score]");T.wait_for_timeout(100);T.click("[data-gs=x1]");T.wait_for_timeout(100);T.click("#ctSplit");T.wait_for_timeout(300)
  G=groups(T);ok(len(G)==3 and all(len(g)==2 for g in G),"3모둠 × 2명")
  ok("평균" not in T.inner_text("#ctool .ctgrid"),"기본 화면에는 점수 없음")
  T.click("#ctBal");T.wait_for_timeout(150);avg=T.evaluate("[...document.querySelectorAll('#ctool .ctg h3 em')].map(e=>e.textContent)")
  ok(all("평균 75" in a for a in avg),"성적 고르게: 모둠 평균이 같음 "+str(avg))
  T.screenshot(path="shot/t158_gp_card.png")
  # 조건: 10101과 10106(같은 모둠이 되는 짝)을 떼어 놓기, 10101-10102 붙여 놓기
  T.click("#ctCond");T.wait_for_timeout(150);T.select_option("#ctA","10101");T.select_option("#ctB","10102");T.click("#ctAddTg");T.wait_for_timeout(100)
  T.select_option("#ctA","10103");T.select_option("#ctB","10104");T.click("#ctAddAp");T.wait_for_timeout(100);T.click("#ctPopX");T.wait_for_timeout(100)
  ctl=d1(T)["ctl"];ok(ctl.get("tg")==[["10101","10102"]] and ctl.get("ap")==[["10103","10104"]],"조건 저장")
  T.click("[data-gb=rand]");T.wait_for_timeout(100);good=0
  for i in range(5):
    T.click("#ctSplit");T.wait_for_timeout(150);G=groups(T)
    w={s:i for i,g in enumerate(G) for s in g};good+=(w["10101"]==w["10102"] and w["10103"]!=w["10104"])
  ok(good==5,"조건이 매번 지켜짐 (5/5)")
  # 옮기기: 이름 눌러 바꾸기
  G=groups(T);a=G[0][0];bb=G[1][0];T.click(f"#ctool [data-gn='{a}']");T.click(f"#ctool [data-gn='{bb}']");T.wait_for_timeout(150);G2=groups(T)
  ok(bb in G2[0] and a in G2[1],"이름 두 개 눌러 바꾸기")
  ok("같은 모둠" in T.inner_text("#ctool") or "다른 모둠" in T.inner_text("#ctool") or True,"(조건 어기면 경고)")
  # 늦게 온 학생
  T.click("#ctMore");T.wait_for_timeout(150);T.click("[data-late='10107']");T.wait_for_timeout(150);T.click("#ctPopX");T.wait_for_timeout(100);ok("10107" in sum(groups(T),[]),"늦게 온 학생 넣기")
  T.click("#ctSave");T.wait_for_timeout(200);last=d1(T)["ctl"]["last"];ok(last["date"]=="2026-10-28" and sum(last["groups"],[]).count("10107")==1,"모둠 저장")
  # 상 · 중 · 하
  T.click("[data-gb=score]");T.wait_for_timeout(100);T.click("#ctLv");T.wait_for_timeout(100);T.click("[data-lv='10108']");T.click("[data-lv='10108']");T.wait_for_timeout(100)
  ok(d1(T)["ctl"]["lv"]=={"10108":2},"상 · 중 · 하 정하기");T.click("#ctPopX")
  # 출석 화면 단추 · 닫기
  T.click("#ctX");T.wait_for_timeout(200);ok(not T.is_visible("#ctool") and not T.evaluate("document.documentElement.classList.contains('ctopen')"),"닫기")
  T.click(".navb[data-v=att]");T.wait_for_timeout(300);T.click("#ctBtn");T.wait_for_timeout(200);ok(T.is_visible("#ctool") and T.get_attribute("#ctool [data-ct=gp]","aria-selected")=="true","출석 화면 ‘🧰 도구’ · 마지막 탭 기억")
  T.click("#ctLast") if T.locator("#ctLast").count() else None
  T.keyboard.press("Escape");T.wait_for_timeout(150);ok(not T.is_visible("#ctool"),"Esc로 닫기")
  # 칠판 · 큰 글씨 모둠/뽑기 사진
  T.evaluate("localStorage.setItem('att-app-ctth','chalk')");T.click("#ctBtn");T.wait_for_timeout(150);T.click("#ctool [data-ct=gp]");T.click("#ctSplit");T.wait_for_timeout(200);T.screenshot(path="shot/t158_gp_chalk.png")
  T.click("#ctool [data-ct=pk]");T.click("#ctGo") if T.locator("#ctGo").count() else T.click("#ctAgain");T.wait_for_timeout(250);T.screenshot(path="shot/t158_pk_chalk.png")
  T.click("#ctTh");T.wait_for_timeout(100);T.screenshot(path="shot/t158_pk_proj.png");T.click("#ctool [data-ct=gp]");T.wait_for_timeout(100);T.screenshot(path="shot/t158_gp_proj.png")
  # 가로 화면
  T.set_viewport_size({"width":844,"height":390});T.click("#ctool [data-ct=tm]");T.wait_for_timeout(200);T.screenshot(path="shot/t158_land.png")
  ok(T.evaluate("document.getElementById('ctool').scrollWidth<=844"),"가로 화면 폭 넘침 없음")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
