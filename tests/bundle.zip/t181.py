src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses,"obs":[{"id":"o1","sid":"10102","date":"2026-10-26","tags":{"a2":1},"memo":"","at":1}]}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "flows":[{"id":"f1","n":"세부 시험 흐름","steps":[{"id":"s1","n":"도입","m":5,"al":"vib"},{"id":"s2","n":"전개","m":35,"al":"vib","subs":[{"id":"u1","n":"개념 설명","m":10},{"id":"u2","n":"탐구 활동","m":15,"al":"vib"},{"id":"u3","n":"토의 · 토론","m":10}]},{"id":"s3","n":"정리","m":10,"al":"vib"}]}],"flowSub":{"물리학":"f1"},"events":[{"id":"e1","date":"2026-10-28","start":"16:00","end":"","cat":"기타","title":"알림 있는 일정","memo":"","clsId":"","alarm":10,"important":False,"done":False}],"notes":{"t1:0:2:2026-10-26":{"progress":"1-2 가속도 (반만)","memo":"실험 보고서 걷기","date":"2026-10-26","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":2,"updated":1}},"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"},"a2":{"st":"h","d":"2026-10-26","k":"t1:0:2:2026-10-26"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','todo');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
errs=[]
def runk(T):
  r=root(T).get("flowRun",{});ks=[k for k in r if k.startswith("2026-10-28")];return r[ks[0]] if ks else {}
def fs(X):
  if X.is_hidden("#sheet") or not X.locator("#sheetBox .flsheetnow").count():
    if X.evaluate("document.documentElement.dataset.view")!="att":X.click(".navb[data-v=att]");X.wait_for_timeout(600)
    X.evaluate("document.getElementById('sheet').hidden=true");X.click("#flLine [data-fls]");X.wait_for_timeout(500)
def box(T):
  fs(T);return T.inner_text("#sheetBox [data-flowbox]") if T.locator("#sheetBox [data-flowbox]").count() else ""
def shift(T,field,ms):
  T.evaluate("""([f,ms])=>{const s=JSON.parse(localStorage.getItem('att-app-v2'));const k=Object.keys(s.flowRun).find(k=>k.startsWith('2026-10-28'));f.split(',').forEach(q=>s.flowRun[k][q]-=ms);localStorage.setItem('att-app-v2',JSON.stringify(s))}""",[field,ms]);T.reload();T.wait_for_timeout(1200)
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},has_touch=True,service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1500)
  T.click(".navb[data-v=att]");T.wait_for_timeout(600)
  t=box(T);ok("▶ 시작" in t and "지금 시작하면" in t and "12:10" in t and "1/3" not in t,"수업 시간이 되어도 바로 시작하지 않고 ▶ 시작을 기다림 · 지금 시작하면 끝 예상 "+t.replace("\n"," ")[:120])
  ok(not runk(T).get("st"),"시작 전에는 시작 시각 없음")
  T.screenshot(path="shot/t181_wait.png")
  T.evaluate("localStorage.setItem('att-app-rlon','1')")
  fs(T);T.click("#sheetBox .flsheetnow [data-flgo=start]");T.wait_for_timeout(500);t=box(T)
  ok("1/3" in t and "도입" in t and "끝 예상" in t and "11:50" in t and "일시 정지" in t and "정지" in t,"5.92.3 ▶ 시작(11:15, 계획대로면 12:05) → 남은 시간에 맞춰 단계가 줄어 끝 예상 11:50 · ⏸ ■ "+t.replace("\n"," ")[:140])
  ok(runk(T).get("st") and any("도입 시작" in (a[1] or "") for a in T.evaluate("window.__flowAlerts||[]")),"시작하면 첫 단계 시작 알림")
  fs(T);T.click("#sheetBox .flsheetnow [data-flgo=pause]");T.wait_for_timeout(400);t=box(T)
  fa=[r.get("a") for r in json.loads(T.evaluate("localStorage.getItem('att-app-rlog')||'[]'")) if r.get("k")=="flow"];ok("시작" in fa and "일시 정지" in fa,"연구용 기록: 시작 · 일시 정지 "+str(fa))
  ok(runk(T).get("pz") and "이어서" in t and "일시 정지" in t,"⏸ 일시 정지 → 이어서 단추")
  shift(T,"st,pz",5*60000);T.click(".navb[data-v=att]");T.wait_for_timeout(500);t=box(T)
  ok("끝 예상" in t and "이어서" in t,"5분 멈춘 동안에도 끝 예상 표시 "+t.replace("\n"," ")[:140])
  T.screenshot(path="shot/t181_pause.png")
  lt=(fs(T),T.inner_text("#sheetBox [data-fltime]"))[1];T.wait_for_timeout(2100);ok((fs(T),T.inner_text("#sheetBox [data-fltime]"))[1]==lt,"멈춘 동안 남은 시간이 줄지 않음 "+lt)
  fs(T);T.click("#sheetBox .flsheetnow [data-flgo=resume]");T.wait_for_timeout(400);r=runk(T)
  ok(not r.get("pz") and 290000<=r.get("pt",0)<=310000 and any(("끝 예상 11:%d"%m) in box(T) for m in range(40,51)),"▶ 이어서 → 남은 시간에 맞춰 끝 예상이 수업 끝(11:50) 안으로 "+box(T).replace("\n"," ")[:120])
  fs(T);T.click("#sheetBox .flsheetnow [data-flgo=stop]");T.wait_for_timeout(400);t=box(T)
  ok(runk(T).get("stop") and "정지" in t and "처음부터 다시" in t,"■ 정지 → 정지 표시 · 처음부터 다시")
  T.click("#utoast button");T.wait_for_timeout(400);ok(not runk(T).get("stop") and "이어서" not in box(T) and "1/3" in box(T),"정지 되돌리기")
  fs(T);T.click("#sheetBox .flsheetnow [data-flgo=stop]");T.wait_for_timeout(300);fs(T);T.click("#sheetBox .flsheetnow [data-flgo=reset]");T.wait_for_timeout(400)
  ok("▶ 시작" in box(T) and not runk(T).get("st"),"처음부터 다시 → 다시 ▶ 시작을 기다림")
  fs(T)
  ok(T.locator("#sheetBox [data-flgo=start]:visible").count()==1 and "지금 시작하면" in T.inner_text("#sheetBox .flendl") and T.locator("#sheetBox [data-flbk]").count()==0,"수업 흐름 창: ▶ 시작 · 끝 예상(시작 전에는 돌아가기 단추 없음)")
  T.click("#sheetBox [data-flam=auto]");T.wait_for_timeout(300);ok(root(T).get("flowCfg",{}).get("auto")==True,"시작 방법: 수업 시각에 저절로 고르기")
  T.click("#skNo");T.wait_for_timeout(500);t=box(T);ok("▶ 시작" not in t and "/3" in t,"저절로 시작이면 수업 시작 시각 기준으로 진행 "+t.replace("\n"," ")[:80])
  fs(T);T.click("#sheetBox [data-flam=btn]");T.wait_for_timeout(200);ok("auto" not in root(T).get("flowCfg",{}),"다시 ▶ 단추로");T.click("#skNo")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
