src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
# 5.93.2 한글 입력 유지: 기록 블록을 다시 그려도 입력 칸이 사라지지 않음 · 한글 칸에 lang=ko
# (참고) 5.93 오늘=안내 · 출석부=수업 진행 · 앱을 열 때 지금 수업 학급으로 맞춤
# (참고) 5.92 흐름 꼬임 · 수업 화면: 출석은 늘 오늘 · 돌아가는 단추 · 학생 창 · 학급 안 바뀜 · 출석부 수업 흐름 한 줄 · 일하는 중 인사 미루기
r1=[["10101","가람"],["10102","가온"],["10103","나래"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s0","date":"2026-10-26","time":"10:00","label":"2교시 물리학","p":{"10101":False,"10102":True},"src":"t1:0:2"},{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c2","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s2","date":"2026-10-28","time":"09:00","label":"1교시 물리학","p":{"10201":True},"src":"t1:2:1"}]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "flows":[{"id":"f1","n":"실험 수업","steps":[{"id":"x1","n":"도입","m":5,"al":"vib"},{"id":"x2","n":"실험","m":35,"al":"vib"},{"id":"x3","n":"정리","m":10,"al":"vib"}]}],"flowSub":{"물리학":"f1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘","ch":[{"id":"a1","t":"속력"}]}],"pg":{}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off+(window.__adv||0))}static now(){return R.now()+off+(window.__adv||0)}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:true,noon:false,pmAt:'11:00'}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1500)
  T.click(".navb[data-v=rec]") if T.locator(".navb[data-v=rec]").count() else T.click(".navb >> nth=4");T.wait_for_timeout(400)
  T.evaluate("document.querySelector('[data-key=\"w:day\"]').click()");T.wait_for_timeout(200);T.click("#wrCard [data-wn=day]");T.wait_for_timeout(300)
  T.evaluate("window.__lost=0;document.getElementById('wrEd').addEventListener('focusout',e=>{if(!e.relatedTarget||!(e.relatedTarget.isContentEditable||e.relatedTarget.id==='kbKeep'))window.__lost++},true)")
  T.click("#wrEd .wbt");T.keyboard.type("첫 줄 기록",delay=10)
  for k in range(3):T.keyboard.press("Enter");T.wait_for_timeout(120);T.keyboard.type("다음 줄 %d"%k,delay=10)
  T.keyboard.press("Backspace");T.wait_for_timeout(100)
  ok(T.evaluate("window.__lost")==0,"Enter로 새 줄을 만들 때 입력 칸이 한 번도 비지 않음(키보드가 닫혔다 열리지 않음) "+str(T.evaluate("window.__lost")))
  ok(T.evaluate("document.activeElement.classList.contains('wbt')&&document.activeElement.lang==='ko'"),"지금 칸에 lang=ko")
  ok(T.locator("#wrEd .wbt").count()==4 and T.evaluate("[...document.querySelectorAll('#wrEd .wbt')].every(e=>e.lang==='ko')"),"모든 블록에 lang=ko")
  ok(T.evaluate("document.activeElement.id")!="kbKeep","입력은 숨은 칸이 아니라 새 줄에")
  ok("다음 줄 2"[:-1] in T.inner_text("#wrEd"),"글이 그대로 "+T.inner_text("#wrEd").replace("\n"," / "))
  # 다른 입력 칸: 한글 칸은 lang=ko, 영어 · 숫자 칸은 그대로
  T.focus("#wrPl") if T.locator("#wrPl").count() else None
  ok(T.locator("#wrPl").count()==0 or T.evaluate("document.getElementById('wrPl').lang")=="ko","장소 칸 lang=ko")
  T.click("#wrCancel");T.wait_for_timeout(300)
  if T.is_visible("#sheet"):T.evaluate("document.getElementById('sheet').hidden=true")
  r=T.evaluate("""()=>{const out={ko:0,en:0,bad:[]};document.querySelectorAll('input,textarea').forEach(t=>{try{t.dispatchEvent(new FocusEvent('focusin',{bubbles:true}))}catch(e){}
    const en=/^(email|url|tel|number|password|date|time|datetime-local|month|week|color|range|file|checkbox|radio|hidden)$/.test(t.type)||/^(numeric|decimal|email|tel|url|none)$/.test(t.inputMode||'')||t.matches('.code,[autocapitalize=characters],#gsCid,#wmT');
    if(en){if(t.lang==='ko')out.bad.push(t.id||t.name||t.type);out.en++}else{if(t.lang!=='ko')out.bad.push('!'+(t.id||t.placeholder));out.ko++}});return out}""")
  ok(not r["bad"] and r["ko"]>20,"모든 입력 칸 점검: 한글 칸 %d개 lang=ko · 영어/숫자 칸 %d개는 그대로 %s"%(r["ko"],r["en"],r["bad"][:5]))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
