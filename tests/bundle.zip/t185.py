src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "pnCfg":{"mode":"auto","from":"2026-10-26"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T12:05:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(3500)
  pg=lambda cid:plan(T)["pg"].get(cid,{})
  g1=pg("c1");g2=pg("c2")
  ok(g1.get("a2",{}).get("k")=="t1:0:2:2026-10-26" and g1["a2"].get("auto")==1,"월 10/26 2교시(1반): 다음 차시 1-2 자동 마침 "+str(g1))
  ok(g1.get("a3",{}).get("k")=="t1:2:3:2026-10-28" and g1["a3"]["st"]=="d","수 10/28 3교시(끝난 수업): 1-3 자동 마침")
  ok(g2.get("a1",{}).get("k")=="t1:1:1:2026-10-27","2반 화 1교시: 2반 진도표 다음 차시 1-1 자동")
  nt=root(T)["notes"];ok("1-3" in nt.get("t1:2:3:2026-10-28",{}).get("progress",""),"수업 메모의 진도 글도 자동 "+str(nt.get("t1:2:3:2026-10-28")))
  # 수업 메모에서 고치면 다시 덮어쓰지 않음
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400)
  ok("자동으로 기록된 진도" in T.inner_text("#mnPn") and "자동" in T.inner_text("#mnPn .pnrow.me"),"수업 메모: 자동 기록 안내 · 자동 표시")
  T.click("#mnPn [data-pc='a3|']");T.wait_for_timeout(200);T.click("#mnPn [data-pc='a2|d']") ;T.wait_for_timeout(300)
  T.reload();T.wait_for_timeout(3000)
  g1=pg("c1");ok("a3" not in g1,"직접 ‘안 함’으로 고친 차시는 다시 자동으로 넣지 않음 "+str(g1))
  # 직접 고르기로 바꾸기
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#ttPnBtn");T.wait_for_timeout(300)
  ok(T.get_attribute("[data-pnm=auto]","aria-pressed")=="true","진도 현황: 진도 기록 자동(기본)")
  T.click("[data-pnm=manual]");T.wait_for_timeout(200);ok(root(T)["pnCfg"]["mode"]=="manual" and "직접 고르기" in T.inner_text("#ttProg"),"직접 고르기로 바꿈")
  T.screenshot(path="shot/t185_mode.png")
  T.evaluate("(()=>{const s=JSON.parse(localStorage.getItem('att-app-v2'));s.pnAuto={};s.plans[0].pg={};localStorage.setItem('att-app-v2',JSON.stringify(s))})()");T.reload();T.wait_for_timeout(3000)
  ok(plan(T)["pg"]=={},"직접 고르기면 자동 기록 안 함")
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#ttPnBtn");T.wait_for_timeout(300);T.click("[data-pnm=auto]");T.wait_for_timeout(600)
  ok(root(T)["pnCfg"]["from"]=="2026-10-28" and plan(T)["pg"].get("c1",{}).get("a1",{}).get("k")=="t1:2:3:2026-10-28" and "a1" not in plan(T)["pg"].get("c2",{}),"다시 자동으로: 켠 날(오늘) 끝난 수업부터만")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
