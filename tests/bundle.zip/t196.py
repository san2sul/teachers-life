import json,os,re,time,mimetypes
from urllib.parse import urlparse,parse_qs
from playwright.sync_api import sync_playwright
APP='__TL_APP__';SP='__TL_WORK__'
store={};ver=[0]
GIS="""window.google={accounts:{oauth2:{initTokenClient:function(c){return{requestAccessToken:function(){setTimeout(function(){c.callback({access_token:'tok'+Math.random(),expires_in:3600})},20)}}},hasGrantedAllScopes:function(){return true},revoke:function(t,cb){cb&&cb()}}}};"""
def handler(route,req):
  u=urlparse(req.url)
  if u.netloc=='tl.test':
    path=u.path.lstrip('/') or 'index.html'
    if path=='config.js':return route.fulfill(body='window.TL_CONFIG={googleClientId:"123-test.apps.googleusercontent.com"};try{if(!localStorage.getItem("att-app-cheer"))localStorage.setItem("att-app-cheer",JSON.stringify({am:false,pm:false,noon:false}));if(!localStorage.getItem("att-app-ui"))localStorage.setItem("att-app-ui",JSON.stringify({open:"last"}));if(!localStorage.getItem("att-app-clsal"))localStorage.setItem("att-app-clsal","0")}catch(e){}',content_type='text/javascript')
    fp=os.path.join(APP,path)
    if not os.path.exists(fp):return route.fulfill(status=404,body='nf')
    return route.fulfill(path=fp,content_type=mimetypes.guess_type(fp)[0] or 'text/plain')
  if 'gsi/client' in req.url:return route.fulfill(body=GIS,content_type='text/javascript')
  if 'oauth2/v3/userinfo' in req.url:return route.fulfill(json={"email":"t@gmail.com","name":"물리 선생님"})
  if 'googleapis.com' in req.url:
    q=parse_qs(u.query);m=req.method
    if u.path=='/drive/v3/files' and m=='GET':
      return route.fulfill(json={"files":[{"id":k,"version":str(v['ver']),"modifiedTime":"x"} for k,v in store.items()]})
    mm=re.match(r'/drive/v3/files/(\w+)',u.path)
    if mm and m=='GET':
      f=store.get(mm.group(1))
      if not f:return route.fulfill(status=404,json={"error":{"message":"nf"}})
      if q.get('alt')==['media']:return route.fulfill(body=f['body'],content_type='application/json')
      return route.fulfill(json={"id":mm.group(1),"version":str(f['ver'])})
    if mm and m=='DELETE':store.pop(mm.group(1),None);return route.fulfill(status=204,body='')
    if u.path=='/upload/drive/v3/files' and m=='POST':
      body=req.post_data;parts=body.split('\r\n\r\n');content=parts[2].rsplit('\r\n--',1)[0]
      ver[0]+=1;store['f1']={'body':content,'ver':ver[0]};return route.fulfill(json={"id":"f1","version":str(ver[0])})
    mm=re.match(r'/upload/drive/v3/files/(\w+)',u.path)
    if mm and m=='PATCH':
      ver[0]+=1;store[mm.group(1)]={'body':req.post_data,'ver':ver[0]};return route.fulfill(json={"id":mm.group(1),"version":str(ver[0])})
  return route.fulfill(status=404,body='blocked')
S={"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","roster":[["10101","김가"],["10102","이나"]],"phones":{"10101":"010-1111-2222"},"teachers":[],"msg":"m","sessions":[{"id":"s1","date":"2026-10-16","time":"09:00","label":"","p":{"10101":True}}]}},{"id":"c2","data":{"v":3,"cls":"1학년 2반","roster":[["10201","최다"]],"phones":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[{"id":"st1","name":"정교감","dept":"교무실","role":"교감","phone":"010-1234-0001"}],"tt":{"list":[],"active":""},"notes":{},"events":[]}
errs=[]
def dev(b,name,state=None):
  c=b.new_context(viewport={"width":1280 if name=="A" else 390,"height":900},service_workers="block",ignore_https_errors=True);c.route("**/*",handler)
  pg=c.new_page();pg.on("pageerror",lambda e:errs.append(name+":"+str(e)));pg.on("console",lambda m:m.type=="error" and errs.append(name+" console:"+m.text))
  pg.goto("https://tl.test/index.html")
  if state:pg.evaluate("s=>localStorage.setItem('att-app-v2',s)",json.dumps(state))
  pg.evaluate("localStorage.setItem('att-app-view','set')");pg.reload();pg.wait_for_timeout(500);return pg
def st(pg):return json.loads(pg.evaluate("localStorage.getItem('att-app-v2')"))
def summ(pg):s=st(pg);return [(c['data']['cls'],[r[1] for r in c['data']['roster']],len(c['data']['sessions'])) for c in s['list']],[x['name'] for x in s['staff']],len(s['events'])
import sys
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
# 5.93.3 기기 사이 동기화: 기록 창을 연 채로도 올림 · 앱을 떠날 때 바로 올림 · 로그인 1시간 지남 알림
def recs(pg):return [ (x.get("title") or "", " ".join(bb.get("x","") for bb in x.get("blocks",[]))) for x in st(pg).get("recs",[])]
def drive():
  if not store:return []
  import base64,zlib
  t=list(store.values())[0]["body"]
  if "z1." in t and not t.lstrip().startswith("{"):
    z=t[t.index("z1.")+3:];z=re.split(r"[^A-Za-z0-9_-]",z)[0];z+="="*(-len(z)%4)
    t=zlib.decompress(base64.urlsafe_b64decode(z),-15).decode("utf-8")
  d=json.loads(t);return [" ".join(bb.get("x","") for bb in x.get("blocks",[])) for x in d.get("data",d).get("recs",[])]
def login(pg):
  pg.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)");pg.click("#gsLogin");pg.wait_for_timeout(1800)
def newrec(pg,txt):
  pg.click(".navb[data-v=rec]") if pg.locator(".navb[data-v=rec]").count() else pg.locator(".navb").nth(4).click();pg.wait_for_timeout(400)
  pg.evaluate("document.querySelector('[data-key=\"w:day\"]').click()");pg.wait_for_timeout(200);pg.click("#wrCard [data-wn=day]");pg.wait_for_timeout(300)
  pg.click("#wrEd .wbt");pg.keyboard.type(txt,delay=5);pg.wait_for_timeout(500)
with sync_playwright() as p:
  b=p.chromium.launch()
  A=dev(b,"A",S);login(A)
  B=dev(b,"Bphone");B.click("#wzHave") if B.is_visible("#wzHave") else None;login(B)
  ok(len(store)==1,"두 기기 연결")
  # 1. 컴퓨터: 생활 기록 창을 열어 둔 채로 써도 올라감
  newrec(A,"컴퓨터에서 쓴 생활 기록");A.wait_for_timeout(4500)
  ok(A.is_visible("#sheet") and any("컴퓨터에서 쓴 생활 기록" in x for x in drive()),"기록 창을 연 채로도 몇 초 뒤 드라이브에 올라감 "+str(drive()))
  A.click("#skNo");A.wait_for_timeout(600)
  # 2. 휴대폰: 돌아오면 받음
  B.evaluate("document.dispatchEvent(new Event('visibilitychange'))");B.wait_for_timeout(1800)
  ok(any("컴퓨터에서 쓴 생활 기록" in x[1] for x in recs(B)),"휴대폰에서 앱으로 돌아오면 컴퓨터 기록을 받음")
  # 3. 컴퓨터: 쓰자마자 창을 닫으면(다른 탭 · 브라우저 닫기) 바로 올림
  newrec(A,"쓰자마자 닫음")
  vis="v=>{Object.defineProperty(document,'visibilityState',{configurable:true,get:()=>v?'hidden':'visible'});Object.defineProperty(document,'hidden',{configurable:true,get:()=>v});document.dispatchEvent(new Event('visibilitychange'))}"
  A.evaluate(vis,True);A.wait_for_timeout(1500)
  ok(any("쓰자마자 닫음" in x for x in drive()),"앱을 떠나는 순간 바로 올림(3초 기다리지 않음)")
  A.evaluate(vis,False);A.wait_for_timeout(300)
  # 4. 휴대폰: 로그인 1시간이 지나면 눈에 띄게 알림 → 다시 로그인하면 받음
  B.evaluate("()=>{const g=JSON.parse(localStorage.getItem('att-app-gsync'));g.exp=Date.now()-1000;localStorage.setItem('att-app-gsync',JSON.stringify(g))}")
  B.reload();B.wait_for_timeout(1500)
  bar=B.locator(".newbar.gsexp");ok(bar.count()==1 and "다시 로그인" in bar.inner_text(),"로그인 시간이 지나면 위에 ‘동기화가 멈춤 · 다시 로그인’ 띠 "+(bar.inner_text().replace("\n"," ") if bar.count() else ""))
  ok(not any("쓰자마자 닫음" in x[1] for x in recs(B)),"(멈춘 동안은 아직 못 받음)")
  bar.locator(".go").click();B.wait_for_timeout(2000)
  ok(any("쓰자마자 닫음" in x[1] for x in recs(B)) and B.locator(".newbar.gsexp").count()==0,"띠의 ‘다시 로그인’ → 바로 받음")
  # 5. 휴대폰에서 쓴 기록도 컴퓨터로
  newrec(B,"휴대폰 기록");B.wait_for_timeout(4500);B.click("#skNo");B.wait_for_timeout(300)
  A.evaluate("document.dispatchEvent(new Event('visibilitychange'))");A.wait_for_timeout(1800)
  ok(A.is_visible("#sheet") and "창을 닫으면 받음" in A.inner_text("#gsPill") and not any("휴대폰 기록" in x[1] for x in recs(A)),"컴퓨터에 기록 창이 열려 있으면 받지 않고 ‘창을 닫으면 받음’ 표시(쓰던 글 보호) "+A.inner_text("#gsPill"))
  A.click("#skNo");A.wait_for_timeout(6500)
  ok(any("휴대폰 기록" in x[1] for x in recs(A)) and len(recs(A))==len(recs(B))==3,"휴대폰 기록도 컴퓨터로 · 두 기기 기록 수 같음 %d/%d"%(len(recs(A)),len(recs(B))))
  b.close()
ok(not [e for e in errs if "favicon" not in e],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
