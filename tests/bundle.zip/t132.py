src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
R1=[["10101","가람"],["10102","나래"],["10103","다솜"]];R2=[["10201","마루"],["10202","바다"]]
def cls(i,n,r):return {"id":i,"data":{"v":3,"cls":n,"year":2026,"term":"2학기","roster":r,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[],"snote":{"10101":[{"id":"n1","k":"prom","t":"숙제 가져오기","at":"2026-10-20T09:00:00Z"},{"id":"n2","k":"warn","t":"알레르기","at":"2026-10-20T09:00:00Z"}]} if i=="c1" else {}}}
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  tasks=[{"id":"k1","k":"perf","n":"공통 실험 보고서","due":"2026-10-22","cls":["c1","c2"],"miss":{"c1":{"10101":"m"},"c2":{"10201":"m"}},"at":"2026-10-20T00:00:00Z"},
         {"id":"k2","k":"hw","n":"1반 학습지","due":"2026-10-21","cls":["c1"],"miss":{},"at":"2026-10-19T00:00:00Z"},
         {"id":"k3","k":"form","n":"2반 퀴즈","due":"2026-10-20","cls":["c2"],"miss":{},"at":"2026-10-18T00:00:00Z"}]
  recs=[{"id":"r1","k":"day","at":"2026-10-22T09:00","place":"교실","blocks":[{"id":"b1","t":"p","x":"첫째 글"}],"media":[]},
        {"id":"r2","k":"day","at":"2026-10-21T09:00","place":"","blocks":[{"id":"b2","t":"p","x":"둘째 글"}],"media":[]}]
  ev=[{"id":"e1","date":"2026-10-22","start":"10:00","end":"","cat":"업무","title":"오늘 회의","memo":"","alarm":-1,"important":False,"done":False}]
  return {"active":"c1","list":[cls("c1","1학년 1반",R1),cls("c2","1학년 2반",R2)],"staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":ev,"evals":[],"tasks":tasks,"recs":recs,"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-22T09:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def task(T,i):return ([x for x in root(T).get("tasks",[]) if x["id"]==i] or [None])[0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},has_touch=True,is_mobile=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX)
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','task');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  cdp=c.new_cdp_session(T)
  def touch(sel,dx=-220,nth=0):
    T.locator(sel).nth(nth).evaluate("e=>e.scrollIntoView({block:'center'})");T.wait_for_timeout(150)
    bb=T.locator(sel).nth(nth).bounding_box();x=bb["x"]+bb["width"]*0.8;y=bb["y"]+bb["height"]/2
    cdp.send("Input.dispatchTouchEvent",{"type":"touchStart","touchPoints":[{"x":x,"y":y}]})
    for i in range(1,9):cdp.send("Input.dispatchTouchEvent",{"type":"touchMove","touchPoints":[{"x":x+dx*i/8,"y":y}]});T.wait_for_timeout(16)
    cdp.send("Input.dispatchTouchEvent",{"type":"touchEnd","touchPoints":[]});T.wait_for_timeout(350)
  def acts():return T.evaluate("[...document.querySelectorAll('.swacts:not([hidden])>button')].map(b=>b.textContent.trim())")
  def tap(label):
    bb=T.locator(".swacts>button",has_text=label).bounding_box();T.touchscreen.tap(bb["x"]+bb["width"]/2,bb["y"]+bb["height"]/2);T.wait_for_timeout(450)
  # ---- 평가 · 과제 (공통 목록)
  row="#ttTasks .tkrow"
  ok(T.locator(row).count()==3,"common task list has 3 rows")
  touch(row);ok(acts()==["수정","보관","삭제"],"swipe shows 수정 · 보관 · 삭제: "+str(acts()))
  T.screenshot(path="shot/t132_task.png")
  tap("보관");ok(task(T,"k1").get("arch") and T.locator(row).count()==2,"보관 hides the task from the list")
  ok(T.locator("#tkArcAll").count()==1 and "보관함 1" in T.inner_text("#tkArcAll"),"보관함 button appears")
  T.click("#utoast button");T.wait_for_timeout(300);ok(not task(T,"k1").get("arch") and T.locator(row).count()==3,"undo un-archives")
  touch(row);tap("보관");T.click("#tkArcAll");T.wait_for_timeout(250)
  ok(T.locator(row).count()==1 and "공통 실험" in T.inner_text(row),"보관함 shows archived task")
  touch(row);ok(acts()==["수정","꺼내기","삭제"],"archived row: 꺼내기")
  tap("꺼내기");ok(not task(T,"k1").get("arch"),"꺼내기 restores")
  ok(T.locator(row).count()==3 and T.locator("#tkArcAll").count()==0,"back to full list when 보관함 empty")
  touch(row,nth=1);tap("수정");ok(not T.locator("#sheet").is_hidden() and "고치기" in T.inner_text("#sheetBox h2"),"수정 opens the editor")
  T.fill("#tkN","1반 학습지 (고침)");T.click("#tkOk");T.wait_for_timeout(300);T.evaluate("document.getElementById('sheet').hidden=true");T.wait_for_timeout(150)
  ok(task(T,"k2")["n"]=="1반 학습지 (고침)","edit saved")
  n0=len(root(T)["tasks"]);touch(row,nth=2);tap("삭제");ok(len(root(T)["tasks"])==n0-1 and task(T,"k3") is None,"삭제 removes")
  T.click("#utoast button");T.wait_for_timeout(300);ok(task(T,"k3") is not None,"undo restores deleted task")
  # ---- 학급 관찰 기록의 평가 · 과제: 공통 과제는 '빼기' (이 학급만)
  T.evaluate("document.querySelector('#amode [data-m=obs]').click()");T.wait_for_timeout(300)
  crow="#tkCard .tkrow"
  ok(T.locator(crow).count()==2,"class card shows 1반 tasks")
  i=[k for k in range(T.locator(crow).count()) if "공통" in T.locator(crow).nth(k).inner_text()][0]
  touch(crow,nth=i);ok(acts()==["수정","보관","빼기"],"shared task in class view: 빼기 "+str(acts()))
  tap("빼기");k1=task(T,"k1");ok(k1 and k1["cls"]==["c2"] and "c1" not in k1["miss"],"빼기 removes only this class")
  ok(T.locator(crow).count()==1,"class list updated")
  T.click("#utoast button");T.wait_for_timeout(300);ok(task(T,"k1")["cls"]==["c1","c2"],"undo 빼기")
  touch(crow,nth=0);tap("보관");ok(T.locator(crow).count()==1 and T.locator("#tkArc").count()==1,"class card 보관 + 보관함 button")
  T.click("#tkArc");T.wait_for_timeout(200);ok(T.locator(crow).count()==1,"class 보관함 lists archived")
  T.click("#tkArc");T.wait_for_timeout(200)
  # ---- 글쓰기: 수정 · 보관 · 삭제
  T.evaluate("document.querySelector('#amode [data-m=write]').click()");T.wait_for_timeout(300)
  wrow="#wrCard .wrrow"
  touch(wrow);ok(acts()==["수정","보관","삭제"],"글쓰기 swipe: "+str(acts()));T.screenshot(path="shot/t132_write.png")
  tap("보관");ok(T.locator(wrow).count()==1 and [r for r in root(T)["recs"] if r["id"]=="r1"][0].get("arch"),"글 보관")
  T.click("#wrArc");T.wait_for_timeout(200);ok(T.locator(wrow).count()==1 and "첫째" in T.inner_text(wrow),"글 보관함")
  touch(wrow);tap("꺼내기");ok(T.locator(wrow).count()==2,"글 꺼내기")
  touch(wrow,nth=1);tap("수정");ok(T.locator("#wrEd").count()==1,"글 수정 opens editor");T.click("#skX");T.wait_for_timeout(250)
  if not T.locator("#sheet").is_hidden():T.evaluate("document.getElementById('sheet').hidden=true")
  # ---- 오늘(할 일): 완료 · 수정 · 삭제
  T.click(".navb[data-v=todo]");T.wait_for_timeout(300)
  touch("#tdList .td");ok(acts()==["완료","수정","삭제"],"할 일 swipe: "+str(acts()));T.screenshot(path="shot/t132_todo.png")
  tap("완료");ok(root(T)["events"][0]["done"]==True,"완료 marks done")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
