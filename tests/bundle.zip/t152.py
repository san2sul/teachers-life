src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def cls(i,name,n):return {"id":i,"data":{"v":3,"cls":name,"year":2026,"term":"2학기","roster":[[f"1{i[-1]}1{k:02d}",f"학생{k}"] for k in range(1,n+1)],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}
def state():
  cells={}
  for d in range(5):
    for p_ in range(1,8):
      if (d+p_)%2==0:cells[f"{d}-{p_}"]={"subject":"물리학","clsId":"c%d"%(1+(d+p_)%3),"clsName":"","room":"과학실"}
  cells["4-1"]={"subject":"물리학","clsId":"c1","clsName":"","room":"과학실"}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[cls("c1","1학년 1반",28),cls("c2","1학년 2반",27),cls("c3","2학년 1반",26)],"tt":{"list":[t],"active":"t1"},"notes":{},
    "events":[{"id":"e1","date":"2026-10-24","start":"10:00","end":"10:50","cat":"기타","title":"부서 회의 및 자료 정리","memo":"","alarm":0}],"evals":[],"tasks":[],"recs":[],"staff":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T09:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
SM="""()=>{let n=0,ex=[];document.querySelectorAll('main.view:not([hidden]) *, nav *').forEach(e=>{if(!e.offsetParent)return;const t=[...e.childNodes].some(x=>x.nodeType===3&&x.nodeValue.trim());if(!t)return;const fs=parseFloat(getComputedStyle(e).fontSize);if(fs<10.95){n++;if(ex.length<3)ex.push(fs.toFixed(1)+' '+e.textContent.trim().slice(0,10))}});return [n,ex]}"""
errs=[]
def page(b,w,h=844,extra=""):
  c=b.new_context(viewport={"width":w,"height":h},is_mobile=w<700,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT+extra);T.goto("https://tl.test/index.html");T.wait_for_timeout(1000);return T
with sync_playwright() as p:
  b=p.chromium.launch()
  for W in (390,360):
    T=page(b,W)
    ok(T.get_attribute("[data-tm=d3]","aria-pressed")=="true" and T.locator("table.ttg.d3").count()==1,f"{W}px 세로 휴대폰은 처음에 3일 보기")
    hb=T.locator("#v-tt .nowhero .nht b");lh=T.evaluate("parseFloat(getComputedStyle(document.querySelector('#v-tt .nowhero .nht b')).lineHeight)")
    ok(hb.bounding_box()["height"]<=lh*1.2,f"{W}px 지금 수업 제목 한 줄 ({hb.inner_text()})")
    g=T.locator("#v-tt .nowgo").bounding_box();x=T.locator("#v-tt .nhx").bounding_box()
    ok(x["x"]>=g["x"] and x["x"]+x["width"]<=g["x"]+g["width"]+1 and x["y"]>=g["y"]-1 and x["width"]>=44 and x["height"]>=44,f"{W}px ✕는 카드 안, 44px")
    T.click("[data-tm=week]");T.wait_for_timeout(250);wt=T.locator("#ttWeekTxt").bounding_box()["height"];ok(wt<30,f"{W}px 주간 기간 표시 한 줄 ({T.inner_text('#ttWeekTxt')})")
    T.click("[data-tm=d3]");T.wait_for_timeout(250)
    for v in ["tt","att","call","todo","stat","set"]:
      T.click(f".navb[data-v={v}]");T.wait_for_timeout(300)
      if v=="set":T.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)");T.wait_for_timeout(200)
      n,ex=T.evaluate(SM);ok(n==0,f"{W}px {v}: 11px 미만 글자 {n} {ex}")
    if W==390:
      hs=T.evaluate("[...document.querySelectorAll('#d-ver .lkrow a')].map(a=>a.getBoundingClientRect().height)");ok(hs and min(hs)>=44,"앱 소개 · 개인정보처리방침 · 이용약관 높이 44px 이상")
      T.click(".navb[data-v=todo]");T.wait_for_timeout(400)
      r=T.locator("#v-todo .swrow:has-text('부서 회의')");r.scroll_into_view_if_needed();bb=r.bounding_box();y=bb["y"]+bb["height"]/2;x0=bb["x"]+bb["width"]-30
      r.evaluate("(r,[x,y])=>{const o={pointerId:7,pointerType:'touch',isPrimary:true,bubbles:true,clientY:y};r.dispatchEvent(new PointerEvent('pointerdown',{...o,clientX:x}));for(let i=1;i<=10;i++)r.dispatchEvent(new PointerEvent('pointermove',{...o,clientX:x-i*18}));r.dispatchEvent(new PointerEvent('pointerup',{...o,clientX:x-180}))}",[x0,y]);T.wait_for_timeout(450)
      ok(T.evaluate("document.querySelector('#v-todo .swrow.swopen')!==null"),"할 일 줄 밀기")
      ok(T.evaluate("getComputedStyle(document.querySelector('#v-todo .swrow.swopen').parentElement).overflowX")=="clip","밀린 줄은 카드 밖으로 보이지 않음")
      ok(T.evaluate("getComputedStyle(document.querySelector('#v-todo .swrow.swopen .tdbell')).visibility")=="hidden","🔔 단추가 완료 · 수정 · 삭제 옆에 남지 않음")
      T.screenshot(path="shot/t152_swipe.png",clip={"x":0,"y":max(0,bb["y"]-50),"width":390,"height":bb["height"]+100})
      T.click(".navb[data-v=att]");T.wait_for_timeout(300);T.evaluate("document.querySelector('#v-att .nowgo')&&document.querySelector('#v-att .nowgo').click()");T.wait_for_timeout(400)
      T.evaluate("(()=>{const b=document.createElement('div');b.className='newbar';b.innerHTML='<span>마지막 백업: 아직 없음. 자료를 잃지 않도록 백업 파일을 저장하거나 구글 연동을 켜 두세요.</span><button class=go>지금 백업</button>';document.body.appendChild(b)})()");T.wait_for_timeout(300)
      T.evaluate("window.scrollTo(0,document.documentElement.scrollHeight)");T.wait_for_timeout(300)
      last=T.locator("#list .st").last.bounding_box();bar=T.locator(".newbar").first.bounding_box()
      ok(last["y"]+last["height"]<=bar["y"],"알림 띠가 떠 있어도 끝까지 밀면 마지막 학생 칸이 가려지지 않음")
      T.screenshot(path="shot/t152_bar.png")
    T.context.close()
  T=page(b,1024,768);ok(T.get_attribute("[data-tm=week]","aria-pressed")=="true","넓은 화면은 주간 보기 그대로");T.context.close()
  T=page(b,390,844,"try{localStorage.setItem('att-app-ttmode','week')}catch(e){}");ok(T.get_attribute("[data-tm=week]","aria-pressed")=="true","주간을 고른 적이 있으면 그대로");T.context.close()
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
