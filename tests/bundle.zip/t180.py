src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ros=[["10101","가람"],["10102","가온"]]
st={"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ros,"phones":{"10101":"010-1234-5678","10102":"010-2222-3333"},"emails":{},"teachers":[],"msg":"m",
 "sessions":[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":False,"10102":True},"src":"t1:2:3"}]}}],"staff":[],
 "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":{"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""}},"adj":{},"days":{},"chg":[]}],"active":"t1"},
 "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-cheer','{\"am\":false,\"pm\":false}')}}catch(e){}"%json.dumps(json.dumps(st))
errs=[]
with sync_playwright() as p:
  b=p.chromium.launch()
  for W in (390,360):
    c=b.new_context(viewport={"width":W,"height":800},has_touch=True,service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
    T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(5600)
    nb=lambda:T.evaluate("(()=>{const e=document.querySelector('.newbar');if(!e)return null;const r=e.getBoundingClientRect();return getComputedStyle(e).display==='none'?'hidden':[Math.round(r.top),Math.round(r.bottom)]})()")
    ok(nb() not in (None,"hidden"),"%d: 백업 알림 띠가 뜸"%W)
    T.click(".navb[data-v=att]");T.wait_for_timeout(200);T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(300)
    k=T.evaluate("document.querySelector('#obsBar [data-k]').dataset.k");T.click("#obsBar [data-k='%s']"%k);T.wait_for_timeout(100)
    T.locator("#obsList [data-s='10101']").first.tap();T.wait_for_timeout(400)
    ok(T.is_visible("#utoast") and nb()=="hidden","%d: 되돌리기 알림이 떠 있는 동안 백업 띠는 잠시 숨김(겹치지 않음)"%W)
    if W==390:T.screenshot(path="shot/t180_undo.png")
    T.click("#utoast button");T.wait_for_timeout(450);ok(nb() not in (None,"hidden"),"%d: 되돌리기 알림이 닫히면 백업 띠가 다시 보임"%W)
    T.click(".navb[data-v=call]");T.wait_for_timeout(400)
    h=T.evaluate("(()=>{const e=document.querySelector('#abList .who .nowr');return e?[e.getClientRects().length,e.textContent]:null})()")
    ok(h and h[0]==1 and "010-1234-5678" in h[1],"%d: 결석 학생 전화번호가 한 줄 %s"%(W,h))
    ov=T.evaluate("(()=>{const r=document.querySelector('#abList .crow');return r.scrollWidth<=r.clientWidth+1})()");ok(ov,"%d: 결석 학생 줄이 가로로 넘치지 않음"%W)
    if W==360:T.locator("#abList .crow").first.screenshot(path="shot/t180_call.png")
    c.close()
  # 아침 인사 기분 단추: 낱말 중간 줄바꿈 없음 (같은 모양의 단추로 확인)
  c=b.new_context(viewport={"width":360,"height":800},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  r=T.evaluate("""(()=>{const d=document.createElement('div');d.className='moods';d.style.width='300px';d.innerHTML='<button><span>😢</span>마음이 무거워요</button><button><span>🙂</span>괜찮아요</button><button><span>😀</span>좋아요</button><button><span>😮‍💨</span>피곤해요</button>';document.body.appendChild(d);const b=d.firstChild,t=b.lastChild,rg=document.createRange();rg.selectNodeContents(t);const lines=[...rg.getClientRects()].length;const out=[getComputedStyle(b).wordBreak,lines];d.remove();return out})()""")
  ok(r[0]=="keep-all" and r[1]<=2,"아침 인사 ‘마음이 무거워요’는 낱말 단위로만 줄바꿈 "+str(r))
  # 5.83.5: 녹음 — 녹음 파일 고르기는 capture 없이(동영상 촬영이 열리지 않게), 앱 안 녹음이 안 되면 창에서 이유 · 방법
  for nomr in (False,True):
    c=b.new_context(viewport={"width":390,"height":800},has_touch=True,service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
    T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT)
    if nomr:T.add_init_script("delete window.MediaRecorder")
    T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
    T.click(".navb[data-v=att]");T.wait_for_timeout(200);T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(300)
    T.click("#obsList [data-e='10101']") if T.locator("#obsList [data-e='10101']").count() else T.locator("#obsList [data-s='10101']").first.click();T.wait_for_timeout(300)
    if T.locator("#obMedBtns [data-cap=audio]").count()==0:
      T.locator("#obsList .otile:has-text('가람'), #obsList [data-e='10101']").first.click();T.wait_for_timeout(300)
    T.click("#obMedBtns [data-cap=audio]");T.wait_for_timeout(300)
    ok(T.is_visible("#recApp") and ("음성 메모" in T.inner_text("#recHow") or "녹음" in T.inner_text("#recHow")),"녹음 창에 휴대폰 녹음 앱으로 붙이는 방법 안내 (MediaRecorder 없음=%s)"%nomr)
    if nomr:ok(T.is_disabled("#recGo") and "지원하지 않습니다" in T.inner_text("#recN"),"앱 안 녹음이 안 되는 브라우저: 동영상 앱으로 넘기지 않고 창에서 이유를 알림")
    if nomr:T.screenshot(path="shot/t180_rec.png")
    with T.expect_file_chooser() as fc:T.click("#recApp")
    el=fc.value.element;ok(el.get_attribute("capture") is None and el.get_attribute("accept")=="audio/*","녹음 파일 붙이기: capture 없이 audio/* (동영상 촬영이 열리지 않음) %s"%[el.get_attribute("capture"),el.get_attribute("accept")])
    c.close()
  # 5.83.6: 안드로이드는 녹음 앱 열기 단추, 아이폰은 음성 메모 안내
  UA={"and":"Mozilla/5.0 (Linux; Android 14; SM-S921N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36","ios":"Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1"}
  for k,ua in UA.items():
    c=b.new_context(viewport={"width":390,"height":800},has_touch=True,user_agent=ua,service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
    T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
    T.click(".navb[data-v=att]");T.wait_for_timeout(200);T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(300)
    T.click("#obsList [data-e='10101']") if T.locator("#obsList [data-e='10101']").count() else T.locator("#obsList [data-s='10101']").first.click();T.wait_for_timeout(300)
    T.click("#obMedBtns [data-cap=audio]");T.wait_for_timeout(300)
    if k=="and":
      ok(T.is_visible("#recOpen") and "녹음 앱 열기" in T.inner_text("#recHow"),"안드로이드: 📱 녹음 앱 열기 단추")
      T.screenshot(path="shot/t180_recand.png")
      urls=[];T.on("request",lambda r:urls.append(r.url))
      T.evaluate("window.__nav=[];document.addEventListener('visibilitychange',()=>{})")
      T.click("#recOpen");T.wait_for_timeout(400)
      T.evaluate("Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'))");T.wait_for_timeout(100)
      T.evaluate("Object.defineProperty(document,'hidden',{configurable:true,get:()=>false});document.dispatchEvent(new Event('visibilitychange'))");T.wait_for_timeout(200)
      ok(T.is_visible("#recApp") and "방금 녹음한" in T.inner_text("#recApp") and "pri" in T.get_attribute("#recApp","class"),"녹음 앱에서 돌아오면 ‘녹음 파일 붙이기’를 앞세움")
    else:
      ok(T.is_visible("#recOpen") and "음성 메모 열기" in T.inner_text("#recOpen") and "음성 메모" in T.inner_text("#recHow"),"아이폰: 🎙 음성 메모 열기(단축어) 단추와 안내")
      T.click(".recsc summary");T.wait_for_timeout(150);ok("단축어" in T.inner_text(".recsc") and T.input_value("#recScI")=="교사녹음","단축어 만드는 법 · 기본 이름 교사녹음")
      T.fill("#recScI","수업 녹음");T.wait_for_timeout(100);ok(T.evaluate("localStorage.getItem('att-app-recsc')")=="수업 녹음" and T.inner_text("#recScN")=="수업 녹음","단축어 이름 바꾸면 기억")
      T.screenshot(path="shot/t180_recios.png")
      T.evaluate("window.__u=null;const o=Object.getOwnPropertyDescriptor(Location.prototype,'href');")
      T.click("#recOpen");T.wait_for_timeout(400)
      T.evaluate("Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'))");T.wait_for_timeout(100)
      T.evaluate("Object.defineProperty(document,'hidden',{configurable:true,get:()=>false});document.dispatchEvent(new Event('visibilitychange'))");T.wait_for_timeout(200)
      ok("방금 녹음한" in T.inner_text("#recApp"),"단축어(음성 메모)에서 돌아오면 녹음 파일 붙이기를 앞세움")
    c.close()
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
