src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ros=[["10101","가람"],["10102","가온"]]
st={"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ros,"phones":{"10101":"010-1234-5678","10102":"010-2222-3333"},"emails":{},"teachers":[],"msg":"m",
 "sessions":[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":False,"10102":True},"src":"t1:2:3"}]}}],"staff":[],
 "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":{"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""}},"adj":{},"days":{},"chg":[]}],"active":"t1"},
 "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-cheer','{\"am\":false,\"pm\":false}')}}catch(e){}"%json.dumps(json.dumps(st))
errs=[]
with sync_playwright() as p:
  b=p.chromium.launch()
  for W in (390,360):
    c=b.new_context(viewport={"width":W,"height":800},has_touch=True,service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
    T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(5600)
    nb=lambda:T.evaluate("(()=>{const e=document.querySelector('.newbar');if(!e)return null;const r=e.getBoundingClientRect();return getComputedStyle(e).display==='none'?'hidden':[Math.round(r.top),Math.round(r.bottom)]})()")
    ok(nb() not in (None,"hidden"),"%d: 백업 알림 띠가 뜸"%W)
    T.click(".navb[data-v=att]");T.wait_for_timeout(200);T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(300)
    k=T.evaluate("document.querySelector('#obsBar [data-k]').dataset.k");T.click("#obsBar [data-k='%s']"%k);T.wait_for_timeout(100)
    T.locator("#obsList [data-s='10101']").first.tap();T.wait_for_timeout(400)
    ok(T.is_visible("#utoast") and nb()=="hidden","%d: 되돌리기 알림이 떠 있는 동안 백업 띠는 잠시 숨김(겹치지 않음)"%W)
    if W==390:T.screenshot(path="shot/t180_undo.png")
    T.click("#utoast button");T.wait_for_timeout(450);ok(nb() not in (None,"hidden"),"%d: 되돌리기 알림이 닫히면 백업 띠가 다시 보임"%W)
    T.click(".navb[data-v=call]");T.wait_for_timeout(400)
    h=T.evaluate("(()=>{const e=document.querySelector('#abList .who .nowr');return e?[e.getClientRects().length,e.textContent]:null})()")
    ok(h and h[0]==1 and "010-1234-5678" in h[1],"%d: 결석 학생 전화번호가 한 줄 %s"%(W,h))
    ov=T.evaluate("(()=>{const r=document.querySelector('#abList .crow');return r.scrollWidth<=r.clientWidth+1})()");ok(ov,"%d: 결석 학생 줄이 가로로 넘치지 않음"%W)
    if W==360:T.locator("#abList .crow").first.screenshot(path="shot/t180_call.png")
    c.close()
  # 아침 인사 기분 단추: 낱말 중간 줄바꿈 없음 (같은 모양의 단추로 확인)
  c=b.new_context(viewport={"width":360,"height":800},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  r=T.evaluate("""(()=>{const d=document.createElement('div');d.className='moods';d.style.width='300px';d.innerHTML='<button><span>😢</span>마음이 무거워요</button><button><span>🙂</span>괜찮아요</button><button><span>😀</span>좋아요</button><button><span>😮‍💨</span>피곤해요</button>';document.body.appendChild(d);const b=d.firstChild,t=b.lastChild,rg=document.createRange();rg.selectNodeContents(t);const lines=[...rg.getClientRects()].length;const out=[getComputedStyle(b).wordBreak,lines];d.remove();return out})()""")
  ok(r[0]=="keep-all" and r[1]<=2,"아침 인사 ‘마음이 무거워요’는 낱말 단위로만 줄바꿈 "+str(r))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
