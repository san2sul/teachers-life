src=open('t50.py').read();exec(src.split('\nS={')[0])
import sys
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
# 5.91.1 보존 자동 검사: 실제 자료처럼 모든 항목을 채운 뒤 저장 → 다시 열기 → 백업 → 복원 → 두 기기 동기화(합치기)까지
# 처음 자료의 모든 값(잎 경로)이 끝까지 그대로인지 통째로 비교합니다. 새 항목을 만들고 정리 · 백업 · 동기화 목록에 넣는 것을 잊으면 여기서 실패합니다.
r1=[["10101","김가람"],["10102","이나래"],["10103","박다솜"],["10104","최라온"]];r2=[["10201","한바다"],["10202","윤사랑"]]
T0=1792200000000  # 2026-10-28 무렵(ms)
ses1=[{"id":"s0","date":"2026-10-26","time":"10:00","label":"2교시 물리학","p":{"10101":True,"10102":True,"10103":True},"src":"t1:0:2","lock":True,"lockAt":T0-200000000,
        "done":{"10104":T0-199000000},"tm":{"10101":T0-200100000,"10102":T0-200090000,"10103":T0-200080000},"lg":[["10101","in",T0-200100000],["10102","in",T0-200090000],["10103","in",T0-200080000],["10103","out",T0-200070000],["10103","in",T0-200060000]],"edAt":T0-199000000},
      {"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3","tm":{"10101":T0,"10102":T0+5000},"lg":[["10101","in",T0],["10102","in",T0+5000]]},
      {"id":"s9","date":"2026-10-27","time":"13:00","label":"5교시 물리학","p":{},"off":True,"offWhy":"체육대회"}]
obs1=[{"id":"o1","sid":"10101","date":"2026-10-26","tags":{"q":1,"help":2},"memo":"질문을 잘함","at":T0-199500000,"lg":[{"t":"10:12","k":"q"},{"t":"10:31","k":"help","c":"모둠 도움"},{"t":"10:40","k":"help","m":1}]}]
plan={"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20",
  "units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도","wk":"2026-10-26"},{"id":"a3","t":"뉴턴 법칙"},{"id":"ax","t":"실험 보충","add":"2026-10-27"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"}]}],
  "pg":{"c1":{"a1":{"st":"d","d":"2026-10-21","fx":1},"a2":{"st":"d","d":"2026-10-28","s":"s1","k":"t1:2:3:2026-10-28","h":[{"st":"h","d":"2026-10-26","s":"s0","k":"t1:0:2:2026-10-26","auto":1}]}},"c2":{"a1":{"st":"h","d":"2026-10-27","k":"t1:1:1:2026-10-27"}}},
  "orig":{"at":"2026-09-01","u":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"}]}]}}
cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":"물리실"},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"물리학","clsId":"c1","clsName":"","room":""}}
FULL={"active":"c1","list":[
  {"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{"10101":"010-1111-0001"},"gph":{"10101":[{"r":"어머니","p":"010-2222-0001"}]},"emails":{"10102":"nara@ex.com"},"teachers":[{"id":"tc1","name":"정담임","role":"담임","phone":"010-3333-0001"}],"msg":"{이름} 학생 결석 안내",
     "sessions":ses1,"obs":obs1,"snote":{"10102":[{"id":"sn1","k":"prom","t":"과제 내일 제출","at":"2026-10-27T09:00"}]},"low":{"10104":1},"sts":{"10101":{"t":"물리 탐구 보고서 우수","at":T0-1000}}}},
  {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s2","date":"2026-10-27","time":"09:00","label":"1교시 물리학","p":{"10201":True},"src":"t1:1:1","tm":{"10201":T0-86400000}}]}}],
 "staff":[{"id":"st1","name":"나교감","role":"교감","dept":"교무부","phone":"010-9999-0000"}],
 "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{"2026-10-30":{"start":"09:00","classMin":40,"breakMin":10,"lunchMin":60,"note":"단축수업"}},
   "chg":[{"id":"cg1","scope":"cell","d":3,"p":4,"from":"2026-10-29","to":"2026-10-29","type":"cancel","subject":"","clsId":"","clsName":"","room":"","reason":"출장","created":T0-5000}]}],"active":"t1",
   "acal":[{"g":"ac1","from":"2026-11-02","to":"2026-11-04","title":"현장체험학습","kind":"event"}]},
 "notes":{"t1:2:3:2026-10-28":{"progress":"1-2 가속도","pAuto":True,"memo":"실험 보고서 걷기","task":"활동지","meet":"","date":"2026-10-28","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":3,"updated":T0},
          "t1:0:2:2026-10-26":{"progress":"교과서 54~57쪽","memo":"","task":"","meet":"가람 목요일 점심","date":"2026-10-26","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":2,"updated":T0-200000000}},
 "events":[{"id":"ac1","date":"2026-11-02","start":"08:30","end":"","cat":"교무 업무","title":"현장체험학습","memo":"학사일정 파일에서 가져옴","clsId":"","alarm":-1,"important":False,"done":False,"notified":False,"endDate":"2026-11-04"},
           {"id":"e2","date":"2026-10-29","start":"12:30","end":"13:00","cat":"학생 면담","title":"가람 면담","memo":"","clsId":"c1","alarm":10,"important":True,"done":False,"notified":False}],
 "evals":[],"tasks":[{"id":"tk1","k":"perf","n":"1차 실험 보고서","due":"2026-10-30","cls":["c1"],"miss":{"c1":{"10103":"m"}},"at":"2026-10-20T00:00:00.000Z","year":2026,"term":"2학기"}],
 "recs":[{"id":"r1","k":"stu","sub":"cns","at":"2026-10-27T15:00","place":"상담실","blocks":[{"id":"bk1","t":"p","x":"진로 상담"}],"media":[],"stus":[{"sid":"10101","name":"김가람","phone":""}],"cns":{"who":"stu","how":"meet","tp":["진로"],"ac":""},"cAt":"2026-10-27T06:00:00.000Z"}],
 "plans":[plan],
 "flows":[{"id":"fl1","n":"실험 수업(내 틀)","steps":[{"id":"fs1","n":"도입","m":5,"al":"vib","memo":"","tool":"","fix":False},{"id":"fs2","n":"실험","m":35,"al":"snd","memo":"안전","tool":"tm","fix":False},{"id":"fs3","n":"정리","m":10,"al":"vib","memo":"","tool":"","fix":True}]}],
 "flowSub":{"물리학":"fl1"},"flowRun":{"2026-10-28|t1:2:3":{"st":"run","pt":T0,"adj":{"fs2":3},"fid":"fl1","at":T0}},"flowCfg":{"auto":True},
 "pnCfg":{"mode":"manual","set":1},"pnAuto":{"t1:0:2:2026-10-26":1},"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
EXTRA={"att-app-diary":json.dumps({"2026-10-27":{"m":3}}),"att-app-tplitems":json.dumps(["결석 안내"]),"att-app-tktpl-perf":"수행평가 안내 문구"}
def flat(o,p=""):
  out={}
  if isinstance(o,dict):
    for k,v in o.items():out.update(flat(v,p+"/"+str(k)))
    if not o:out[p]="{}"
  elif isinstance(o,list):
    for i,v in enumerate(o):out.update(flat(v,p+"["+str(i)+"]"))
    if not o:out[p]="[]"
  else:out[p]=o
  return out
def lost(a,b,skip=()):
  A=flat(a);B=flat(b);return [(k,A[k],B.get(k,"<없음>")) for k in A if not any(k.startswith(s) for s in skip) and (k not in B or B[k]!=A[k])]
def st(pg):return json.loads(pg.evaluate("localStorage.getItem('att-app-v2')"))
def ex(pg):return pg.evaluate("ks=>Object.fromEntries(ks.map(k=>[k,localStorage.getItem(k)]))",list(EXTRA))
errs=[]
def mk(b,state=None,extra=None,view="tt"):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",accept_downloads=True);c.route("**/*",handler)
  pg=c.new_page();pg.on("pageerror",lambda e:errs.append(str(e)));pg.add_init_script(FIX)
  init="try{if(!localStorage.getItem('att-app-lastver')){localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0');localStorage.setItem('att-app-view','%s');%s%s}}catch(e){}"%(view,
    ("localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-v2',%s);"%json.dumps(json.dumps(state))) if state else "",
    "".join("localStorage.setItem(%s,%s);"%(json.dumps(k),json.dumps(v)) for k,v in (extra or {}).items()))
  pg.add_init_script(init);pg.goto("https://tl.test/index.html");pg.wait_for_timeout(1800);return pg
with sync_playwright() as p:
  b=p.chromium.launch()
  A=mk(b,FULL,EXTRA)
  S0=st(A)
  L=lost(FULL,S0);ok(not L,"① 처음 열기: 넣은 자료가 하나도 빠지지 않음 "+str(L[:6]))
  # 앱에서 새로 만든 자료(출석 누른 시각 · 고친 기록 · 수업 진도 · 관찰 시각)
  A.click(".navb[data-v=tt]");A.wait_for_timeout(300);A.click(".ttmode [data-tm=week]");A.wait_for_timeout(300);A.click(".tc[data-d='2'][data-p='3']");A.wait_for_timeout(400);A.locator("#cmAtt").dispatch_event("click");A.wait_for_timeout(600)
  A.locator("#list .st").nth(2).click();A.wait_for_timeout(300);A.locator("#list .st").nth(0).click();A.wait_for_timeout(300)
  A.click("#pnFullO");A.wait_for_timeout(300);A.click("#pnFullBox [data-pc='a3|h']");A.wait_for_timeout(300);A.click("#pnFullX");A.wait_for_timeout(300)
  A.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");A.wait_for_timeout(400)
  k=A.evaluate("(document.querySelector('#obsBar [data-k]')||{dataset:{}}).dataset.k")
  if k:A.click("#obsBar [data-k='%s']"%k);A.wait_for_timeout(150);A.locator("#obsList [data-s='10102']").first.click();A.wait_for_timeout(500)
  S1=st(A);s1=[x for x in S1["list"][0]["data"]["sessions"] if x["id"]=="s1"][0]
  ok("10103" in s1.get("tm",{}) and len(s1.get("lg",[]))>=4 and S1["plans"][0]["pg"]["c1"].get("a3",{}).get("st")=="h","새로 만든 자료: 출석 누른 시각 · 고친 기록 · 이 수업 진도")
  ok(any(o["sid"]=="10102" and o.get("lg") for o in S1["list"][0]["data"].get("obs",[])) or not k,"새로 만든 자료: 관찰 기록 시각")
  # ② 앱 다시 열기
  A.reload();A.wait_for_timeout(1800);S2=st(A)
  L=lost(S1,S2,skip=("/flowRun",));ok(not L,"② 다시 열기: 하나도 빠지지 않음 "+str(L[:6]))
  # ③ 백업 → 다른 기기에서 복원(바꾸기)
  A.evaluate("()=>{document.querySelector('.navb[data-v=set]')?document.querySelector('.navb[data-v=set]').click():document.querySelector('#topBtns .navb[data-v=set]').click();navigator.canShare=undefined}");A.wait_for_timeout(300)
  with A.expect_download() as dl:A.evaluate("document.getElementById('backupFile').click()")
  bk=open(dl.value.path(),encoding="utf-8").read();bko=json.loads(bk)
  ok(all(k in (bko.get("extra") or {}) for k in EXTRA),"백업 파일에 기기 자료(기분 일기 · 템플릿) "+str(list((bko.get("extra") or {}).keys())))
  B=mk(b,{"active":"z","list":[{"id":"z","data":{"v":3,"cls":"","roster":[],"phones":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[],"active":""},"notes":{},"events":[]})
  B.evaluate("t=>{document.getElementById('sheet').hidden=true;const f=new File([t],'b.json',{type:'application/json'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('restoreFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",bk);B.wait_for_timeout(800)
  B.click("#rsReplace");B.wait_for_timeout(150);B.click("#rsReplace");B.wait_for_timeout(900);S3=st(B)
  L=lost(S2,S3,skip=("/active",));ok(not L,"③ 백업 → 복원: 하나도 빠지지 않음 "+str(L[:6]))
  E=ex(B);ok(all(E.get(k)==v for k,v in EXTRA.items()),"③ 복원: 기기 자료도 그대로")
  B.reload();B.wait_for_timeout(1500);L=lost(S3,st(B));ok(not L,"③ 복원 뒤 다시 열기도 그대로 "+str(L[:6]))
  # ④ 기기 연동: A가 올리고, 빈 기기 C가 받음
  A.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)");A.click("#gsLogin");A.wait_for_timeout(2500)
  ok(bool(store),"A가 드라이브에 올림")
  C=mk(b,None,None,"set")
  if C.is_visible("#wzHave"):C.click("#wzHave");C.wait_for_timeout(300)
  C.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)");C.click("#gsLogin");C.wait_for_timeout(3000)
  if C.locator("#flMerge").count() and C.is_visible("#flMerge"):C.click("#flMerge");C.wait_for_timeout(2000)
  S4=st(C);L=lost(S2,S4,skip=("/active",));ok(not L,"④ 다른 기기로 동기화: 하나도 빠지지 않음 "+str(L[:6]))
  E=ex(C);ok(all(E.get(k)==v for k,v in EXTRA.items()),"④ 동기화: 기기 자료도 그대로 "+str({k:(E.get(k) or "")[:20] for k in EXTRA}))
  # ⑤ 두 기기에서 따로 고친 뒤 합치기: A는 출석을 더 누르고, C는 다른 수업 진도를 기록 → 둘 다 남아야 함
  A.click(".navb[data-v=tt]");A.wait_for_timeout(300);A.click(".ttmode [data-tm=week]");A.wait_for_timeout(300);A.click(".tc[data-d='2'][data-p='3']");A.wait_for_timeout(400);A.locator("#cmAtt").dispatch_event("click");A.wait_for_timeout(500)
  A.evaluate("document.querySelector('[data-key=\"m:att\"]').click()");A.wait_for_timeout(400)
  t2=[y for y in st(A)["list"][0]["data"]["sessions"] if y["id"]=="s1"][0]["tm"].get("10102")
  A.locator("#list .st").nth(1).click(position={"x":8,"y":8});A.wait_for_timeout(300)
  ta=[y for y in st(A)["list"][0]["data"]["sessions"] if y["id"]=="s1"][0];ok(ta["tm"].get("10102")!=t2,"A에서 출석을 다시 누름(합치기 전) "+str([ta["tm"].get("10102"),t2,len(ta.get("lg",[]))]))
  C.click(".navb[data-v=tt]");C.wait_for_timeout(300);C.click(".ttmode [data-tm=week]");C.wait_for_timeout(300);C.click(".tc[data-d='0'][data-p='2']");C.wait_for_timeout(400);C.locator("#cmAtt").dispatch_event("click");C.wait_for_timeout(500)
  C.click("#pnFullO");C.wait_for_timeout(300);C.click("#pnFullBox [data-uo=u2]");C.wait_for_timeout(200);C.click("#pnFullBox [data-pc='b1|d']");C.wait_for_timeout(300);C.click("#pnFullX");C.wait_for_timeout(300)
  A.wait_for_timeout(4500);C.wait_for_timeout(4500)
  for pg in (A,C,A):
    pg.evaluate("()=>{const s=document.getElementById('sheet');if(s)s.hidden=true;document.querySelector('.navb[data-v=set]').click()}");pg.wait_for_timeout(300)
    pg.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)")
    if pg.locator("#gsPill").count() and pg.is_visible("#gsPill"):pg.click("#gsPill")
    pg.wait_for_timeout(2500)
  for nm,pg in (("A",A),("C",C)):
    s=st(pg);x=[y for y in s["list"][0]["data"]["sessions"] if y["id"]=="s1"][0];g=s["plans"][0]["pg"]["c1"]
    ok(x.get("tm",{}).get("10102")!=t2 and "10103" in x.get("tm",{}) and g.get("b1",{}).get("k")=="t1:0:2:2026-10-26" and g.get("a3",{}).get("st")=="h","⑤ %s: 두 기기의 고친 것(출석 누른 시각 · 다른 수업 진도)이 모두 남음 %s"%(nm,str([x.get("tm",{}).get("10102"),t2,g.get("b1"),g.get("a3"),len(x.get("lg",[])),store and max(v["ver"] for v in store.values())])))
    L=lost(S0,s,skip=("/active","/list[0]/data/sessions","/plans[0]/pg","/notes","/list[0]/data/obs","/flowRun"));ok(not L,"⑤ %s: 처음 자료도 그대로 %s"%(nm,str(L[:4])))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
