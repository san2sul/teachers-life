src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy,re
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def M(T,key="school:master"):return T.evaluate("k=>new Promise(r=>{const q=indexedDB.open('teachers-life-media');q.onsuccess=()=>{const g=q.result.transaction('m').objectStore('m').get('kv:'+k);g.onsuccess=()=>r(g.result?JSON.parse(g.result):null)}})",key)
def st(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
EMPTY={"active":"c0","list":[{"id":"c0","data":{"v":3,"cls":"","roster":[],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
ADM=copy.deepcopy(EMPTY);#ADM["tt"]["acal"]=[{"g":"x1","from":"2026-11-04","to":"2026-11-04","title":"체육대회","kind":"event"},{"g":"x2","from":"2026-11-19","to":"2026-11-19","title":"수능 휴업","kind":"cancel"},{"g":"x3","from":"2025-11-19","to":"2025-11-19","title":"작년 행사","kind":"event"}]
def dev(b,state,touch=False):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,has_touch=touch);c.route("**/*",handler);T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)))
  T.goto("https://tl.test/index.html");T.evaluate("s=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');if(!localStorage.getItem('att-app-ui'))localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));if(!localStorage.getItem('att-app-clsal'))localStorage.setItem('att-app-clsal','0');localStorage.setItem('att-app-setup','1')}",json.dumps(state));T.reload();T.wait_for_timeout(700);return T
def admin_setup(T,school="물리고등학교"):
  T.click(".navb[data-v=set]");T.evaluate("()=>{document.getElementById('d-school').open=true}");T.click("#schOpen");T.check("#schAgree");T.click("#schOnBtn");T.wait_for_timeout(400)
  T.set_input_files("#schFile","schf/v1.xlsx");T.wait_for_timeout(1200);T.click("#schGo");T.wait_for_timeout(400)
  T.fill("#schName",school);T.evaluate("document.getElementById('schName').dispatchEvent(new Event('change'))");T.wait_for_timeout(300)
def setpage(T):T.evaluate("()=>{document.getElementById('sheet').hidden=true;document.querySelector('.navb[data-v=set]').click();document.getElementById('d-pack').open=true}");T.wait_for_timeout(150)
def openfile(T,text):
  setpage(T);T.evaluate("t=>{const f=new File([t],'pack.json',{type:'application/json'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('packFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",text);T.wait_for_timeout(900)
def by(s,n):return [c for c in s["list"] if c["data"].get("cls")==n]
def dl(A):
  with A.expect_download() as d:A.click("#packMake")
  A.wait_for_timeout(600);return open(d.value.path(),encoding="utf-8").read()
def recv(B,pack,name,code,first=False):
  openfile(B,pack)
  if first:B.click("#pkOk");B.wait_for_timeout(200)
  if B.locator("#pmA").count():B.click("#pmA");B.wait_for_timeout(200)
  B.click(f"#pkList [data-t] >> text={name}");B.fill("#pkCode",code);B.click("#pkGo");B.wait_for_timeout(900)
def roster(s,n):return {r[0]:r[1] for r in by(s,n)[0]["data"]["roster"]}
def asg(A,name,hr=None,add=None):
  A.click("[data-st=asg]");A.wait_for_timeout(300);A.click(f"#schList [data-au] >> text={name}");A.wait_for_timeout(200)
  if hr is not None:A.click(f"[data-hr='{hr}']")
  if add:i=A.locator("[data-sj]").count()-1;A.click(f"[data-ti='{i}'][data-k='{add}']")
  A.click("#asgOk");A.wait_for_timeout(300)
with sync_playwright() as p:
  b=p.chromium.launch()
  A=dev(b,EMPTY);admin_setup(A);A.click("[data-st=asg]");A.wait_for_timeout(200);A.set_input_files("#asgFile","schf/asg_list.xlsx");A.wait_for_timeout(1000);A.click("#asgGo");A.wait_for_timeout(400)
  pack0=dl(A);m=M(A);codes={t["name"]:t["code"] for t in m["staff"] if t.get("code")}
  B=dev(b,EMPTY,touch=True);recv(B,pack0,"김물리",codes["김물리"],first=True);B.click("#pkApply");B.wait_for_timeout(600)
  setpage(B);ok(B.locator("#cdStart").count()==0,"optional: school hasn't turned 인계 카드 on → teacher sees no card entry")
  A.click("[data-st=card]");A.wait_for_timeout(200);ok(A.is_hidden("#cdOpts") and not A.is_checked("#opCdU"),"admin: off by default");A.check("#opCdU");A.wait_for_timeout(100)
  pack1=dl(A);P1=json.loads(pack1)
  ok(P1.get("enc") and P1["enc"]["crv"]=="P-256" and "d" not in P1["enc"],"pack carries 담당자 public key (signed), no private part")
  recv(B,pack1,"김물리",codes["김물리"]);B.click("#pkApply");B.wait_for_timeout(600)
  r11=roster(st(B),"1학년 1반");han=[k for k,v in r11.items() if v=="한마루"][0];ryu=[k for k,v in r11.items() if v=="류나래"][0]
  B.evaluate("([a])=>{const raw=JSON.parse(localStorage.getItem('att-app-v2'));const c=raw.list.find(x=>x.data.cls==='1학년 1반').data;c.sessions.push({id:'s1',date:'2026-10-19',time:'',label:'',p:Object.fromEntries(c.roster.filter(r=>r[0]!==a).map(r=>[r[0],true]))},{id:'s2',date:'2026-10-20',time:'',label:'',p:Object.fromEntries(c.roster.map(r=>[r[0],true]))});c.obs.push({id:'o1',sid:a,date:'2026-10-20',tags:{},memo:'실험 보고서를 꼼꼼히 씀',at:1});c.sts={[a]:{t:'세특 초안 내용',at:1}};localStorage.setItem('att-app-v2',JSON.stringify(raw))}",[han]);B.reload();B.wait_for_timeout(700)
  setpage(B);ok(B.locator("#cdStart").count()==1,"teacher: 인계 카드 entry in 학교에서 받기")
  B.click("#cdStart");B.wait_for_timeout(200);B.click("[data-cc]");B.wait_for_timeout(300)
  ok("1학년 1반 인계 카드" in B.inner_text("#sheetBox") and "출석 1/2" in B.inner_text(f"label:has([data-on='{han}'])"),"auto summary (attendance) per student")
  B.fill(f"[data-m='{han}']","발표를 좋아함. 수학 기초 보충 받음");B.uncheck(f"[data-on='{ryu}']");B.check("#cdObs");B.wait_for_timeout(200)
  ok("메모 쓴 학생 1명" in B.inner_text("#cdN") and "카드 24장" in B.inner_text("#cdN"),"counts: "+B.inner_text("#cdN"))
  B.check("#cdOnly");B.wait_for_timeout(100);ok("카드 1장" in B.inner_text("#cdN"),"option: only students with a memo");B.uncheck("#cdOnly")
  B.click("#cdBack");B.wait_for_timeout(200);B.click("[data-cc]");B.wait_for_timeout(200);ok(B.input_value(f"[data-m='{han}']").startswith("발표를") and not B.is_checked(f"[data-on='{ryu}']"),"draft remembered")
  with B.expect_download() as d:B.click("#cdMake")
  B.wait_for_timeout(400);cf=open(d.value.path(),encoding="utf-8").read();C1=json.loads(cf)
  ok(C1["kind"]=="teachers-life-cards" and C1["n"]==24 and "한마루" not in cf and "발표" not in cf and "010-" not in cf,"card file sealed: nothing readable")
  # another admin can't open it
  G=dev(b,EMPTY);admin_setup(G);G.click("[data-st=card]");G.wait_for_timeout(200);G.set_input_files("#cdIn",d.value.path());G.wait_for_timeout(800)
  ok(not M(G).get("cards"),"different 담당자 cannot open the card file")
  # admin imports
  A.click("[data-st=card]");A.wait_for_timeout(200);A.set_input_files("#cdIn",d.value.path());A.wait_for_timeout(800)
  mA=M(A);hu=[x["uid"] for x in mA["students"] if x["name"]=="한마루"][0];ok(len(mA["cards"])==24 and mA["cards"][hu][0]["memo"].startswith("발표를") and mA["cards"][hu][0]["obs"][0]["memo"].startswith("실험") and "sts" not in mA["cards"][hu][0],"admin: 24 cards attached to student ids (세특 not included)")
  ok("카드 있는 학생 24/" in A.inner_text("#schList") and "김물리" in A.inner_text("#schList"),"card tab summary")
  tx=A.inner_text("#schList");print("  status:",tx[tx.find("제출 현황"):tx.find("제출 현황")+120].replace("\n"," | "))
  ok("담임 2명 · 보냄 1 · 아직 1 · 안 씀 0" in tx,"submission status by homeroom teacher")
  ok(A.locator("#cdNag").count()==1 and "1명께 문자" in A.inner_text("#cdNag"),"nudge button for those who haven't sent")
  A.click(".cdst .prow:has-text('이수학') [data-skip]");A.wait_for_timeout(300);tx=A.inner_text("#schList")
  ok("안 씀 1" in tx and A.locator("#cdNag").count()==0,"'안 씀' removes a teacher from status/nudge")
  A.click(".cdst .prow:has-text('이수학') [data-skip]");A.wait_for_timeout(300)
  A.check("#opCdE");A.wait_for_timeout(300);tx=A.inner_text("#schList");ok("담임 · 교과 담당" in tx and "일부 1/" in tx,"subject classes counted when chosen")
  A.uncheck("#opCdE");A.wait_for_timeout(300)
  A.set_input_files("#cdIn",d.value.path());A.wait_for_timeout(800);ok(len(M(A)["cardSrc"])==1 and len(M(A)["cards"][hu])==1,"same file twice: replaced, not duplicated")
  # next year: 정교감 becomes 1-1 homeroom, 김물리 not; 이수학 also teaches 1-1
  asg(A,"김물리",hr="");asg(A,"정교감",hr="1-1");asg(A,"이수학",add="1-1")
  pack2=dl(A)
  C=dev(b,EMPTY);recv(C,pack2,"정교감",M(A)["staff"][[t["name"] for t in M(A)["staff"]].index("정교감")]["code"],first=True)
  ok("인계 카드 24명" in C.inner_text("#sheetBox"),"new homeroom: preview shows 인계 카드");C.click("#pkApply");C.wait_for_timeout(600)
  c11=by(st(C),"1학년 1반")[0]["data"];ok(len(c11.get("cards",{}))==24 and c11["cards"][han][0]["memo"].startswith("발표를") and c11["cards"][han][0]["from"]=="김물리","new homeroom got the cards")
  C.click(".navb[data-v=att]");C.wait_for_timeout(200);C.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");C.wait_for_timeout(200);C.click(f"#obsList [data-s='{han}']");C.click("#obAll");C.wait_for_timeout(200)
  sh=C.inner_text("#sheetBox");print("  student sheet:",sh[:300].replace("\n"," | "));ok("인계 카드 1장" in sh and "김물리 선생님" in sh and "발표를 좋아함" in sh and "결석 1회" in sh,"card shown in student sheet")
  C.reload();C.wait_for_timeout(700);ok(len(by(st(C),"1학년 1반")[0]["data"].get("cards",{}))==24,"cards survive reload")
  D=dev(b,EMPTY);recv(D,pack2,"이수학",codes["이수학"],first=True);D.click("#pkApply");D.wait_for_timeout(500)
  ok(not by(st(D),"1학년 1반")[0]["data"].get("cards"),"subject teacher: no cards by default")
  B2=dev(b,EMPTY);recv(B2,pack2,"김물리",codes["김물리"],first=True);B2.click("#pkApply");B2.wait_for_timeout(500)
  ok(all(not c["data"].get("cards") for c in st(B2)["list"]),"author doesn't get own cards back")
  A.click("[data-st=card]");A.wait_for_timeout(200);A.check("#opCdS");A.wait_for_timeout(100);pack3=dl(A)
  recv(D,pack3,"이수학",codes["이수학"]);D.click("#pkApply");D.wait_for_timeout(500)
  ok(len(by(st(D),"1학년 1반")[0]["data"].get("cards",{}))==24,"subject teacher gets cards when 담당자 allows")
  # pick mode never carries cards
  A.click("[data-st=asg]");A.wait_for_timeout(300);A.check("#opMP");pack4=json.loads(dl(A));pc=M(A)["pickCode"]
  E=dev(b,EMPTY);openfile(E,json.dumps(pack4,ensure_ascii=False));E.click("#pkOk");E.wait_for_timeout(200);E.click("#pmP");E.wait_for_timeout(200);E.click("#pcList [data-k='1-1']");E.fill("#pcCode",pc);E.click("#pcGo");E.wait_for_timeout(900)
  ok("인계 카드" not in E.inner_text("#sheetBox"),"pick mode (shared code): no cards")
  # reset removes received cards but keeps records
  setpage(C);C.click("#pkReset");C.wait_for_timeout(200);C.click("#rsGo");C.click("#rsGo");C.wait_for_timeout(400)
  ok(all(not c["data"].get("cards") for c in st(C)["list"]),"초기화 removes received cards")
  # handover with new key: old card files still open
  A.click("[data-st=cls]");A.wait_for_timeout(200);A.click("#hoMake");A.wait_for_timeout(1200);code=A.inner_text("#hoCode")
  with A.expect_download() as h:A.click("#hoSave")
  A.wait_for_timeout(300);A.click("#skNo")
  N=dev(b,EMPTY);N.click(".navb[data-v=set]");N.evaluate("()=>{document.getElementById('d-school').open=true}");N.click("#schOpen");N.wait_for_timeout(200);N.set_input_files("#hoIn0",str(h.value.path()));N.wait_for_timeout(400)
  N.fill("#hoIn",code);N.click("#hoGo");N.wait_for_timeout(1200);N.check("[name=hoK][value=new]");N.click("#hoApply");N.wait_for_timeout(1200)
  ok(len(M(N)["cards"])==24,"cards moved with handover")
  N.click("[data-st=card]");N.wait_for_timeout(200);N.set_input_files("#cdIn",d.value.path());N.wait_for_timeout(800);ok(len(M(N)["cardSrc"])==1 and len(M(N)["cards"])==24,"new 담당자 (new code) can still open card files sealed to the old key")
  b.close()
print("fails",F);print(errs)
