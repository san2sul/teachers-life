src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"],["10103","나래"],["10104","다온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":False,"10103":False,"10104":False},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{"10102":"010-1111-2222","10103":"010-3333-4444","10104":"010-5555-6666"},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{"t1:0:2:2026-10-26":{"progress":"1-2 가속도 (반만)","memo":"실험 보고서 걷기","date":"2026-10-26","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":2,"updated":1}},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"},"a2":{"st":"h","d":"2026-10-26","k":"t1:0:2:2026-10-26"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  raw=lambda k:T.evaluate("k=>localStorage[k]===undefined?null:localStorage[k]",k)
  real0=raw("att-app-v2");ok(real0 and "1학년 1반" in real0 and T.locator("#pracBar").is_hidden(),"보통 모드: 실제 자료 · 체험 띠 없음")
  T.goto("https://tl.test/index.html?practice");T.wait_for_timeout(1000)
  ok(T.is_visible("#pracBar") and "?practice" not in T.url,"?practice 로 열면 체험 모드 띠, 주소에서 practice 지움 "+T.url)
  pr=raw("tlprac:att-app-v2");ok(pr and "체험 1학년 1반" in pr and "체험 1학년 2반" in pr,"가상 학급 두 개가 따로 저장(tlprac:)")
  P0=json.loads(pr);ok(len(P0["staff"])==12 and len(P0["list"][0]["data"]["teachers"])==4 and P0["plans"][0]["subj"]=="과학" and P0["flowSub"]=={"과학":"b:3"} and len(P0["tt"]["list"][0]["cells"])==35,"가상 교직원 12명 · 수업 교사 · 진도표 · 수업 흐름 · 시간표 35칸")
  ok(raw("att-app-v2")==real0,"실제 자료는 그대로")
  ok(T.locator("#wiz:not([hidden])").count()==0,"처음 설정 안내 없이 바로")
  T.click(".navb[data-v=todo]");T.wait_for_timeout(500)
  hero=T.inner_text("#v-todo .nowhero");ok("3교시 과학" in hero and "체험 1학년 1반" in hero,"지금 수업 카드(3교시 과학 · 체험 1학년 1반) "+hero.replace("\n"," ")[:80])
  row=T.locator("#v-todo .tdl:has-text('3교시 과학')").first.inner_text().replace("\n"," ");ok("지난" in row and "반만" in row and "오늘" in row,"오늘 수업 목록에 지난 시간 → 오늘 진도 "+row[:120])
  T.click(".navb[data-v=call]");T.wait_for_timeout(400);T.click("#ctabs [data-c=staff]");T.wait_for_timeout(300)
  ok("나교감" in T.inner_text("#v-call") and "보건교사" in T.inner_text("#v-call"),"연락 → 교직원 연락에 가상 교직원")
  # 체험 중 출석 체크
  T.click(".navb[data-v=todo]");T.wait_for_timeout(400);T.click("#v-todo .nowhero [data-nhgo]");T.wait_for_timeout(700)
  n0=len(json.loads(raw("tlprac:att-app-v2"))["list"][0]["data"]["sessions"])
  ok(n0==7 and raw("att-app-v2")==real0,"체험에서 출석 체크 → 체험 자료에만 저장(6→7) "+str(n0))
  # 처음으로
  T.click("#pracReset");T.wait_for_timeout(200);ok("정말" in T.inner_text("#pracReset"),"처음으로: 한 번 더 눌러 확인");T.click("#pracReset");T.wait_for_timeout(1500)
  n1=len(json.loads(raw("tlprac:att-app-v2"))["list"][0]["data"]["sessions"]);ok(n1==6 and T.is_visible("#pracBar"),"↺ 처음으로 → 가상 자료 처음 상태(7→6), 체험은 계속 "+str(n1))
  # 끝내기
  T.click("#pracEnd");T.wait_for_timeout(1200)
  ok(T.locator("#pracBar").is_hidden() and T.evaluate("sessionStorage.getItem('tl-practice')") is None,"체험 끝내기 → 보통 모드")
  T.click(".navb[data-v=att]");T.wait_for_timeout(400);ok("체험" not in T.inner_text("#v-att"),"원래 학급 자료로 돌아옴")
  ok(raw("att-app-v2")==real0,"실제 자료 변함 없음")
  # 설정에서 시작
  T.click("#topBtns .setb");T.wait_for_timeout(400);T.click("#d-prac summary");T.wait_for_timeout(200)
  ok("연수 안내 주소" in T.inner_text("#d-prac") and "?practice" in T.inner_text("#d-prac"),"설정: 체험 모드 칸 · 연수 안내 주소")
  T.click("#pracGo");T.wait_for_timeout(1200);ok(T.is_visible("#pracBar") and "체험 1학년" in T.inner_text("body"),"설정에서 체험 모드 시작")
  T.reload();T.wait_for_timeout(900);ok(T.is_visible("#pracBar"),"새로 고쳐도 체험 유지")
  P2=c.new_page();P2.on("pageerror",lambda e:errs.append(str(e)));P2.add_init_script(FIX);P2.goto("https://tl.test/index.html");P2.wait_for_timeout(900)
  ok(P2.locator("#pracBar").is_hidden(),"다른 창(새로 연 앱)은 보통 모드")
  T.click("#topBtns .setb");T.wait_for_timeout(300);T.click("#d-prac summary");T.wait_for_timeout(200);ok("지금은 체험 모드" in T.inner_text("#d-prac"),"체험 중 설정 칸 안내")
  ok(T.locator("#gsLogin").count()==1,"구글 로그인 단추 있음")
  T.evaluate("document.getElementById('gsLogin').click()");T.wait_for_timeout(200);ok("구글 연동을 쓰지 않습니다" in T.inner_text("body"),"체험 중 구글 로그인 막음")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
