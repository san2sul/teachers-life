src=open('audit2.py').read();exec(src.split("sizes=")[0])
import re,urllib.parse
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"]],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
import time as _t
_OFF=int(1792995600000-_t.time()*1000)
FIX="(()=>{const R=Date,off=%d;"%_OFF+"class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
def setdt(T,id,v):
  y,m,d,h,i=int(v[0:4]),int(v[5:7]),int(v[8:10]),int(v[11:13]),int(v[14:16])
  for p,x in (("y",y),("m",m),("d",d),("h",h),("i",i)):T.select_option(f"#{id} [data-p={p}]",str(x));T.wait_for_timeout(30)
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def sv(T):return [r for r in root(T)["recs"] if r["k"]=="survey"][-1]
def flush(T):T.wait_for_timeout(560)
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":430,"height":900},service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script("window.__goSpy=[];window.__fileSpy=[];window.__printSpy=[];")
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click("[data-wn=survey]");T.wait_for_timeout(400)
  ok(T.locator(".svtab [data-tab]").count()==3 and T.is_checked("#svPv"),"설문 만들기 · 개인정보 동의 기본 켜짐")
  T.fill("#svTi","진로 활동 만족도");T.fill("#svDs","5분 정도 걸립니다.")
  T.click("[data-nm='2']");T.wait_for_timeout(200)
  ok(T.locator("#svSt").count()==0 and "게시하면 바로 시작" in T.inner_text("#svSum"),"기본: 바로 시작 · 직접 마감")
  T.click("[data-svs='1']");T.wait_for_timeout(200);T.click("[data-sve='1']");T.wait_for_timeout(200)
  ok([T.locator("#svSt select").nth(k).get_attribute("data-p") for k in range(5)]==["y","m","d","h","i"],"일시 고르기: 연도 → 월 → 일 → 시 → 분 순서")
  setdt(T,"svSt","2026-10-20T09:00");setdt(T,"svEn","2026-10-30T18:00")
  T.click("[data-svm='1']");T.wait_for_timeout(200);T.fill("#svN","3");T.dispatch_event("#svN","input")
  ok("2026년 10월 20일 09:00에 시작" in T.inner_text("#svSum") and "선착순 3명" in T.inner_text("#svSum") and "2026년 10월 30일 18:00에 마감" in T.inner_text("#svSum"),"요약: 시작 예약 · 마감 예약 · 선착순")
  def q(i):return T.locator("#sheetBox .svq").nth(i)
  # 섹션 1: q1 객관식 (예/아니오)
  q(0).locator("[data-qt]").fill("활동에 참여했나요?");q(0).locator("[data-qr]").check()
  q(0).locator("[data-qo]").nth(0).fill("예");q(0).locator("[data-qo]").nth(1).fill("아니오")
  T.click("#svAddS");T.wait_for_timeout(250);T.click("#svAddS");T.wait_for_timeout(250)
  ok(T.locator("#sheetBox .svsec").count()==3,"섹션 3개")
  # 분기: 아니오 → 섹션 3
  q(0).locator("[data-go][data-gi='1']").select_option(index=2);T.wait_for_timeout(100)
  # 섹션 2 문항(척도) + 추가 문항들
  s2=T.locator("#sheetBox .svsec").nth(1)
  s2.locator(".svq [data-qk]").select_option("scale");T.wait_for_timeout(250);s2=T.locator("#sheetBox .svsec").nth(1);s2.locator(".svq [data-qt]").fill("만족도는?");s2.locator(".svq [data-qr]").check()
  for k,t in [("cb","좋았던 활동 (2개까지)"),("grid","항목별 평가"),("cgrid","원하는 시간"),("matrix","요일별 가능 인원"),("dd","학년"),("long","하고 싶은 말"),("date","가능한 날짜")]:
    s2=T.locator("#sheetBox .svsec").nth(1);s2.locator("[data-qa]").click();T.wait_for_timeout(200)
    s2=T.locator("#sheetBox .svsec").nth(1);last=s2.locator(".svq").last;last.locator("[data-qk]").select_option(k);T.wait_for_timeout(200)
    s2=T.locator("#sheetBox .svsec").nth(1);s2.locator(".svq").last.locator("[data-qt]").fill(t)
  s2=T.locator("#sheetBox .svsec").nth(1);cbq=s2.locator(".svq").nth(1);cbq.locator("[data-qmx]").fill("2");cbq.locator("[data-qoth]").check();T.wait_for_timeout(200)
  s2=T.locator("#sheetBox .svsec").nth(1);s2.locator("[data-snx]").select_option("end");T.wait_for_timeout(100)
  s3=T.locator("#sheetBox .svsec").nth(2);s3.locator(".svq [data-qk]").select_option("short");T.wait_for_timeout(200);s3=T.locator("#sheetBox .svsec").nth(2);s3.locator(".svq [data-qt]").fill("참여하지 못한 이유");flush(T)
  r=sv(T);v=r["sv"];qs=[q for s in v["sec"] for q in s["qs"]]
  ok([q["k"] for q in qs]==["mc","scale","cb","grid","cgrid","matrix","dd","long","date","short"],"문항 종류 10가지: "+str([q["k"] for q in qs]))
  ok(qs[0]["go"]=={"1":v["sec"][2]["id"]} and v["sec"][1].get("nx")=="end","답에 따라 섹션 이동 · 섹션 끝 제출")
  ok(v["nm"]==2 and v["em"]["lim"]==1 and v["em"]["n"]==3 and v["st"]=="2026-10-20T09:00","응답자 · 기간 · 인원 제한")
  T.screenshot(path="shot/t139_make.png")
  # 게시
  T.click("[data-tab=pub]");T.wait_for_timeout(300);T.fill("#svTo","teacher@school.go.kr");T.click("#svLink");T.wait_for_timeout(800)
  url=T.input_value("#svU");ok("/survey.html#q=z1." in url and "진행 중" in T.inner_text("#sheetBox h2"),"설문 링크 · 진행 중")
  T.screenshot(path="shot/t139_pub.png")
  # ---- 응답 1 (예 → 섹션 2)
  def respond(name,yes,kiosk=False,extra=None):
    cc=c if kiosk else b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,service_workers="block",timezone_id="Asia/Seoul")
    if not kiosk:cc.route("**/*",handler)
    P=cc.new_page();P.on("pageerror",lambda e:errs.append(str(e)));P.add_init_script(FIX);P.goto(url+("&kiosk=1" if kiosk else ""));P.wait_for_timeout(700)
    P.click("#go");ok(not P.locator("#gerr").is_hidden(),"동의 안 하면 시작 안 됨") if name=="가람" else None
    P.check("#agree");P.click("#go");
    if name=="가람":ok("이름" in P.inner_text("#gerr"),"이름 필수")
    P.fill("#nm",name);P.click("#go");P.wait_for_timeout(200)
    P.click("#next");P.wait_for_timeout(200);ok(P.locator(".qerr").count()==1,"필수 문항 확인") if name=="가람" else None
    P.check("[data-q] input[value='%d']"%(0 if yes else 1));P.click("#next");P.wait_for_timeout(300)
    if yes:
      P.check(".scale input[value='4']" if name!="라온" else ".scale input[value='5']")
      cb=P.locator("[data-q]").nth(1);cb.locator("input[type=checkbox]").nth(0).check();cb.locator("input[type=checkbox]").nth(1).check();cb.locator("input[type=checkbox]").nth(2).check()
      P.click("#next");P.wait_for_timeout(200);ok("2개까지" in P.inner_text(".qerr"),"최대 선택 수 확인") if name=="가람" else None
      cb.locator("input[type=checkbox]").nth(2).uncheck()
      g=P.locator("[data-q]").nth(2);g.locator("tr").nth(1).locator("input").nth(0).check();g.locator("tr").nth(2).locator("input").nth(1).check()
      cg=P.locator("[data-q]").nth(3);cg.locator("tr").nth(1).locator("input").nth(0).check();cg.locator("tr").nth(1).locator("input").nth(2).check()
      P.locator("[data-mx]").nth(0).fill("3명");P.select_option("[data-q]:nth-of-type(7) select",index=2) if False else P.locator("#body select.f").select_option("1")
      P.locator("#body textarea.f").fill("재미있었어요");P.locator("input[type=date]").fill("2026-11-02")
      if name=="가람":P.screenshot(path="shot/t139_resp.png",full_page=True)
      P.click("#next");P.wait_for_timeout(600)
    else:
      ok("참여하지 못한 이유" in P.inner_text("#body"),"‘아니오’ → 섹션 3으로 건너뜀")
      P.locator("#body input.f").fill("병결");P.click("#next");P.wait_for_timeout(600)
    if kiosk:
      ok("앱에 들어갔습니다" in P.inner_text("#done"),"이 기기 응답: 자동으로 앱에");P.close();return None
    href=P.get_attribute("#ml","href");body=urllib.parse.unquote(href.split("body=")[1]);m=re.search(r"(https?://\S+#a=[A-Za-z0-9_\-.]+)",body)
    ok(href.startswith("mailto:teacher%40school.go.kr") and m,"제출 → 선생님께 이메일 · 문자로 보내기")
    if name=="가람":P.screenshot(path="shot/t139_done.png")
    P.close();return m.group(1)
  a1=respond("가람",True);a2=respond("나래",False);respond("다솜",True,kiosk=True)
  T.bring_to_front();T.evaluate("window.dispatchEvent(new Event('focus'))");T.wait_for_timeout(800)
  ok(len(sv(T)["resp"])==1,"이 기기 응답이 앱에 자동으로 들어옴")
  T.click("[data-tab=resp]");T.wait_for_timeout(300);T.fill("#svIn",a1+"\n이것도\n"+a2);T.click("#svImp");T.wait_for_timeout(800)
  r=sv(T);ok(len(r["resp"])==3,"받은 응답 링크 붙여 넣기 → 3개")
  T.fill("#svIn",a1);T.click("#svImp");T.wait_for_timeout(600);ok(len(sv(T)["resp"])==3,"같은 응답은 두 번 안 들어감")
  # 4번째 → 인원 제한으로 집계 제외
  a4=respond("라온",True);T.bring_to_front();T.fill("#svIn",a4);T.click("#svImp");T.wait_for_timeout(800)
  r=sv(T);ok(len(r["resp"])==4,"4번째 응답도 보관")
  ok("집계 3개" in T.inner_text("#sheetBox") and "마감(인원 다 참)" in T.inner_text("#sheetBox h2"),"인원 제한 3명: 집계 3 · 마감")
  qs=[q for s in r["sv"]["sec"] for q in s["qs"]];sm=T.inner_text("#svSum")
  ok("평균 4.00" in sm,"척도 평균 (먼저 온 3명: 4, 4 · 라온은 인원 초과로 제외): "+re.sub(r"\s+"," ",sm)[:120])
  ok(T.locator("#svSum .svgt").count()>=3,"그리드 · 행렬 집계 표")
  T.screenshot(path="shot/t139_sum.png",full_page=True)
  T.click("#svCsv");T.wait_for_timeout(300);fs=T.evaluate("window.__fileSpy");ok(fs and fs[-1]["name"]=="진로 활동 만족도_응답.csv","엑셀(CSV) 받기")
  T.click("#svRes");T.wait_for_timeout(500);T.click("#srP");T.wait_for_timeout(300);ok(len(T.evaluate("window.__printSpy"))==1,"결과 인쇄 · PDF")
  # 앱 주소로 응답 링크 열기 (#a=)
  T.evaluate("document.getElementById('sheet').hidden=true")
  A2=c.new_page();A2.on("pageerror",lambda e:errs.append(str(e)));A2.add_init_script(FIX);A2.goto(a2.replace("https://tl.test/","https://tl.test/index.html"));A2.wait_for_timeout(1500)
  ok("이미 있는 응답" in A2.inner_text("body"),"응답 링크로 앱 열기 → 넣기 (이미 있으면 안내)");A2.close()
  # 기간 밖
  r=sv(T);rv=r["sv"]
  def link_with(st,en):
    return T.evaluate("([id,st,en])=>{const r=S.recs.find(x=>x.id===id)}",[r["id"],st,en]) if False else None
  T.click("#wrCard [data-wsv]");T.wait_for_timeout(300);T.click("[data-tab=make]");T.wait_for_timeout(300)
  setdt(T,"svSt","2026-11-01T09:00");setdt(T,"svEn","2026-11-05T18:00");T.click("[data-svm='0']");T.wait_for_timeout(200)
  ok("그때까지 들어온 응답을 모두 받음" in T.inner_text("#svSum") and T.locator("#svN").count()==0,"마감 때까지 모두 받기로 바꾸기");flush(T)
  T.click("[data-tab=pub]");T.wait_for_timeout(300);ok("예약됨" in T.inner_text("#sheetBox h2"),"시작 전이면 ‘예약됨’")
  T.click("#svLink");T.wait_for_timeout(700);u2=T.input_value("#svU")
  P=c.new_page();P.add_init_script(FIX);P.goto(u2);P.wait_for_timeout(600);ok("아직 시작 전" in P.inner_text("#gate"),"설문 페이지: 시작 전 안내");P.close();P=c.new_page();P.add_init_script(FIX);P.goto(u2+"&preview=1");P.wait_for_timeout(600)
  ok(not P.locator("#pvb").is_hidden() and P.locator("#agree").count()==1,"미리 보기는 시작 전에도 열림");P.close()
  T.click("[data-tab=make]");T.wait_for_timeout(300);setdt(T,"svSt","2026-10-01T09:00");setdt(T,"svEn","2026-10-10T09:00");flush(T)
  T.click("[data-tab=pub]");T.wait_for_timeout(300);ok("마감(시한 지남)" in T.inner_text("#sheetBox h2"),"마감 시한 지나면 마감");T.click("#svLink");T.wait_for_timeout(700);u3=T.input_value("#svU")
  P=c.new_page();P.add_init_script(FIX);P.goto(u3);P.wait_for_timeout(600);ok("마감된 설문" in P.inner_text("#gate"),"설문 페이지: 마감 안내");P.close()
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
