src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
R1=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"]]
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  cells["3-4"]={"subject":"물리학","clsId":"c1","clsName":"","room":""}   # 목요일(22일) 1교시 · 4교시 두 번
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  ses=[{"id":"s1","date":"2026-10-22","time":"09:00","label":"1교시 물리학","src":"t1:3:1","p":{"10101":True,"10102":True,"10104":True}},
       {"id":"s4","date":"2026-10-22","time":"12:00","label":"4교시 물리학","src":"t1:3:4","p":{"10101":True,"10103":True,"10104":True}},
       {"id":"s5","date":"2026-10-21","time":"09:05","label":"","p":{"10101":True,"10102":True,"10103":True}}]
  tasks=[{"id":"k1","k":"perf","n":"실험 발표","due":"2026-10-22","cls":["c1"],"miss":{},"at":"2026-10-20T00:00:00Z"},
         {"id":"k2","k":"form","n":"퀴즈","due":"2026-10-22","cls":["c1"],"miss":{},"tm":{"c1":{"p":4,"time":"12:00","l":"4교시 물리학"}},"at":"2026-10-19T00:00:00Z"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":R1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}}],"staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":tasks,"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-22T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def task(T,i):return [x for x in root(T)["tasks"] if x["id"]==i][0]
def miss(T,i):return task(T,i).get("miss",{}).get("c1",{})
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX)
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','task');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  P0=json.dumps(root(T)["list"][0]["data"]["sessions"],sort_keys=True)
  ok(miss(T,"k1")=={},"같은 날 수업 두 번 + 시간 안 정함 → 반영하지 않음(확정 불가): "+str(miss(T,"k1")))
  ok(miss(T,"k2")=={"10102":"m"},"4교시로 정한 평가 → 4교시 출석의 결석 학생만: "+str(miss(T,"k2")))
  # sheet warns
  T.locator("#ttTasks .tkrow",has_text="실험 발표").click();T.wait_for_timeout(250);T.click("#sheetBox [data-hc]");T.wait_for_timeout(250)
  ok(T.locator("#sheetBox .tkatt.warn").count()==1 and "2번" in T.inner_text("#sheetBox .tkatt"),"체크 창에 ‘수업 시간을 정해 주세요’ 경고")
  T.screenshot(path="shot/t134_warn.png")
  T.evaluate("document.getElementById('sheet').hidden=true");T.wait_for_timeout(100)
  # edit: choose 1교시
  T.locator("#ttTasks .tkrow",has_text="실험 발표").click();T.wait_for_timeout(250);T.click("#hbEdit");T.wait_for_timeout(300)
  chips=T.evaluate("[...document.querySelectorAll('#tkTm [data-tmc]')].map(b=>b.textContent)")
  ok(chips==["1교시 물리학 (09:00)","4교시 물리학 (12:00)"],"고치기 창에 그 날 수업 시간 두 개: "+str(chips))
  ok(T.locator("#tkTm .tkwarn").count()==1,"안 고르면 경고")
  T.screenshot(path="shot/t134_edit.png")
  T.click("#tkTm [data-tmi='0']");T.wait_for_timeout(150);ok(T.get_attribute("#tkTm [data-tmi='0']","aria-pressed")=="true","1교시 선택")
  T.click("#tkOk");T.evaluate("()=>{if(document.getElementById('tkScNx')){document.getElementById('skNo').click();const g=document.getElementById('tkSaGo');if(g)g.click()}}");T.wait_for_timeout(400)
  ok(task(T,"k1").get("tm",{}).get("c1",{}).get("p")==1,"평가 시간 저장(1교시)")
  ok(miss(T,"k1")=={"10103":"m"},"1교시 출석의 결석 학생만 반영: "+str(miss(T,"k1")))
  ok("1교시" in T.inner_text("#sheetBox") or True,"")
  # switch to 4교시 → marks follow
  T.click("#hbEdit");T.wait_for_timeout(300);T.click("#tkTm [data-tmi='1']");T.click("#tkOk");T.evaluate("()=>{if(document.getElementById('tkScNx')){document.getElementById('skNo').click();const g=document.getElementById('tkSaGo');if(g)g.click()}}");T.wait_for_timeout(400)
  ok(miss(T,"k1")=={"10102":"m"},"4교시로 바꾸면 4교시 결석 학생으로 바뀜: "+str(miss(T,"k1")))
  ok(json.dumps(root(T)["list"][0]["data"]["sessions"],sort_keys=True)==P0,"출석 체크 결과는 그대로")
  T.evaluate("document.getElementById('sheet').hidden=true");T.wait_for_timeout(100)
  # new task on 21일(수업 한 번, 출석 체크는 src 없이 09:05) → 시간 저절로 선택
  T.click("#ttTkNew");T.wait_for_timeout(250);T.fill("#tkN","수요일 과제");T.click("#tkK [data-k='hw']");T.wait_for_timeout(100)
  T.fill("#tkD","2026-10-21");T.dispatch_event("#tkD","change");T.click("#tkC [data-c='c1']");T.wait_for_timeout(200)
  ch=T.evaluate("[...document.querySelectorAll('#tkTm [data-tmc]')].map(b=>[b.textContent,b.getAttribute('aria-pressed')])")
  ok(len(ch)==1 and ch[0][1]=="true","수업이 하나뿐이면 저절로 선택: "+str(ch))
  ok(T.input_value("#tkN")=="수요일 과제","종류를 바꿔도 이름 유지")
  T.click("#tkOk");T.evaluate("()=>{if(document.getElementById('tkScNx')){document.getElementById('skNo').click();const g=document.getElementById('tkSaGo');if(g)g.click()}}");T.wait_for_timeout(400)
  nk=[x for x in root(T)["tasks"] if x["n"]=="수요일 과제"][0]
  ok(nk["miss"].get("c1")=={"10104":"m"},"그 수업 출석(09:05)의 결석 학생 반영: "+str(nk["miss"].get("c1")))
  # new task on 22일 without choosing → not applied
  T.evaluate("document.getElementById('sheet').hidden=true");T.click("#ttTkNew");T.wait_for_timeout(250);T.fill("#tkN","목요일 평가");T.fill("#tkD","2026-10-22");T.dispatch_event("#tkD","change");T.click("#tkC [data-c='c1']");T.wait_for_timeout(200)
  ok(T.locator("#tkTm .tkwarn").count()==1,"두 번 있는 날은 고르라고 경고")
  T.click("#tkOk");T.evaluate("()=>{if(document.getElementById('tkScNx')){document.getElementById('skNo').click();const g=document.getElementById('tkSaGo');if(g)g.click()}}");T.wait_for_timeout(400);nk=[x for x in root(T)["tasks"] if x["n"]=="목요일 평가"][0]
  ok(nk["miss"].get("c1",{})=={},"고르지 않으면 반영 안 함")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
