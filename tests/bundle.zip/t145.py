src=open('audit2.py').read();exec(src.split("sizes=")[0])
import re,urllib.parse
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
STAFF=[{"name":"김과학","phone":"010-1000-0001","dept":"교무부","role":"교무부장","subj":"과학"},{"name":"이수학","phone":"010-1000-0002","dept":"연구부","role":"수업","subj":"수학"},
       {"name":"박국어","phone":"010-1000-0003","dept":"교무부","role":"학적","subj":"국어"},{"name":"최물리","phone":"010-1000-0004","dept":"과학정보부","role":"부장","subj":"과학"}]
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"]],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":STAFF,"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
SC=[("tt","document.querySelector('.navb[data-v=tt]').click()"),("att","document.querySelector('.navb[data-v=att]').click()"),
 ("call","document.querySelector('.navb[data-v=call]').click()"),("todo","document.querySelector('.navb[data-v=todo]').click()"),
 ("stat","document.querySelector('#amode [data-t=eval]').click()"),("set","document.querySelector('.navb[data-v=set]').click();document.querySelectorAll('main.view:not([hidden]) details').forEach(d=>d.open=true)"),
 ("write","document.querySelector('.navb[data-v=att]').click();document.querySelector('[data-m=write]').click();document.querySelector('[data-wn=free]').click()")]
CHK="""()=>{const W=innerWidth;let bad=[];const clipped=e=>{let p=e.parentElement;while(p&&p!==document.body){const cs=getComputedStyle(p);if(/auto|scroll|hidden|clip/.test(cs.overflowX)){const q=p.getBoundingClientRect();if(q.right<=W+1&&q.left>=-1)return true}p=p.parentElement}return false};
document.querySelectorAll('#sheet:not([hidden]) *,main.view:not([hidden]) *').forEach(e=>{if(e.closest('[hidden]'))return;const b=e.getBoundingClientRect();if(b.width<1||b.height<1)return;if((b.right>W+1.5||b.left<-1.5)&&!clipped(e))bad.push((e.id||e.className||e.tagName)+'')});
return{doc:document.documentElement.scrollWidth-W,bad:bad.slice(0,4),fs:parseFloat(getComputedStyle(document.documentElement).fontSize),sheet:(()=>{const s=document.querySelector('#sheet:not([hidden])>div');return s?s.getBoundingClientRect().width:0})()}}"""
with sync_playwright() as p:
  b=p.chromium.launch();R={}
  for w,h in [(320,640),(390,844),(768,1024),(1280,800),(1920,1080)]:
    c=b.new_context(viewport={"width":w,"height":h},is_mobile=w<700,has_touch=w<1100,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
    T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX)
    T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}))}}catch(e){}"%json.dumps(json.dumps(state())))
    T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
    for name,js in SC:
      T.evaluate("()=>{document.getElementById('sheet').hidden=true;"+js+"}");T.wait_for_timeout(250)
      r=T.evaluate(CHK);R[(w,name)]=r
      ok(r["doc"]<=1 and not r["bad"],f"{w}px {name}: 가로로 넘치지 않음 {r['bad'][:2]}")
    if w in(390,1280):T.screenshot(path=f"shot/t145_{w}.png")
    c.close()
  b.close()
fs=[R[(w,"att")]["fs"] for w in [320,390,768,1280,1920]];print("root font",fs)
ok(fs==sorted(fs) and fs[0]>=15 and fs[-1]<=19.01 and fs[-1]-fs[0]>=3,"화면이 넓을수록 글자가 커짐 (15 → 19px)")
sw=[R[(w,"write")]["sheet"] for w in [390,768,1280,1920]];print("sheet",sw)
ok(abs(sw[0]-390)<2 and sw[1]>600 and sw[2]>760 and sw[3]>820,"새 창(글쓰기)이 화면 폭에 맞춰 넓어짐")
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
