src=open('audit2.py').read();exec(src.split("sizes=")[0])
import base64
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"]],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-22T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
HW="(()=>{window.HandwritingStroke=class{constructor(){this.p=[]}addPoint(q){this.p.push(q)}};navigator.queryHandwritingRecognizer=async()=>({});navigator.createHandwritingRecognizer=async()=>({startDrawing:()=>{const s=[];return{addStroke:x=>s.push(x),getPrediction:async()=>[{text:s.length>=2?'안녕하세요\\n반갑습니다':''}],clear:()=>{}}},finish:()=>{}})})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def rec(T):return root(T)["recs"][-1]
def blocks(T):return rec(T)["blocks"]
def sel(T,sel,a,b):T.evaluate("([s,a,b])=>{const el=document.querySelector(s);const w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let n,pos=0,st=null,en=null;while(n=w.nextNode()){const L=n.nodeValue.length;if(!st&&a<=pos+L)st=[n,a-pos];if(!en&&b<=pos+L)en=[n,b-pos];pos+=L}const r=document.createRange();r.setStart(...st);r.setEnd(...en);el.focus();const S=getSelection();S.removeAllRanges();S.addRange(r)}",[sel,a,b])
def flush(T):T.wait_for_timeout(550)
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":430,"height":900},service_workers="block",timezone_id="Asia/Seoul",permissions=["clipboard-read","clipboard-write"]);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(HW)
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click("[data-wn=free]");T.wait_for_timeout(300)
  ok(T.locator("#wrFmt [data-fm]").count()==17,"글자 꾸미기 단추 17개")
  # ---- 글자 꾸미기
  T.click("#wrEd .wbt");T.keyboard.type("가나다라마바사",delay=10);flush(T)
  sel(T,"#wrEd .wbt",1,3);T.click("#wrFmt [data-fm=bold]");flush(T)
  ok("<b>나다</b>" in (blocks(T)[0].get("h") or ""),"굵게: "+str(blocks(T)[0].get("h")))
  ok(blocks(T)[0]["x"]=="가나다라마바사","글자는 그대로(검색 · 보내기용)")
  for cmd,tag in [("italic","<i>"),("underline","<u>"),("strikeThrough","<s>")]:
    sel(T,"#wrEd .wbt",4,5);T.click(f"#wrFmt [data-fm={cmd}]");flush(T);ok(tag in blocks(T)[0]["h"],cmd)
  sel(T,"#wrEd .wbt",5,6);T.click("#wrFmt [data-fm=subscript]");flush(T);ok("<sub>" in blocks(T)[0]["h"],"아래첨자")
  sel(T,"#wrEd .wbt",6,7);T.click("#wrFmt [data-fm=superscript]");flush(T);ok("<sup>" in blocks(T)[0]["h"],"위첨자")
  sel(T,"#wrEd .wbt",0,1);T.click("#wrFmt [data-fm=color]");T.wait_for_timeout(150);T.click(".wpal [data-pc='#c0392b']");flush(T)
  ok("color:" in blocks(T)[0]["h"] and ("#c0392b" in blocks(T)[0]["h"] or "192, 57, 43" in blocks(T)[0]["h"]),"글자색")
  sel(T,"#wrEd .wbt",2,3);T.click("#wrFmt [data-fm=hi]");T.wait_for_timeout(150);T.click(".wpal [data-pc='#fff3a3']");flush(T);ok("background-color" in blocks(T)[0]["h"],"음영(배경색)")
  sel(T,"#wrEd .wbt",3,4);T.click("#wrFmt [data-fm=shadow]");flush(T);ok("text-shadow" in blocks(T)[0]["h"],"그림자")
  T.locator("#wrEd .wb").first.screenshot(path="shot/t136_fmt.png")
  h0=blocks(T)[0]["h"];sel(T,"#wrEd .wbt",0,7);T.click("#wrFmt [data-fm=clear]");flush(T);ok(not blocks(T)[0].get("h"),"서식 지우기 → 모두 지움: "+str(blocks(T)[0].get("h")))
  T.keyboard.press("Control+z");flush(T)
  # Enter split keeps formatting
  T.evaluate("document.querySelector('#wrEd .wbt').focus()");T.keyboard.press("End");T.keyboard.press("Enter");T.keyboard.type("둘째 줄",delay=10)
  T.keyboard.press("Control+b");T.keyboard.type("굵은",delay=10);T.keyboard.press("Control+b");flush(T)
  b2=blocks(T);ok(len(b2)==2 and "<b>굵은</b>" in (b2[1].get("h") or ""),"Ctrl+B 단축키 · 줄 나누기: "+str(b2[1]))
  sel(T,"#wrEd .wb:nth-child(2) .wbt",2,6);T.keyboard.press("Home")
  # split in middle of bold
  T.evaluate("(()=>{const el=document.querySelectorAll('#wrEd .wbt')[1];const b=el.querySelector('b');const t=b.firstChild;const r=document.createRange();r.setStart(t,1);r.collapse(true);el.focus();const s=getSelection();s.removeAllRanges();s.addRange(r)})()")
  T.keyboard.press("Enter");flush(T);b3=blocks(T)
  ok(len(b3)==3 and "<b>굵</b>" in (b3[1].get("h") or "") and "<b>은</b>" in (b3[2].get("h") or ""),"굵은 글자 가운데서 나눠도 꾸밈 유지: "+str([x.get("h") for x in b3]))
  T.keyboard.press("Backspace");flush(T);b4=blocks(T);ok(len(b4)==2 and b4[1]["x"]=="둘째 줄굵은","Backspace로 다시 합치기: "+str(b4[1]))
  # ---- 문장 속 수식
  T.keyboard.press("End");T.click("#wrFmt [data-fm=math]");T.wait_for_timeout(300)
  ok(T.locator(".wov.wmed").count()==1,"수식 편집 창")
  T.click(".wmed [data-mp='0']");T.keyboard.type("1",delay=10);T.keyboard.press("ArrowRight");T.keyboard.press("ArrowRight");T.keyboard.type("2",delay=10);T.wait_for_timeout(600)
  ok(T.input_value("#wmT")=="\\frac{1}{2}","분수 틀에 채우기: "+T.input_value("#wmT"))
  ok(T.locator("#wmP .katex").count()>=1,"미리 보기(KaTeX)")
  T.locator(".wmed .wovb").screenshot(path="shot/t136_math.png")
  T.click("#wmOk");T.wait_for_timeout(600);flush(T)
  b5=blocks(T)[1];ok('data-tex="\\frac{1}{2}"' in (b5.get("h") or "") and "$\\frac{1}{2}$" in b5["x"],"문장 속 수식 저장: "+b5["x"])
  ok(T.locator("#wrEd .wmath .katex").count()==1,"문장 속 수식 표시")
  # ---- 수식 블록
  T.click("#wrTool [data-bo=math]");T.wait_for_timeout(300);T.fill("#wmT","E=mc^{2}");T.click("#wmOk");T.wait_for_timeout(600);flush(T)
  ok(any(x["t"]=="math" and x["tex"]=="E=mc^{2}" for x in blocks(T)),"수식 블록")
  ok(T.locator("#wrEd .wmathb .katex-display").count()==1,"수식 블록 표시")
  # ---- 표
  T.click("#wrTool [data-bo=table]");T.wait_for_timeout(300);flush(T)
  tb=[x for x in blocks(T) if x["t"]=="table"];ok(len(tb)==1 and len(tb[0]["rows"])==3 and len(tb[0]["rows"][0])==3,"표 넣기 3×3")
  T.keyboard.type("이름",delay=10);T.keyboard.press("Tab");T.keyboard.type("점수",delay=10);T.keyboard.press("Enter");T.keyboard.type("90",delay=10);flush(T)
  tb=[x for x in blocks(T) if x["t"]=="table"][0];ok(tb["rows"][0][:2]==["이름","점수"] and tb["rows"][1][1]=="90","칸에 쓰기 · Tab · Enter: "+str(tb["rows"]))
  bar=lambda a:T.click(f"#wrEd .wb.table [data-ta='{a}']")
  bar("r+");T.wait_for_timeout(150);bar("c+");T.wait_for_timeout(150);flush(T);tb=[x for x in blocks(T) if x["t"]=="table"][0]
  ok(len(tb["rows"])==4 and len(tb["rows"][0])==4,"줄 · 칸 넣기")
  bar("c-");T.wait_for_timeout(150);bar("r-");T.wait_for_timeout(150);flush(T);tb=[x for x in blocks(T) if x["t"]=="table"][0];ok(len(tb["rows"])==3 and len(tb["rows"][0])==3,"줄 · 칸 빼기")
  bar("hc");T.wait_for_timeout(150);flush(T);tb=[x for x in blocks(T) if x["t"]=="table"][0];ok(tb.get("hd")==1 and tb.get("hc")==1 and T.locator("#wrEd .wtbl tr:nth-child(2) th").count()==1,"머리글 줄 · 칸")
  T.click("#wrEd .wtbl [data-r='1'][data-c='1']");bar("bg");T.wait_for_timeout(150);T.click(".wpal [data-pc='#d9f2dc']");T.wait_for_timeout(150)
  bar("bc");T.wait_for_timeout(150);T.click(".wpal [data-pc='#1f6fb2']");flush(T);tb=[x for x in blocks(T) if x["t"]=="table"][0]
  ok(tb.get("bg",{}).get("1,1")=="#d9f2dc" and tb.get("bc")=="#1f6fb2","칸 음영 · 선 색: "+str((tb.get("bg"),tb.get("bc"))))
  T.locator("#wrEd .wb.table").screenshot(path="shot/t136_table.png")
  # paste TSV into a cell
  T.click("#wrEd .wtbl [data-r='2'][data-c='0']")
  T.evaluate("(()=>{const el=document.activeElement;const dt=new DataTransfer();dt.setData('text/plain','가\\t1\\n나\\t2\\n다\\t3');el.dispatchEvent(new ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}))})()");flush(T)
  tb=[x for x in blocks(T) if x["t"]=="table"][0];ok(len(tb["rows"])==5 and tb["rows"][4][:2]==["다","3"],"엑셀처럼 칸에 표 붙여넣기 → 줄 늘어남")
  # paste HTML table into text block
  T.evaluate("(()=>{const el=document.querySelector('#wrEd .wb.p:last-of-type .wbt')||[...document.querySelectorAll('#wrEd .wbt')].pop();el.focus();const dt=new DataTransfer();dt.setData('text/html','<table><tr><td>A</td><td>B</td></tr><tr><td>1</td><td>2</td></tr></table>');dt.setData('text/plain','A B');el.dispatchEvent(new ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}))})()");flush(T)
  tbs=[x for x in blocks(T) if x["t"]=="table"];ok(len(tbs)==2 and tbs[1]["rows"]==[["A","B"],["1","2"]],"웹 · 엑셀 표 붙여넣기 → 표 블록")
  # ---- 그림 + 캡션 (파일 고르기 · 붙여넣기)
  with T.expect_file_chooser() as fc:T.click("#wrTool [data-bo=img]")
  fc.value.set_files("wr_photo.jpg");T.wait_for_timeout(1200)
  im=[x for x in blocks(T) if x["t"]=="img"];ok(len(im)==1 and im[0]["m"].startswith("w"),"그림 넣기")
  ok(T.evaluate("(()=>{const i=document.querySelector('#wrEd .wfig img');return !!(i&&i.src.startsWith('blob:'))})()"),"그림 표시")
  T.click("#wrEd .wcap");T.keyboard.type("실험 장면",delay=10);T.click("#wrEd .wb.img [data-iw='50']");flush(T)
  im=[x for x in blocks(T) if x["t"]=="img"][0];ok(im["cap"]=="실험 장면" and im["w"]==50,"캡션 · 크기")
  b64=base64.b64encode(open("wr_photo.jpg","rb").read()).decode()
  T.evaluate("(b)=>{const el=[...document.querySelectorAll('#wrEd .wbt')].pop();el.focus();const bin=atob(b),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);const dt=new DataTransfer();dt.items.add(new File([u],'p.jpg',{type:'image/jpeg'}));el.dispatchEvent(new ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}))}",b64);T.wait_for_timeout(1200)
  ok(len([x for x in blocks(T) if x["t"]=="img"])==2,"사진 붙여넣기 → 그림 블록")
  # ---- 도화지: 도형 · 글상자 · 선 색 · 면 색 · 조정
  T.click("#wrTool [data-bo=draw]");T.wait_for_timeout(400);ok(T.locator(".wov.wdr").count()==1,"도화지 편집 창")
  bb=T.locator("#wdS").bounding_box();k=bb["width"]/1000
  def drag(x1,y1,x2,y2):
    bb=T.locator("#wdS").bounding_box();k=bb["width"]/1000
    T.mouse.move(bb["x"]+x1*k,bb["y"]+y1*k);T.mouse.down();
    for s in range(1,7):T.mouse.move(bb["x"]+(x1+(x2-x1)*s/6)*k,bb["y"]+(y1+(y2-y1)*s/6)*k)
    T.mouse.up();T.wait_for_timeout(80)
  T.click(".wdtools [data-t=rect]");T.click("#wdO [data-c='#1f6fb2']");T.click("#wdO [data-f='#fff3a3']");drag(100,100,400,300)
  T.click(".wdtools [data-t=ell]");T.click("#wdO [data-f='']");drag(500,100,800,300)
  T.click(".wdtools [data-t=arrow]");T.click("#wdO [data-c='#c0392b']");T.click("#wdO [data-w='12']");drag(100,400,600,420)
  T.click(".wdtools [data-t=line]");drag(100,480,600,480)
  T.click(".wdtools [data-t=pen]");T.click("#wdO [data-c='#1d2621']");T.click("#wdO [data-w='6']");drag(650,380,700,460);drag(720,380,760,470)
  T.click(".wdtools [data-t=text]");bb=T.locator("#wdS").bounding_box();T.mouse.click(bb["x"]+120*k,bb["y"]+140*k);T.wait_for_timeout(200);T.fill("#wdT","글상자 안의 글");T.click("#wdTok");T.wait_for_timeout(200)
  n=T.evaluate("document.querySelectorAll('#wdS g[data-i]').length");ok(n==7,"사각형 · 원 · 화살표 · 직선 · 펜 2 · 글상자 = 7: %d"%n)
  # select & move & resize & recolor
  T.evaluate("document.getElementById('wdC').scrollTop=0");bb=T.locator("#wdS").bounding_box();k=bb["width"]/1000
  T.click(".wdtools [data-t=select]");bb=T.locator("#wdS").bounding_box();T.mouse.click(bb["x"]+300*k,bb["y"]+250*k);T.wait_for_timeout(150)
  ok(T.locator("#wdS .wdsel").count()==1,"선택하면 테두리 · 손잡이")
  drag(300,250,350,280);T.wait_for_timeout(100)
  hb=T.locator("#wdS .wdh").bounding_box();T.mouse.move(hb["x"]+hb["width"]/2,hb["y"]+hb["height"]/2);T.mouse.down();T.mouse.move(hb["x"]+hb["width"]/2+40,hb["y"]+hb["height"]/2+30);T.mouse.up();T.wait_for_timeout(100)
  T.click("#wdO [data-c='#2e8b57']");T.click("#wdO [data-f='#d6e8fb']");T.wait_for_timeout(100)
  T.screenshot(path="shot/t136_draw.png")
  T.click(".wdtop [data-a=undo]");T.wait_for_timeout(100);T.click(".wdtop [data-a=redo]");T.wait_for_timeout(100)
  T.click(".wdtools [data-t=erase]");drag(100,480,600,480);T.wait_for_timeout(100)
  n2=T.evaluate("document.querySelectorAll('#wdS g[data-i]').length");ok(n2==6,"지우개로 직선 지우기: %d"%n2)
  T.click(".wdtop [data-a=ok]");T.wait_for_timeout(400);flush(T)
  dw=[x for x in blocks(T) if x["t"]=="draw"][0];its=dw["items"];kinds=sorted(i["k"] for i in its)
  ok(kinds==sorted(["rect","ell","arrow","pen","pen","text"]),"도화지 저장: "+str(kinds))
  rc=[i for i in its if i["k"]=="rect"][0];ok(rc["x"]==150 and rc["y"]==130 and rc["w2"]>=330 and rc["c"]=="#2e8b57" and rc["f"]=="#d6e8fb","옮기기 · 크기 · 선 색 · 면 색: "+str(rc))
  ar=[i for i in its if i["k"]=="arrow"][0];ok(ar["c"]=="#c0392b" and ar["w"]==12,"화살표 색 · 굵기")
  tx=[i for i in its if i["k"]=="text"][0];ok(tx["t"]=="글상자 안의 글","글상자")
  ok(T.locator("#wrEd .wdrw svg g").count()==6,"글에 도화지 미리 보기")
  # ---- 손글씨 → 글자 (크롬 손글씨 인식 흉내)
  T.click("#wrTool [data-bo=ink]");T.wait_for_timeout(400)
  ok(T.get_attribute(".wdtools [data-t=pen]","aria-pressed")=="true","손글씨는 펜으로 시작")
  bb=T.locator("#wdS").bounding_box();k=bb["width"]/1000;drag(100,100,200,200);drag(250,100,300,220)
  T.click("#wdO [data-a=ocr]");T.wait_for_timeout(600)
  ok("안녕하세요" in T.input_value("#wkT"),"손글씨 → 글자 결과: "+T.input_value("#wkT"))
  T.locator(".wink .wovb").screenshot(path="shot/t136_ink.png")
  T.click("#wkOk");T.wait_for_timeout(300)
  its=[i for i in []];n3=T.evaluate("document.querySelectorAll('#wdS g[data-i]').length");ok(n3==1 and "안녕하세요" in T.text_content("#wdS"),"글상자로 바뀌고 손글씨는 지움")
  T.click(".wdtop [data-a=ok]");T.wait_for_timeout(400);flush(T)
  # doc-level ink → text blocks
  T.click("#wrTool [data-bo=ink]");T.wait_for_timeout(400);bb=T.locator("#wdS").bounding_box();k=bb["width"]/1000;drag(100,100,200,200);drag(250,100,300,220);T.click(".wdtop [data-a=ok]");T.wait_for_timeout(400)
  T.locator("#wrEd .wb.draw [data-da=ocr]").last.click();T.wait_for_timeout(600);T.click("#wkOk");T.wait_for_timeout(400);flush(T)
  xs=[x.get("x") for x in blocks(T)];ok("안녕하세요" in xs and "반갑습니다" in xs,"글에서 손글씨 → 글자 블록(줄마다)")
  # ---- Esc closes overlay first
  T.click("#wrTool [data-bo=math]");T.wait_for_timeout(200);T.keyboard.press("Escape");T.wait_for_timeout(200)
  ok(T.locator(".wov").count()==0 and not T.locator("#sheet").is_hidden(),"Esc는 수식 창만 닫음")
  # ---- plain text (search/보내기)
  T.click("#skNo");T.wait_for_timeout(400)
  r=rec(T);ok(any(x["t"]=="img" for x in r["blocks"]),"저장됨")
  T.fill("#wrQ","실험 장면");T.wait_for_timeout(300);ok(T.locator("#wrCard .wrrow").count()==1,"캡션으로도 찾기")
  T.fill("#wrQ","frac");T.wait_for_timeout(300);ok(T.locator("#wrCard .wrrow").count()==1,"수식으로도 찾기")
  # reopen renders everything
  T.fill("#wrQ","");T.wait_for_timeout(200);T.click("#wrCard .wrmain");T.wait_for_timeout(900)
  ok(T.locator("#wrEd .wmath .katex").count()==1 and T.locator("#wrEd .wtbl").count()==2 and T.locator("#wrEd .wfig img").count()==2,"다시 열면 그대로")
  T.screenshot(path="shot/t136_doc.png",full_page=False)
  # ---- 휴대폰(터치)으로 손글씨 · 도형
  m=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul");m.route("**/*",handler)
  M=m.new_page();M.on("pageerror",lambda e:errs.append(str(e)));M.add_init_script(FIX)
  M.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  M.goto("https://tl.test/index.html");M.wait_for_timeout(900);M.click("[data-wn=day]");M.wait_for_timeout(300);M.click("#wrTool [data-bo=ink]");M.wait_for_timeout(400)
  cdp=m.new_cdp_session(M)
  def tdrag(x1,y1,x2,y2):
    bb=M.locator("#wdS").bounding_box();k=bb["width"]/1000;X=lambda v:bb["x"]+v*k;Y=lambda v:bb["y"]+v*k
    cdp.send("Input.dispatchTouchEvent",{"type":"touchStart","touchPoints":[{"x":X(x1),"y":Y(y1)}]})
    for s2 in range(1,9):cdp.send("Input.dispatchTouchEvent",{"type":"touchMove","touchPoints":[{"x":X(x1+(x2-x1)*s2/8),"y":Y(y1+(y2-y1)*s2/8)}]})
    cdp.send("Input.dispatchTouchEvent",{"type":"touchEnd","touchPoints":[]});M.wait_for_timeout(120)
  tdrag(100,100,300,300);tdrag(300,100,100,300)
  M.click(".wdtools [data-t=rect]");tdrag(500,100,800,300)
  n=M.evaluate("document.querySelectorAll('#wdS g[data-i]').length");ok(n==3,"휴대폰: 손가락으로 손글씨 2획 + 사각형: %d"%n)
  ok(M.evaluate("document.querySelector('.wov.wdr').getBoundingClientRect().height")>=800,"휴대폰: 도화지 편집은 전체 화면")
  M.screenshot(path="shot/t136_mdraw.png")
  M.click(".wdtop [data-a=ok]");M.wait_for_timeout(500);ok(M.locator("#wrEd .wb.draw").count()==1,"휴대폰: 저장")
  M.screenshot(path="shot/t136_mdoc.png")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
