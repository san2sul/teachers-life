src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
# 5.91 안정화 2 · 3차: 수업 설정 한 곳 · 지우기 방식 · 학생 창 · 오늘 화면 정리 · 숨은 동작 안내 · 용어
r1=[["10101","가람"],["10102","가온"],["10103","나래"]]
def state():
  cells={"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"3-4":{"subject":"물리학","clsId":"c1","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[{"id":"e1","date":"2026-10-28","start":"15:00","end":"16:00","cat":"학생 면담","title":"가람 면담","memo":"","clsId":"","alarm":-1,"important":False,"done":False}],
    "evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘","ch":[{"id":"a1","t":"속력"},{"id":"a2","t":"가속도"}]}],"pg":{}}],
    "period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','todo');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1500)
  # 3: 오늘 화면 — 지금 수업 카드가 있으면 목록의 그 줄은 짧게, 보내기 · 알림은 접힘
  if T.evaluate("document.documentElement.dataset.view")!="todo":T.click(".navb[data-v=todo]");T.wait_for_timeout(500)
  row=T.locator("#v-todo .tdl.now").first.inner_text().replace("\n"," ")
  ok("위 ‘지금 수업’ 카드" in row,"지금 수업 줄은 짧게 "+row)
  ok(T.evaluate("!document.getElementById('tdSendC').open && !document.getElementById('alCard').open") and T.inner_text("#alTag")!="","할 일 보내기 · 알림 확인은 접힘(알림 상태 표시 "+T.inner_text("#alTag")+")")
  # 13: 숨은 동작 안내 · 컴퓨터 오른쪽 클릭
  rows=T.locator("#tdList .td.swrow:visible")
  if rows.count():
    T.wait_for_timeout(1200);ok(T.is_visible("#ghint") and "왼쪽" in T.inner_text("#ghint"),"처음 한 번 밀기 안내 "+(T.inner_text("#ghint") if T.locator("#ghint").count() else ""))
    rows.first.scroll_into_view_if_needed();T.wait_for_timeout(400);bb=rows.first.bounding_box();T.mouse.click(bb["x"]+bb["width"]/2,bb["y"]+bb["height"]/2,button="right");T.wait_for_timeout(400);ok(T.evaluate("!!document.querySelector('.swrow.swopen')"),"오른쪽 클릭으로 밀기 단추 열기")
    T.mouse.click(5,5);T.wait_for_timeout(300)
  else:ok(False,"오늘 화면에 밀기 줄이 없음")
  T.reload();T.wait_for_timeout(1500);T.wait_for_timeout(1200);ok(not T.is_visible("#ghint"),"안내는 기기마다 한 번만")
  # 1: 수업 설정 한 곳
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#ttPnBtn");T.wait_for_timeout(300)
  T.click("#ttProg [data-lsgo]");T.wait_for_timeout(500)
  ok(T.evaluate("document.documentElement.dataset.view")=="set" and T.evaluate("document.getElementById('d-lesson').open") and T.locator("#lsBody [data-ls]").count()==6,"진도 현황 ⚙ 수업 설정 → 설정의 ‘수업’ 묶음")
  T.click("#lsBody [data-ls='pn|auto']");T.wait_for_timeout(200);T.click("#lsBody [data-ls='fl|auto']");T.wait_for_timeout(200)
  R=root(T);ok(R["pnCfg"]["mode"]=="auto" and R["pnCfg"].get("set") and R["flowCfg"].get("auto"),"진도 자동 · 흐름 자동을 한 곳에서 "+str(R.get("pnCfg"))+str(R.get("flowCfg")))
  T.click("#lsBody [data-ls='pn|manual']");T.wait_for_timeout(200);T.click("#lsBody [data-ls='fl|manual']");T.wait_for_timeout(200)
  R=root(T);ok(R["pnCfg"]["mode"]=="manual" and not R.get("flowCfg",{}).get("auto"),"다시 직접으로")
  T.fill("#lsSc","내녹음");T.wait_for_timeout(200);ok(T.evaluate("localStorage.getItem('att-app-recsc')")=="내녹음","녹음 단축어 이름")
  T.click("#lsBody [data-ls='wk|off']");T.wait_for_timeout(200);ok(json.loads(T.evaluate("localStorage.getItem('att-app-ui')")or"{}").get("wake")=="off","화면 켜 두기 끄기(화면 설정과 같은 값)");T.click("#lsBody [data-ls='wk|on']");T.wait_for_timeout(200)
  # 5: 칸 메모 · 9: 용어
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  if T.is_visible("#ttProg"):T.click("#ttPnBtn");T.wait_for_timeout(300)
  if not T.is_visible(".tc[data-d='2'][data-p='3']"):T.click(".ttmode [data-tm=week]");T.wait_for_timeout(300)
  T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400)
  ok(T.locator("#sheetBox .memosame").count()==1,"칸 메모: 출석부 수업 메모와 같은 기록이라는 안내")
  ok("맞바꾸기" in T.inner_text("#cmChg") or "맞바꾸기" in T.inner_text("#sheetBox"),"용어: 교체 → 맞바꾸기 "+T.inner_text("#cmChg"))
  T.click("#skNo");T.wait_for_timeout(200)
  # 11: 지우기 — 한 번 누르고 되돌리기
  T.click(".navb[data-v=todo]");T.wait_for_timeout(400)
  T.click("#tdList .td:has-text('가람 면담') .tdb");T.wait_for_timeout(400)
  ok(T.locator("#evDel").count()==1,"일정 창의 삭제 단추")
  T.click("#evDel");T.wait_for_timeout(300)
  ok(root(T)["events"]==[] and T.is_hidden("#sheet"),"한 번 눌러 바로 지움")
  ok(T.is_visible("#utoast") and "되돌리기" in T.inner_text("#utoast"),"아래 되돌리기")
  T.click("#utoast button");T.wait_for_timeout(400);ok([e["id"] for e in root(T)["events"]]==["e1"],"되돌리기 → 일정이 돌아옴")
  # 10: 학생 창 — 출석부 위에 덮어 열고, 닫으면 그대로
  T.click(".navb[data-v=att]");T.wait_for_timeout(500);T.evaluate("document.querySelector('[data-key=\"m:att\"]').click()");T.wait_for_timeout(400)
  T.wait_for_timeout(1700);ok(T.is_visible("#ghint") and "길게" in T.inner_text("#ghint"),"출석부 처음: 길게 누르기 안내")
  T.evaluate("document.querySelectorAll('#list .st')[2].scrollIntoView({block:'center'})");T.wait_for_timeout(300);y0=T.evaluate("scrollY")
  tile=T.locator("#list .st").nth(2);bb=tile.bounding_box();T.mouse.move(bb["x"]+10,bb["y"]+10);T.mouse.down();T.wait_for_timeout(800);T.mouse.up();T.wait_for_timeout(400)
  ok(T.is_visible("#stuOv") and "나래" in T.inner_text("#stuOv .stuhd") and T.evaluate("document.documentElement.dataset.view")=="att","학생 창이 출석부 위에(화면은 출석 그대로)")
  T.screenshot(path="shot/t190_stuov.png")
  T.click("#stuOv #stuMore");T.wait_for_timeout(200);ok(T.is_visible("#sheet"),"학생 창 위에 창(⋯)이 열림");T.click("#skNo") if T.locator("#skNo").count() else None;T.wait_for_timeout(200)
  if T.is_visible("#sheet"):T.evaluate("document.getElementById('sheet').hidden=true");T.wait_for_timeout(200)
  ok(T.is_visible("#stuOv"),"창을 닫아도 학생 창은 그대로")
  T.click("#stuOvX");T.wait_for_timeout(400)
  ok(not T.is_visible("#stuOv") and T.is_visible("#list .st") and abs(T.evaluate("scrollY")-y0)<40,"‹ 출석(으)로 → 같은 자리의 출석부")
  # 학생 창이 열린 채 아래 메뉴로 옮기면 닫힘
  bb=T.locator("#list .st").nth(0).bounding_box();T.mouse.move(bb["x"]+10,bb["y"]+10);T.mouse.down();T.wait_for_timeout(800);T.mouse.up();T.wait_for_timeout(400)
  T.evaluate("document.querySelector('.navb[data-v=tt]').click()");T.wait_for_timeout(300);ok(not T.is_visible("#stuOv"),"다른 화면으로 가면 학생 창 닫힘")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
