src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "pnCfg":{"mode":"manual"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  pg=lambda:plan(T)["pg"].get("c1",{})
  def att():
    T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400);T.locator("#cmAtt").dispatch_event("click");T.wait_for_timeout(500)
  att()
  ok(T.locator("#pnBar #pnFullO").count()==1 and T.locator("#sesMemo #smProg").count()==0 and "📘" in T.inner_text("#sesMemo"),"출석부: 📘 진도 펼치기 단추, 수업 메모의 진도 칸은 📘로 안내")
  T.click("#pnFullO");T.wait_for_timeout(300)
  F0="#pnFullBox"
  ok(T.is_visible("#sheet") and T.locator("#pnBar #pnFullBox").count()==0 and T.locator(F0+" .pncmp").count()==1 and T.locator(F0+" [data-pc]").count()>=3 and T.locator(F0+" #pnFree").count()==1 and T.locator(F0+" #pnFxL").count()==1,"5.91: 펼치면 아래에서 올라오는 창에 진도 목록(출석 칸은 그대로)")
  bx=T.evaluate("(()=>{const r=document.querySelector('#sheetBox').getBoundingClientRect();return[r.bottom,innerHeight]})()");ok(abs(bx[0]-bx[1])<2,"창이 화면 아래에 붙음 "+str(bx))
  T.screenshot(path="shot/t187_full.png")
  T.click(F0+" [data-pc='a2|d']");T.wait_for_timeout(300)
  ok(pg()["a2"].get("s")=="s1" and "1-2" in T.inner_text(F0+" .pncmp"),"창에서 1-2 마침 → 이 수업 실제 진도 "+T.inner_text(F0+" .pncmp").replace("\n"," "))
  T.click(F0+" [data-pc='a2|h']");T.wait_for_timeout(300);ok(pg()["a2"]["st"]=="h","반만으로 고치기")
  T.click(F0+" [data-pc='a3|d']");T.wait_for_timeout(300);T.click(F0+" [data-pc='a3|']");T.wait_for_timeout(300);ok("a3" not in pg(),"잘못 누른 차시 안 함")
  T.fill(F0+" #pnFree","교과서 54~57쪽");T.wait_for_timeout(500);ok(root(T)["notes"].get("t1:2:3:2026-10-28",{}).get("progress")=="교과서 54~57쪽","직접 입력도 출석부에서")
  ok(T.locator(F0+" .pnmis").count()==1 and "1-2" in T.inner_text(F0+" .pnmis"),"5.91: 직접 쓴 진도 글에 기록된 차시(1-2)가 없으면 알림")
  T.click("#pnSyncT");T.wait_for_timeout(300);ok("1-2" in root(T)["notes"]["t1:2:3:2026-10-28"]["progress"] and root(T)["notes"]["t1:2:3:2026-10-28"].get("pAuto") and T.locator(F0+" .pnmis").count()==0,"‘기록대로 글 바꾸기’ "+root(T)["notes"]["t1:2:3:2026-10-28"]["progress"])
  T.click("#utoast button");T.wait_for_timeout(300);ok(root(T)["notes"]["t1:2:3:2026-10-28"]["progress"]=="교과서 54~57쪽","되돌리기")
  T.click(F0+" #pnFxL");T.wait_for_timeout(300);ok("진도 바로잡기" in T.inner_text("#sheetBox"),"창에서 ↺ 바로잡기");T.click("#sheetBox [data-fx='2']");T.wait_for_timeout(200);T.click("#pnFxOk");T.wait_for_timeout(400)
  ok(pg().get("a3",{}).get("st")=="d" and T.is_visible("#pnFullBox"),"바로잡은 뒤 진도 창으로 돌아옴")
  T.click("#pnFullX");T.wait_for_timeout(300);ok(T.is_hidden("#sheet") and ("이 수업 진도" in T.inner_text("#pnBar") or "2차시" in T.inner_text("#pnBar")),"닫으면 짧은 진도 줄(수업 중에는 위쪽 한 줄)")
  T.reload();T.wait_for_timeout(900);att()
  ok(T.locator("#pnFullBox").count()==0 and T.locator("#pnBar #pnFullO").count()==1,"다시 열면 늘 접힌 채 시작")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
