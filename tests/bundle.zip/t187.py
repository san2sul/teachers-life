src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "pnCfg":{"mode":"manual"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  pg=lambda:plan(T)["pg"].get("c1",{})
  def att():
    T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400);T.locator("#cmAtt").dispatch_event("click");T.wait_for_timeout(500)
  att()
  ok(T.locator("#pnBar #pnFullO").count()==1 and T.locator("#sesMemo #smProg").count()==0 and "📘" in T.inner_text("#sesMemo"),"출석부: 📘 진도 펼치기 단추, 수업 메모의 진도 칸은 📘로 안내")
  T.click("#pnFullO");T.wait_for_timeout(300)
  ok(T.locator("#pnBar #pnFullBox .pncmp").count()==1 and T.locator("#pnBar [data-pc]").count()>=3 and T.locator("#pnBar #pnFree").count()==1 and T.locator("#pnBar #pnFxL").count()==1,"펼치면 출석부 안에 진도 목록(계획 · 실제 · 차시마다 마침/반만/안 함 · 직접 입력 · 바로잡기)")
  T.screenshot(path="shot/t187_full.png")
  T.click("#pnBar [data-pc='a2|d']");T.wait_for_timeout(300)
  ok(pg()["a2"].get("s")=="s1" and "1-2" in T.inner_text("#pnBar .pncmp"),"출석부에서 바로 1-2 마침 → 이 수업 실제 진도 "+T.inner_text("#pnBar .pncmp").replace("\n"," "))
  T.click("#pnBar [data-pc='a2|h']");T.wait_for_timeout(300);ok(pg()["a2"]["st"]=="h","반만으로 고치기")
  T.click("#pnBar [data-pc='a3|d']");T.wait_for_timeout(300);T.click("#pnBar [data-pc='a3|']");T.wait_for_timeout(300);ok("a3" not in pg(),"잘못 누른 차시 안 함")
  T.fill("#pnBar #pnFree","교과서 54~57쪽");T.wait_for_timeout(500);ok(root(T)["notes"].get("t1:2:3:2026-10-28",{}).get("progress")=="교과서 54~57쪽","직접 입력도 출석부에서")
  T.click("#pnBar #pnFxL");T.wait_for_timeout(300);ok("진도 바로잡기" in T.inner_text("#sheetBox"),"출석부에서 ↺ 바로잡기");T.click("#sheetBox [data-fx='2']");T.wait_for_timeout(200);T.click("#pnFxOk");T.wait_for_timeout(500)
  ok(pg().get("a3",{}).get("st")=="d" and T.is_hidden("#sheet") and T.locator("#pnBar #pnFullBox").count()==1,"바로잡은 뒤 출석부로(진도 목록 펼친 그대로)")
  # 수업 메모 창을 함께 열어도 각자 동작(같은 이름 칸 겹침 없음)
  T.locator("#smMore").dispatch_event("click");T.wait_for_timeout(400)
  T.click("#mnPn [data-pc='a1|h']");T.wait_for_timeout(300);ok(pg()["a1"]["st"]=="h" and "1-1" in T.inner_text("#mnPn .pncmp"),"출석부 위 수업 메모 창의 진도 목록도 정상")
  T.click("#skNo");T.wait_for_timeout(300)
  if T.is_visible("#sheet"):T.evaluate("document.getElementById('sheet').hidden=true")
  T.click("#pnFullX");T.wait_for_timeout(300);ok(T.locator("#pnBar #pnFullBox").count()==0 and "이 수업 진도" in T.inner_text("#pnBar"),"접으면 짧은 진도 줄(이 수업 진도)")
  T.click("#pnFullO");T.wait_for_timeout(200);T.reload();T.wait_for_timeout(900);att()
  ok(T.locator("#pnBar #pnFullBox").count()==1,"펼친 상태를 기억")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
