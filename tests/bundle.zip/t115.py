src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy,re
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def M(T,key="school:master"):return T.evaluate("k=>new Promise(r=>{const q=indexedDB.open('teachers-life-media');q.onsuccess=()=>{const g=q.result.transaction('m').objectStore('m').get('kv:'+k);g.onsuccess=()=>r(g.result?JSON.parse(g.result):null)}})",key)
def st(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
EMPTY={"active":"c0","list":[{"id":"c0","data":{"v":3,"cls":"","roster":[],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
def dev(b,state,touch=False):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,has_touch=touch);c.route("**/*",handler);T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)))
  T.goto("https://tl.test/index.html");T.evaluate("s=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');if(!localStorage.getItem('att-app-ui'))localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));if(!localStorage.getItem('att-app-clsal'))localStorage.setItem('att-app-clsal','0');localStorage.setItem('att-app-setup','1')}",json.dumps(state));T.reload();T.wait_for_timeout(700);return T
def admin_setup(T,school="물리고등학교"):
  T.click(".navb[data-v=set]");T.evaluate("()=>{document.getElementById('d-school').open=true}");T.click("#schOpen");T.check("#schAgree");T.click("#schOnBtn");T.wait_for_timeout(400)
  T.set_input_files("#schFile","schf/v1.xlsx");T.wait_for_timeout(1200);T.click("#schGo");T.wait_for_timeout(400)
  T.fill("#schName",school);T.evaluate("document.getElementById('schName').dispatchEvent(new Event('change'))");T.wait_for_timeout(300)
def openfile(T,path_or_text):
  T.evaluate("()=>{document.getElementById('sheet').hidden=true;document.querySelector('.navb[data-v=set]').click();document.getElementById('d-pack').open=true}");T.wait_for_timeout(150)
  T.evaluate("t=>{const f=new File([t],'pack.json',{type:'application/json'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('packFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",path_or_text);T.wait_for_timeout(900)
with sync_playwright() as p:
  b=p.chromium.launch()
  A=dev(b,EMPTY);admin_setup(A)
  ok("담당자용" in A.inner_text("#d-school summary"),"settings says 담당자용")
  A.click("[data-st=asg]");A.wait_for_timeout(200)
  A.set_input_files("#asgFile","schf/asg_list.xlsx");A.wait_for_timeout(1000);sh=A.inner_text("#sheetBox");print("  asg list:",sh[:160].replace("\n"," | "))
  ok("선생님 3명" in sh and "담임 2명" in sh and "박국어" in sh,"list-format assignment read (multi-row teacher, '2학년 1,2반', '201', example skipped)")
  A.click("#asgGo");A.wait_for_timeout(400);m=M(A);kim=[t for t in m["staff"] if t["name"]=="김물리"][0];lee=[t for t in m["staff"] if t["name"]=="이수학"][0]
  ok(kim["hr"]=="1-1" and sorted(sum([x["cls"] for x in kim["teach"]],[]))==["1-1","1-2","1-3","1-4","2-1","2-2"],"김물리: 담임 1-1, 수업 6학급 "+str(kim["teach"]))
  ok(lee["hr"]=="2-2" and lee["teach"][0]["cls"]==["2-1","2-2","2-3","2-4"],"이수학: 담임 2-2, 수학 201~204")
  ok(any(t["name"]=="박국어" for t in m["staff"]),"unknown teacher added to staff")
  A.set_input_files("#asgFile","schf/asg_grid.xlsx");A.wait_for_timeout(1000);sh=A.inner_text("#sheetBox");ok("교사별 시간표 1개" in sh,"timetable grid read: "+sh[:120].replace("\n"," | "));A.click("#asgGo");A.wait_for_timeout(400)
  kim=[t for t in M(A)["staff"] if t["name"]=="김물리"][0];ok(len(kim.get("tt",{}))==9 and kim["tt"]["1-2"]["cls"]=="1-3","timetable cells: "+str(len(kim.get("tt",{}))))
  # manual edit: 정교감 gets 3-1 진로
  A.click("#schList [data-au] >> text=정교감");A.wait_for_timeout(200);A.click("#asgAdd");A.fill("[data-sj='0']","진로");A.click("[data-ti='0'][data-k='3-1']");A.click("#asgOk");A.wait_for_timeout(300)
  ok([t for t in M(A)["staff"] if t["name"]=="정교감"][0]["teach"]==[{"subj":"진로","cls":["3-1"]}],"manual assignment edit")
  fp=A.inner_text("#fpBox");ok(re.match(r"^[0-9A-Z]{4}-[0-9A-Z]{4}$",fp),"담당자 확인 코드 shown: "+fp)
  with A.expect_download() as dl:A.click("#packMake")
  A.wait_for_timeout(500);pack=open(dl.value.path(),encoding="utf-8").read();P=json.loads(pack)
  ok(P["kind"]=="teachers-life-school-pack" and len(P["entries"])==4,"pack has 4 teacher entries")
  names=[s["name"] for s in M(A)["students"]][:50]
  ok(not any(n in pack for n in names) and "010-" not in pack,"no student names or phone numbers readable in the file")
  m=M(A);codes={t["name"]:t["code"] for t in m["staff"] if t.get("code")}
  A.click("#packCodes");A.wait_for_timeout(300);ok(A.locator(".codelist .prow").count()==4 and codes["김물리"] in A.inner_text(".codelist"),"개인 코드 list");A.click("#skNo")
  # ---- teacher B (김물리) ----
  B=dev(b,EMPTY,touch=True)
  openfile(B,pack);sh=B.inner_text("#sheetBox");ok("처음 받는" in sh and fp in sh,"first time: shows 담당자 확인 코드 to compare")
  B.click("#pkOk");B.wait_for_timeout(200)
  B.click("#pkList [data-t] >> text=이수학");B.fill("#pkCode",codes["김물리"]);B.click("#pkGo");B.wait_for_timeout(800);ok("맞지 않습니다" in B.inner_text("#pkMsg"),"another teacher's part does not open with my code")
  B.click("#pkList [data-t] >> text=김물리");B.fill("#pkCode","ABCD-EFGH");B.click("#pkGo");B.wait_for_timeout(800);ok("맞지 않습니다" in B.inner_text("#pkMsg"),"wrong code rejected")
  B.fill("#pkCode",codes["김물리"].lower().replace("-"," "));B.click("#pkGo");B.wait_for_timeout(900);sh=B.inner_text("#sheetBox");print("  preview:",sh[:300].replace("\n"," | "))
  ok("김물리 선생님께 온 학급" in sh and "담임" in sh and "시간표 9칸" in sh,"code accepted (case/space tolerant), preview shows classes, 담임, timetable")
  B.click("#pkApply");B.wait_for_timeout(500);s=st(B)
  cl={c["data"]["cls"]:c["data"] for c in s["list"] if c["data"].get("sch")}
  ok(len(cl)==6 and cl["1학년 1반"]["sch"]["role"]=="담임" and cl["1학년 2반"]["sch"]["role"]=="교과","6 classes created with roles")
  ok(len(cl["1학년 1반"]["phones"])==25 and len(cl["1학년 2반"]["phones"])==0,"담임반 has phones, 교과반 has none")
  ok(s["active"]==[c["id"] for c in s["list"] if c["data"].get("cls")=="1학년 1반"][0],"homeroom becomes the active class")
  tt=s["tt"]["list"];ok(len(tt)==1 and len(tt[0]["cells"])==9 and tt[0]["cells"]["0-1"]["clsId"]==[c["id"] for c in s["list"] if c["data"].get("cls")=="1학년 1반"][0],"timetable created and linked to classes")
  ok(len(s["staff"])>=2,"staff directory merged (%d)"%len(s["staff"]))
  ok(len(cl["1학년 1반"]["sch"]["uids"])==25,"school unique ids kept for later updates")
  # attendance on homeroom then re-import: no duplicates, records kept
  B.click(".navb[data-v=att]");B.wait_for_timeout(200);B.evaluate("()=>{const b=document.getElementById('startSes');if(!b.closest('[hidden]'))b.click();else document.querySelector('#tabs .tab.add').click()}");B.wait_for_timeout(300)
  nses=len([c for c in st(B)["list"] if c["data"].get("cls")=="1학년 1반"][0]["data"]["sessions"])
  openfile(B,pack);ok("내 이름" in B.inner_text("#sheetBox"),"second time: trusted, goes straight to name/code")
  ok(B.evaluate("document.querySelector('#pkList [aria-pressed=true]')&&document.querySelector('#pkList [aria-pressed=true]').textContent").startswith("김물리"),"my name remembered")
  B.fill("#pkCode",codes["김물리"]);B.click("#pkGo");B.wait_for_timeout(900);ok("이미 있는 학급" in B.inner_text("#sheetBox"),"existing classes noted");B.click("#pkApply");B.wait_for_timeout(400);s=st(B)
  ok(len([c for c in s["list"] if c["data"].get("sch")])==6 and len([c for c in s["list"] if c["data"].get("cls")=="1학년 1반"][0]["data"]["sessions"])==nses,"re-import: no duplicate classes, attendance kept")
  B.reload();B.wait_for_timeout(700);ok(all(c["data"].get("sch") for c in st(B)["list"] if c["data"].get("cls")),"sch info survives reload/normalize")
  # undo
  B.evaluate("()=>{document.querySelector('.navb[data-v=set]').click();document.getElementById('d-bk').open=true}");B.wait_for_timeout(200)
  ok(B.is_visible("#undoBtn"),"undo available after receiving")
  # tamper
  T2=json.loads(pack);e=T2["entries"][0];e["name"]="해커"
  openfile(B,json.dumps(T2,ensure_ascii=False));ok("열 수 없는 묶음" in B.inner_text("#sheetBox"),"tampered pack refused")
  T3=json.loads(pack);T3["entries"][1]["ct"]=T3["entries"][1]["ct"][:-8]+"AAAAAAA="
  openfile(B,json.dumps(T3,ensure_ascii=False));ok("열 수 없는 묶음" in B.inner_text("#sheetBox"),"modified encrypted part refused")
  # foreign admin with same school name
  C=dev(b,EMPTY);admin_setup(C);C.click("[data-st=asg]");C.set_input_files("#asgFile","schf/asg_list.xlsx");C.wait_for_timeout(900);C.click("#asgGo");C.wait_for_timeout(300)
  with C.expect_download() as dl2:C.click("#packMake")
  C.wait_for_timeout(400);fake=open(dl2.value.path(),encoding="utf-8").read()
  openfile(B,fake);sh=B.inner_text("#sheetBox");ok("확인 코드가 다릅니다" in sh,"pack from a different 담당자 → warning");ok(B.is_visible("#skNo"),"default action is not to open")
  b.close()
print("fails",F);print(errs)
