src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{"t1:0:2:2026-10-26":{"progress":"1-2 가속도 (반만)","memo":"실험 보고서 걷기","date":"2026-10-26","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":2,"updated":1}},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"},"a2":{"st":"h","d":"2026-10-26","k":"t1:0:2:2026-10-26"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click(".navb[data-v=todo]");T.wait_for_timeout(500)
  row=T.locator("#v-todo .tdl:has-text('3교시 물리학')").first.inner_text().replace("\n"," ")
  ok("지난 10/26 · 1-2" in row and "오늘 1-2 가속도" in row,"오늘 수업 목록: 지난 진도 → 오늘 진도 "+row)
  hero=T.inner_text("#v-todo .nowhero");ok("지난 1-2" in hero,"지금 수업 단추에도 지난 진도 "+hero.replace("\n"," "))
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400)
  pv=T.inner_text("#mnPn .pnprev");ok("10월 26일" in pv and "1-2 가속도 (반만)" in pv and "실험 보고서 걷기" in pv,"학급 정보 진도: 지난 시간 차시 · 지난 메모 "+pv.replace("\n"," / "))
  ok(T.locator("#sheetBox p.note.prev").count()==0,"진도표가 있으면 지난 수업 줄은 한 번만")
  T.click("#mnPn [data-pc='a3|d']");T.wait_for_timeout(200);pv=T.inner_text("#mnPn .pnprev")
  ok("1-2 가속도" in pv and "1-3" not in pv,"이 수업에 기록해도 지난 시간은 그대로 "+pv.replace("\n"," / "))
  T.click("#skNo");T.wait_for_timeout(200)
  T.click(".navb[data-v=att]");T.wait_for_timeout(400)
  pb=T.inner_text("#pnBar");ok("지난 시간" in pb and "1-2 가속도" in pb and "실험 보고서 걷기" in pb,"출석부 진도 칸에도 지난 시간 "+pb.replace("\n"," / "))
  ok(T.locator("#sesMemo .pnprev").count()==0,"출석부 수업 메모에는 겹쳐 나오지 않음")
  # 진도표가 없는 교과: 수업 메모의 진도 · 메모로
  T.evaluate("""(()=>{const s=JSON.parse(localStorage.getItem('att-app-v2'));s.plans=[];localStorage.setItem('att-app-v2',JSON.stringify(s))})()""");T.reload();T.wait_for_timeout(900)
  T.click(".navb[data-v=todo]");T.wait_for_timeout(500);row=T.locator("#v-todo .tdl:has-text('3교시 물리학')").first.inner_text().replace("\n"," ")
  ok("지난 10/26 · 1-2 가속도 (반만)" in row,"진도표 없이도 지난 메모의 진도 "+row)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400)
  pv=T.inner_text("#sheetBox .pnprev");ok("1-2 가속도" in pv and "실험 보고서 걷기" in pv,"수업 메모장 위 지난 시간 "+pv.replace("\n"," / "))
  T.click("#skNo");T.wait_for_timeout(200)
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
