src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ros=[["10101","가람"],["10102","가온"],["10103","나래"],["10104","다솜"]]
def state():
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ros,"phones":{},"emails":{},"teachers":[],"msg":"m",
     "sessions":[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True,"10103":True},"src":"t1:2:3"}]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":{"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-5":{"subject":"물리학","clsId":"c1","clsName":"","room":""}},"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','todo');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def d1(T):return root(T)["list"][0]["data"]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",permissions=["clipboard-read","clipboard-write"]);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  # 1. 오늘 → 수업 누르면 시간표 칸과 같은 창
  T.click(".navb[data-v=todo]");T.wait_for_timeout(300)
  T.click("#tdToday .tdl:has-text('5교시')");T.wait_for_timeout(300)
  tx=T.inner_text("#sheetBox");ok(T.is_visible("#sheet") and "수 5교시 · 물리학" in tx,"오늘에서 수업을 누르면 시간표 칸 창 (수 5교시)")
  T.click("#skNo");T.wait_for_timeout(150);ok(T.evaluate("document.querySelector('#v-todo').hidden")==False,"오늘 화면에 그대로")
  # 2. 관찰: 모두에게 넣기 · 빼기
  T.click(".navb[data-v=att]");T.wait_for_timeout(200);T.click("#amode [data-m=obs]");T.wait_for_timeout(200)
  ok(not T.is_visible("#obsAll"),"항목을 고르기 전에는 숨김")
  T.click("#obsBar [data-k=a1]");T.wait_for_timeout(150)
  ok(T.is_visible("#obsAllOn") and "출석 3명" in T.inner_text("#obsAllOn"),"‘모두에게 넣기 (출석 3명)’")
  T.click("#obsAllOn");T.wait_for_timeout(200)
  have=[r["sid"] for r in d1(T)["obs"] if r["date"]=="2026-10-28" and r["tags"].get("a1")];ok(sorted(have)==["10101","10102","10103"],"출석한 3명에게 넣음 (결석 학생 제외)")
  T.click("#obsList [data-s='10101']");T.wait_for_timeout(150)
  ok([r for r in d1(T)["obs"] if r["sid"]=="10101"][0]["tags"]["a1"]==2,"개별 체크는 그대로 됨")
  T.click("#obsAllOff");T.wait_for_timeout(200);ok(not any(r["tags"].get("a1") for r in d1(T).get("obs",[])),"모두에서 빼기")
  T.click("#utoast button");T.wait_for_timeout(200);ok(len([r for r in d1(T)["obs"] if r["tags"].get("a1")])==3,"되돌리기")
  T.screenshot(path="shot/t159_obs.png")
  # 3. 글쓰기 전체 선택
  T.click("#amode [data-m=write]");T.wait_for_timeout(200);T.click("[data-wn=day]");T.wait_for_timeout(400)
  T.click("#wrEd .wbt");T.keyboard.type("첫째 문단",delay=5);T.keyboard.press("Enter");T.keyboard.type("둘째 문단",delay=5);T.keyboard.press("Enter");T.keyboard.type("셋째",delay=5);T.wait_for_timeout(600)
  T.keyboard.press("Control+a");T.wait_for_timeout(200)
  ok(T.evaluate("document.getElementById('wrEd').classList.contains('wrall')") and T.is_visible("#wrAllBar") and "3블록" in T.inner_text("#wrAllBar"),"Ctrl+A → 글 전체 선택 (3블록)")
  T.screenshot(path="shot/t159_all.png")
  T.keyboard.press("Control+c");T.wait_for_timeout(300);clip=T.evaluate("navigator.clipboard.readText()")
  ok(clip=="첫째 문단\n둘째 문단\n셋째","복사: 글 전체 "+repr(clip))
  T.keyboard.press("Backspace");T.wait_for_timeout(700);bl=root(T)["recs"][-1]["blocks"];ok(len(bl)==1 and not bl[0]["x"],"지우기: 글 전체")
  T.click("#utoast button");T.wait_for_timeout(700);ok(len(root(T)["recs"][-1]["blocks"])==3,"되돌리기로 살림")
  # 도구 단추 · 덮어 쓰기
  T.click("[data-wc=tool]");T.wait_for_timeout(150);T.click("#wrTool [data-sa]");T.wait_for_timeout(200);ok(T.is_visible("#wrAllBar"),"🧰 도구 → ☑ 전체 선택 단추")
  T.keyboard.type("New");T.wait_for_timeout(700);bl=root(T)["recs"][-1]["blocks"];ok(len(bl)==1 and bl[0]["x"]=="New","전체 선택 뒤 글자를 치면 바꿔 씀 "+repr(bl))
  T.keyboard.type(" 글");T.wait_for_timeout(700);ok(root(T)["recs"][-1]["blocks"][0]["x"]=="New 글","이어서 그대로 입력(한글 포함)")
  T.keyboard.press("Control+a");T.wait_for_timeout(150);T.click("#wrEd .wbt");T.wait_for_timeout(150);ok(not T.is_visible("#wrAllBar"),"글을 누르면 전체 선택 풀림")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
