src=open('audit2.py').read();exec(src.split("sizes=")[0])
import base64
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
def cls(i,name,term,roster,phones,extra={}):return {"id":i,"data":{"v":3,"cls":name,"year":2026,"term":term,"roster":roster,"phones":phones,"emails":{},"teachers":[],"msg":"{이름} 결석 안내","sessions":[],**extra}}
def state():
  t1={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"days":{},"adj":{},
      "cells":{"0-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"3-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""}},
      "chg":[{"id":"g1","scope":"cell","d":2,"p":3,"from":"2026-10-21","to":"2026-10-21","type":"change","clsId":"c2","subject":"물리학","reason":"수업 교체","created":1},
             {"id":"g2","scope":"day","d":0,"p":1,"from":"2026-10-22","to":"2026-10-22","type":"cancel","reason":"재량휴업일","created":2}]}
  t2={"id":"t2","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"days":{},"adj":{},"chg":[],"cells":{"0-1":{"subject":"화학","clsId":"c2","clsName":"","room":""}}}
  ros=[["10101","가람"],["10103","김민준"],["10115","김민준"]]
  c1=cls("c1","1학년 1반","2학기",ros,{"10103":"010-3333-0103","10115":"010-3333-0115"},
     {"obs":[{"id":"o1","sid":"10115","date":"2026-10-12","tags":{},"memo":"실험 발표를 잘함","at":1}],"sts":{"10115":{"t":"세특 초안 문장","at":1}}})
  c1["data"]["sessions"]=[{"id":"s12","date":"2026-10-12","time":"09:00","label":"1교시 물리학","p":{"10101":True,"10103":True},"src":"t1:0:1"},
                          {"id":"s22","date":"2026-10-22","time":"09:00","label":"1교시 물리학","p":{"10101":True},"src":"t1:3:1"}]
  c9=cls("c9","1학년 1반","1학기",[["10101","가람"]],{},{"obs":[{"id":"q1","sid":"10101","date":"2026-05-01","tags":{},"memo":"1학기 기록","at":1},{"id":"q2","sid":"10101","date":"2026-05-02","tags":{},"memo":"1학기 기록2","at":1}]})
  c9["data"]["sessions"]=[{"id":"a%d"%i,"date":"2026-05-0%d"%i,"time":"09:00","label":"1교시","p":{"10101":True}} for i in (4,5,6)]
  return {"active":"c1","list":[c1,cls("c2","1학년 2반","2학기",[["10201","누리"],["10202","다온"]],{}),c9],"tt":{"list":[t1,t2],"active":"t1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"staff":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T16:40:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0');localStorage.setItem('att-app-attview','list')}catch(e){}"
errs=[]
def root(P):return json.loads(P.evaluate("localStorage.getItem('att-app-v2')"))
def cd(st,i):return [x for x in st["list"] if x["id"]==i][0]["data"]
def ses(st,i,date):return [s for s in cd(st,i)["sessions"] if s["date"]==date]
def edit(P,js):P.evaluate("(f)=>{const s=JSON.parse(localStorage.getItem('att-app-v2'));(new Function('S',f))(s);localStorage.setItem('att-app-v2',JSON.stringify(s))}",js);P.reload();P.wait_for_timeout(900)
def check_all(st,tag):
  a=ses(st,"c2","2026-10-21");ok(len(a)==1 and a[0]["src"]=="t1:2:3" and len(a[0]["p"])==2 and not ses(st,"c1","2026-10-21"),tag+"임시 변경: 변경을 취소해도 출석은 바꾼 학급(2반)에 그대로")
  h=ses(st,"c1","2026-10-22");ok(len(h)==1 and h[0]["p"]=={"10101":True},tag+"휴업일: 이미 한 출석은 지워지지 않음")
  o=[s for s in ses(st,"c1","2026-10-12")];ok(len(o)==1 and o[0]["label"]=="1교시 물리학" and set(o[0]["p"])=={"10101","10103"} and not ses(st,"c2","2026-10-12"),tag+"시간표 교체: 이전 출석은 예전 과목 · 학급 그대로")
  q=cd(st,"c9");ok(len(q["sessions"])==3 and len(q.get("obs",[]))==2,tag+"학기 전환: 1학기 출석 3회 · 관찰 2건 그대로")
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul",accept_downloads=True);c.route("**/*",handler)
  T=c.new_page();T.add_init_script("try{if(!localStorage.getItem('att-app-ttmode'))localStorage.setItem('att-app-ttmode','week')}catch(e){}");T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script("window.__goSpy=[];window.__fileSpy=[];")
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-view','tt')}}catch(e){}"%json.dumps(json.dumps(state()))+INIT)
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  # 1) 임시 변경 · 보강
  T.click("table.ttg .tc[data-d='2'][data-p='3']");T.wait_for_timeout(300)
  ok("1학년 2반" in T.inner_text("#sheetBox"),"변경된 칸은 바꾼 학급(2반)으로 열림")
  T.click("#cmAtt");T.wait_for_timeout(400);ok("1학년 2반" in T.inner_text("#cls"),"그 학급 출석 체크");T.click("#allIn");T.wait_for_timeout(300)
  edit(T,"S.tt.list[0].chg=S.tt.list[0].chg.filter(c=>c.id!=='g1')")
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  cell=T.inner_text("table.ttg .tc[data-d='2'][data-p='3']");ok("1학년 1반" in cell and "/" not in cell,"변경 취소 뒤 시간표 칸은 원래 학급, 2반 기록을 끌어오지 않음")
  # 2) 휴업일
  cell=T.inner_text("table.ttg .tc[data-d='3'][data-p='1']");ok("휴강" in cell and "재량휴업일" in cell,"휴업일 칸은 휴강 표시")
  T.click("table.ttg .tc[data-d='3'][data-p='1']");T.wait_for_timeout(300);ok(T.locator("#cmAtt").count()==0,"휴업일 칸에서는 출석 체크가 자동으로 생기지 않음");T.keyboard.press("Escape");T.evaluate("document.getElementById('sheet').hidden=true")
  edit(T,"S.active='c1'");T.click(".navb[data-v=att]");T.fill("#date","2026-10-22");T.dispatch_event("#date","change");T.wait_for_timeout(300)
  ok("재량휴업일" in T.inner_text("#offBar") and "출석 체크 1회" in T.inner_text("#dayHead"),"휴업일 전에 한 출석은 남고, 통계에서는 빠진다고 표시")
  # 3) 시간표 교체
  T.click(".navb[data-v=tt]");T.select_option("#ttSel","t2");T.wait_for_timeout(400)
  ok(root(T)["tt"]["active"]=="t2","새 시간표 적용")
  T.click("#ttPrev");T.wait_for_timeout(300);cell=T.inner_text("table.ttg .tc[data-d='0'][data-p='1']");ok("화학" in cell and "/" not in cell,"새 시간표 칸은 예전 출석을 끌어오지 않음")
  T.click(".navb[data-v=att]");T.evaluate("document.getElementById('clsBtn')");edit(T,"S.active='c1'")
  T.click(".navb[data-v=att]");T.fill("#date","2026-10-12");T.dispatch_event("#date","change");T.wait_for_timeout(300)
  ok("1학년 1반" in T.inner_text("#cls") and "1교시 물리학" in T.inner_text("#v-att") and "출석 체크 1회" in T.inner_text("#dayHead"),"예전 출석은 예전 과목 이름(물리학) · 1반으로 보임")
  # 동명이인 (같은 수업 10/12)
  rows=T.locator("#list .st");txt=[rows.nth(i).inner_text() for i in range(rows.count())]
  r03=[t for t in txt if "10103" in t][0];r15=[t for t in txt if "10115" in t][0]
  ok("출석" in r03 and "결석" in r15,"동명이인: 학번별로 출결이 따로 보임")
  T.locator("#list .st:has-text('10115')").click();T.wait_for_timeout(250)
  s12=ses(root(T),"c1","2026-10-12")[0];ok(set(s12["p"])=={"10101","10103","10115"},"동명이인 한 명을 바꾸면 그 학생만 바뀜")
  T.locator("#list .st:has-text('10103')").click();T.wait_for_timeout(250)
  s12=ses(root(T),"c1","2026-10-12")[0];ok(set(s12["p"])=={"10101","10115"},"다른 김민준도 따로 바뀜")
  T.click(".navb[data-v=call]");T.wait_for_timeout(300);ab=T.inner_text("#abList")
  ok(ab.count("김민준")==1 and "010-3333-0103" in ab and "0115" not in ab,"결석 연락은 결석한 김민준(10103) 번호로만")
  T.locator("#list .st:has-text('10103')").count()
  T.evaluate("document.querySelector('[data-key=\"m:att\"]').click()");T.wait_for_timeout(300);T.locator("#list .st:has-text('10103')").click();T.wait_for_timeout(200)
  T.click(".navb[data-v=set]");T.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)");T.wait_for_timeout(200)
  T.click("#stuList .prow:has-text('10115')");T.wait_for_timeout(250);T.fill("#esId","10116");T.click("#esOk");T.wait_for_timeout(400)
  d=cd(root(T),"c1");s12=[s for s in d["sessions"] if s["id"]=="s12"][0]
  ok(set(s12["p"])=={"10101","10103","10116"} and d["obs"][0]["sid"]=="10116" and "10116" in d.get("sts",{}) and "10115" not in d.get("sts",{}),"동명이인 한 명의 학번을 바꾸면 그 학생 출결 · 관찰 · 세특만 옮겨짐")
  ok(any(r==["10103","김민준"] for r in d["roster"]) and any(r==["10116","김민준"] for r in d["roster"]),"다른 김민준은 그대로")
  edit(T,"S.list.find(c=>c.id==='c1').data.roster.find(r=>r[0]==='10116')[0]='10115';const d=S.list.find(c=>c.id==='c1').data;d.obs[0].sid='10115';d.sts={'10115':d.sts['10116']};const s=d.sessions.find(x=>x.id==='s12');delete s.p['10116'];S.tt.active='t1'")
  # 4) 학기 전환
  edit(T,"S.period={year:2026,term:'1학기'};S.active='c9'")
  T.click(".navb[data-v=att]");T.wait_for_timeout(300);ok("1학기" in T.inner_text("#clsSub"),"1학기로 돌아가기")
  T.fill("#date","2026-05-05");T.dispatch_event("#date","change");T.wait_for_timeout(300);ok("출석 체크 1회" in T.inner_text("#dayHead"),"1학기 출석 그대로 보임")
  edit(T,"S.period={year:2026,term:'2학기'};S.active='c1'")
  check_all(root(T),"")
  T.screenshot(path="shot/t149.png")
  # 백업 → 다른 기기 복원 뒤에도 같은지
  T.click(".navb[data-v=set]");T.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)");T.click("#fullBk");T.wait_for_timeout(600);T.click("#fbGo");T.wait_for_timeout(1500)
  b64=T.evaluate("()=>window.__fbk.arrayBuffer().then(a=>{let s='';const u=new Uint8Array(a);for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)})")
  c2=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul");c2.route("**/*",handler)
  R=c2.new_page();R.add_init_script("try{if(!localStorage.getItem('att-app-ttmode'))localStorage.setItem('att-app-ttmode','week')}catch(e){}");R.on("pageerror",lambda e:errs.append("R:"+str(e)));R.add_init_script(FIX);R.add_init_script(INIT+"try{localStorage.setItem('att-app-view','set')}catch(e){}")
  R.goto("https://tl.test/index.html");R.wait_for_timeout(900);R.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)")
  R.evaluate("b=>{const s=atob(b),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);const f=new File([u],'x.tlbak',{type:'application/octet-stream'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('restoreFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",b64);R.wait_for_timeout(1500)
  if R.locator("#fbOk").count():R.click("#fbOk");R.wait_for_timeout(1500)
  R.click("#rsReplace");R.click("#rsReplace");R.wait_for_timeout(800)
  check_all(root(R),"복원 뒤 · ")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
