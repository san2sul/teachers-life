src=open('audit2.py').read();exec(src.split("sizes=")[0])
import re,urllib.parse,io,base64
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
STAFF=[{"name":"김과학","phone":"010-1000-0001","dept":"교무부","role":"교무부장","subj":"과학"},{"name":"이수학","phone":"010-1000-0002","dept":"연구부","role":"수업","subj":"수학"},
       {"name":"박국어","phone":"010-1000-0003","dept":"교무부","role":"학적","subj":"국어","email":"park@school.kr"},{"name":"최물리","phone":"010-1000-0004","dept":"과학정보부","role":"부장","subj":"과학"}]
def cls(i,name,roster,phones,emails={}):return {"id":i,"data":{"v":3,"cls":name,"year":2026,"term":"2학기","roster":roster,"phones":phones,"emails":emails,"teachers":[],"msg":"m","sessions":[]}}
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[cls("c1","1학년 1반",[["10101","가람"],["10102","가온"]],{"10101":"010-1111-0001"}),cls("c2","1학년 2반",[["10201","나래"],["10202","누리"]],{"10201":"010-2222-0001","10202":"010-2222-0002"}),cls("c3","2학년 1반",[["20101","다솜"]],{},{"20101":"dasom@ex.com"})],
    "staff":STAFF,"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def cls1(T):return [x for x in root(T)["list"] if x["id"]=="c1"][0]["data"]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",permissions=["clipboard-read","clipboard-write"]);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script("window.__goSpy=[];window.__fileSpy=[];window.__printSpy=[];")
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}))}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.evaluate("()=>{const b=document.getElementById('startSes');if(b&&!b.closest('[hidden]'))b.click();else document.querySelector('#tabs .tab.add').click()}");T.wait_for_timeout(400)
  ok(not T.locator("#akBox").is_hidden() and T.locator("#akBox .akr").count()==2,"출석 체크: 결석 학생 출결 구분 칸")
  T.locator("#list .st").first.click();T.wait_for_timeout(200);ok(T.locator("#akBox .akr").count()==1,"출석으로 바꾸면 구분 칸에서 빠짐")
  T.evaluate("document.querySelector('#akBox details').open=true")
  T.select_option("#akBox [data-akk='10102']","지각");T.select_option("#akBox [data-akr='10102']","질병");T.wait_for_timeout(300)
  s=cls1(T)["sessions"][-1];ok(s.get("ak",{}).get("10102")=="지각" and s.get("ar",{}).get("10102")=="질병","종류 · 사유 저장")
  T.screenshot(path="shot/t147_ak.png")
  T.reload();T.wait_for_timeout(900);T.evaluate("document.querySelector('#akBox details')&&(document.querySelector('#akBox details').open=true)")
  ok(T.input_value("#akBox [data-akk='10102']")=="지각" and T.input_value("#akBox [data-akr='10102']")=="질병","다시 열어도 그대로")
  # 나이스 요약
  T.click(".navb[data-v=stat]");T.wait_for_timeout(300);T.evaluate("()=>{const b=document.querySelector('#stabs .chip[data-t=att]');b&&b.click()}");T.wait_for_timeout(300)
  T.click("#neisBtn");T.wait_for_timeout(400);tx=T.input_value("#neTx")
  ok("가온(지각 - 질병)" in tx and "■ 1학년 1반" in tx and "학생별 합계" in tx and "가온: 지각 - 질병 1" in tx,"나이스 입력용 요약: 날짜별 · 학생별")
  T.screenshot(path="shot/t147_neis.png")
  T.click("#neCp");T.wait_for_timeout(300);ok("가온(지각 - 질병)" in T.evaluate("navigator.clipboard.readText()"),"요약 복사")
  T.click("#skNo");T.wait_for_timeout(200)
  # 학번을 바꾸면 구분도 따라감
  T.click(".navb[data-v=set]");T.wait_for_timeout(200);T.evaluate("()=>{document.querySelectorAll('details.card').forEach(d=>{if(d.querySelector('#stuList'))d.open=true})}")
  T.click("#stuList .prow:has-text('가온')");T.wait_for_timeout(200);T.fill("#esId","10199");T.click("#esOk");T.wait_for_timeout(300)
  s=cls1(T)["sessions"][-1];ok(s.get("ak",{}).get("10199")=="지각" and "10102" not in s.get("ak",{}) and s.get("ar",{}).get("10199")=="질병","학번을 바꾸면 출결 구분도 새 학번으로")
  # 전체 백업
  T.evaluate("()=>new Promise(res=>{const q=indexedDB.open('teachers-life-media',1);q.onupgradeneeded=()=>{try{q.result.createObjectStore('m')}catch(e){}};q.onsuccess=()=>{const tx=q.result.transaction('m','readwrite');tx.objectStore('m').put(new Blob([new Uint8Array(5000).fill(7)],{type:'image/jpeg'}),'wtestphoto');tx.objectStore('m').put('f-string-value','f:testfile');tx.oncomplete=()=>res(1)}})")
  T.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)");T.click("#fullBk");T.wait_for_timeout(600)
  ok("첨부 2개" in T.inner_text("#fbInfo"),"전체 백업: 기기 안 첨부 세기")
  T.fill("#fbP1","abcd1234");T.fill("#fbP2","abcd1234");T.click("#fbGo");T.wait_for_timeout(2000)
  fs=T.evaluate("window.__fileSpy");ok(fs and fs[-1]["name"].endswith(".tlbak"),"전체 백업 파일(.tlbak) 만들기")
  b64=T.evaluate("()=>window.__fbk.arrayBuffer().then(a=>{let s='';const u=new Uint8Array(a);for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)})")
  raw=base64.b64decode(b64);ok(raw[:6]==b"TLBK1\n" and "가온".encode() not in raw and b"10101" not in raw,"비밀번호를 건 파일 안에 학생 정보가 그대로 보이지 않음")
  # 새 기기에서 열기
  R=c.new_page();R.on("pageerror",lambda e:errs.append("R:"+str(e)));R.add_init_script(FIX);R.add_init_script("try{localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','set')}catch(e){}")
  R.goto("https://tl.test/index.html");R.wait_for_timeout(900)
  R.evaluate("()=>new Promise(res=>{const q=indexedDB.open('teachers-life-media',1);q.onsuccess=()=>{const tx=q.result.transaction('m','readwrite');tx.objectStore('m').clear();tx.oncomplete=()=>res(1)}})")
  R.click(".navb[data-v=set]");R.evaluate("document.querySelectorAll('#v-set details').forEach(d=>d.open=true)")
  R.evaluate("b=>{const s=atob(b),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);const f=new File([u],'x.tlbak',{type:'application/octet-stream'});const dt=new DataTransfer();dt.items.add(f);const i=document.getElementById('restoreFile');i.files=dt.files;i.dispatchEvent(new Event('change'))}",b64);R.wait_for_timeout(1000)
  ok(R.locator("#fbPw").count()==1,"전체 백업 열기: 비밀번호 묻기")
  R.fill("#fbPw","wrong");R.click("#fbOk");R.wait_for_timeout(2500);ok("비밀번호가 맞지 않습니다" in R.inner_text("#fbErr"),"틀린 비밀번호는 거부")
  R.fill("#fbPw","abcd1234");R.click("#fbOk");R.wait_for_timeout(2500)
  ok(R.locator("#rsReplace").count()==1 and R.locator("#sheetBox .bkcmp").count()==1,"맞는 비밀번호 → 백업 검사 · 불러오기 창")
  R.click("#rsReplace");R.click("#rsReplace");R.wait_for_timeout(800)
  got=R.evaluate("()=>new Promise(res=>{const q=indexedDB.open('teachers-life-media',1);q.onsuccess=()=>{const st=q.result.transaction('m').objectStore('m');const a=st.get('wtestphoto');a.onsuccess=()=>{const b2=st.get('f:testfile');b2.onsuccess=()=>res([a.result?a.result.size:0,a.result?a.result.type:'',b2.result])}}})")
  ok(got[0]==5000 and got[1]=="image/jpeg" and got[2]=="f-string-value","새 기기에 사진 · 첨부까지 옮겨짐")
  st=json.loads(R.evaluate("localStorage.getItem('att-app-v2')"));ok(any(len(x["data"]["roster"])==2 for x in st["list"]) and any(s2.get("ak",{}).get("10199")=="지각" for x in st["list"] for s2 in x["data"].get("sessions",[])),"자료(출결 구분 포함)도 그대로")
  R.screenshot(path="shot/t147_fbk.png")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
