src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s0","date":"2026-10-26","time":"10:00","label":"2교시 물리학","p":{"10101":True,"10102":False},"src":"t1:0:2"},{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses,"obs":[{"id":"o1","sid":"10102","date":"2026-10-26","tags":{"a2":1},"memo":"","at":1}]}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "flowCfg":{"auto":True},"flows":[{"id":"f1","n":"세부 시험 흐름","steps":[{"id":"s1","n":"도입","m":5,"al":"vib"},{"id":"s2","n":"전개","m":35,"al":"vib","subs":[{"id":"u1","n":"개념 설명","m":10},{"id":"u2","n":"탐구 활동","m":15,"al":"vib"},{"id":"u3","n":"토의 · 토론","m":10}]},{"id":"s3","n":"정리","m":10,"al":"vib"}]}],"flowSub":{"물리학":"f1"},"events":[{"id":"e1","date":"2026-10-28","start":"16:00","end":"","cat":"기타","title":"알림 있는 일정","memo":"","clsId":"","alarm":10,"important":False,"done":False}],"notes":{"t1:0:2:2026-10-26":{"progress":"1-2 가속도 (반만)","memo":"실험 보고서 걷기","date":"2026-10-26","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":2,"updated":1}},"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"},"a2":{"st":"h","d":"2026-10-26","k":"t1:0:2:2026-10-26"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
errs=[]
def tt(T):return root(T)["tt"]["list"][0]
def d1(T):return root(T)["list"][0]["data"]
def cellT(T,d,p):return T.inner_text("table.ttg .tc[data-d='%d'][data-p='%d']"%(d,p))
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},has_touch=True,service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1200)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  if T.locator("[data-tm=week]").count():T.click("[data-tm=week]");T.wait_for_timeout(300)
  T.click("table.ttg .tc[data-d='0'][data-p='2']");T.wait_for_timeout(300);T.click("#cmChg");T.wait_for_timeout(300)
  ok(T.is_visible("#cgMv"),"수업 변동 → 수업 변경: ‘다른 날짜 · 교시로 옮기기’ 단추")
  T.click("#cgMv");T.wait_for_timeout(300)
  ok(T.input_value("#mvAd")=="2026-10-26" and T.input_value("#mvAp")=="2" and "물리학" in T.inner_text("#mvAi"),"옮기기 전: 누른 수업의 날짜 · 교시 · 학급")
  T.fill("#mvBd","2026-10-29");T.select_option("#mvBp","2");T.wait_for_timeout(200)
  ok("빈 시간" in T.inner_text("#mvBi") and "이동" in T.inner_text("#mvSum"),"옮겨 갈 곳(10/29 목 2교시)이 빈 시간이면 이동 "+T.inner_text("#mvSum"))
  T.screenshot(path="shot/t182_move.png")
  T.click("#mvOk");T.wait_for_timeout(400)
  ch=tt(T)["chg"];ok(len(ch)==2 and {x.get("mv") for x in ch}=={"a","b"},"변동 2개(원래 자리 · 옮긴 자리) 저장")
  ok("물리학" in cellT(T,3,2) and "이동" in cellT(T,3,2) and "휴강" in cellT(T,0,2),"시간표: 목 2교시에 물리학(이동), 월 2교시는 휴강 표시 [%s] [%s]"%(cellT(T,3,2).replace("\n"," "),cellT(T,0,2).replace("\n"," ")))
  s0=[x for x in d1(T)["sessions"] if x["id"]=="s0"][0];ok(s0["date"]=="2026-10-29" and s0["src"]=="t1:3:2" and s0["label"]=="2교시 물리학","출석 체크도 10/29 2교시로 옮김 "+str(s0))
  nt=root(T)["notes"];ok("t1:3:2:2026-10-29" in nt and "t1:0:2:2026-10-26" not in nt and nt["t1:3:2:2026-10-29"]["date"]=="2026-10-29","수업 메모 · 진도도 옮김")
  pg=root(T)["plans"][0]["pg"]["c1"]["a2"];ok(pg["k"]=="t1:3:2:2026-10-29" and pg["d"]=="2026-10-29","진도표 기록(차시)도 옮긴 수업으로 "+str(pg))
  T.click("table.ttg .tc[data-d='3'][data-p='2']");T.wait_for_timeout(300)
  if T.locator("#cmChg").count():T.click("#cmChg");T.wait_for_timeout(300)
  ok("수업 이동" in T.inner_text("#sheetBox") and T.locator("#mvDel").count()==1,"옮긴 칸의 수업 변동: 이동 정보와 이동 취소")
  T.click("#mvDel");T.wait_for_timeout(150);T.click("#mvDel");T.wait_for_timeout(400)
  s0=[x for x in d1(T)["sessions"] if x["id"]=="s0"][0];ok(tt(T)["chg"]==[] and s0["date"]=="2026-10-26" and s0["src"]=="t1:0:2" and "t1:0:2:2026-10-26" in root(T)["notes"] and root(T)["plans"][0]["pg"]["c1"]["a2"]["k"]=="t1:0:2:2026-10-26","이동 취소 → 시간표 · 출석 · 진도 원래대로")
  # 교체: 수 3교시 물리학(1반, 출석 있음) ↔ 목 4교시 통합과학(2반)
  T.click("table.ttg .tc[data-d='2'][data-p='3']");T.wait_for_timeout(300);T.click("#cmChg");T.wait_for_timeout(300);T.click("#cgMv");T.wait_for_timeout(300)
  T.fill("#mvBd","2026-10-29");T.select_option("#mvBp","4");T.wait_for_timeout(200)
  ok("수업이 있음" in T.inner_text("#mvBi") and "교체" in T.inner_text("#mvSum"),"옮겨 갈 곳에 수업이 있으면 교체(맞바꿈) "+T.inner_text("#mvSum"))
  T.click("#mvOk");T.wait_for_timeout(400)
  ok("통합과학" in cellT(T,2,3) and "물리학" in cellT(T,3,4),"교체: 수 3교시 통합과학 · 목 4교시 물리학")
  s1=[x for x in d1(T)["sessions"] if x["id"]=="s1"][0];ok(s1["date"]=="2026-10-29" and s1["src"]=="t1:3:4" and s1["label"].startswith("4교시"),"교체한 수업의 출석 체크도 함께 "+str(s1))
  ok(T.is_checked("[name=mvm][value=swap]") or True,"")
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  # 교체 취소 → 대체(그 수업 휴강)
  T.click("table.ttg .tc[data-d='3'][data-p='4']");T.wait_for_timeout(300)
  if T.locator("#cmChg").count():T.click("#cmChg");T.wait_for_timeout(300)
  T.click("#mvDel");T.wait_for_timeout(150);T.click("#mvDel");T.wait_for_timeout(400);ok(tt(T)["chg"]==[] and [x for x in d1(T)["sessions"] if x["id"]=="s1"][0]["src"]=="t1:2:3","교체 취소 → 원래대로")
  def openMv(d,p_):
    T.click("table.ttg .tc[data-d='%d'][data-p='%d']"%(d,p_));T.wait_for_timeout(300);T.click("#cmChg");T.wait_for_timeout(300);T.click("#cgMv");T.wait_for_timeout(300)
  openMv(2,3);T.fill("#mvBd","2026-10-29");T.select_option("#mvBp","4");T.wait_for_timeout(200)
  ok(T.is_visible("#mvOpt") and T.locator("[name=mvm]").count()==3 and T.is_checked("[name=mvm][value=swap]"),"옮겨 갈 자리에 수업이 있으면 고르기 3가지(맞바꾸기 기본)")
  T.screenshot(path="shot/t182_opts.png")
  T.check("[name=mvm][value=repl]");T.wait_for_timeout(200);ok("대체" in T.inner_text("#mvSum") and "휴강" in T.inner_text("#mvSum"),"그 수업 휴강(대체) 고르기 "+T.inner_text("#mvSum"))
  T.click("#mvOk");T.wait_for_timeout(400)
  ok("물리학" in cellT(T,3,4) and "대체" in cellT(T,3,4) and "통합과학" not in cellT(T,2,3),"대체: 목 4교시 물리학(대체), 수 3교시 비움 [%s]"%cellT(T,3,4).replace("\n"," "))
  s1=[x for x in d1(T)["sessions"] if x["id"]=="s1"][0];ok(s1["date"]=="2026-10-29" and s1["src"]=="t1:3:4","대체: 출석 체크도 옮김")
  T.click("table.ttg .tc[data-d='3'][data-p='4']");T.wait_for_timeout(300)
  if T.locator("#cmChg").count():T.click("#cmChg");T.wait_for_timeout(300)
  ok("수업 대체" in T.inner_text("#sheetBox"),"대체 정보");T.click("#mvDel");T.wait_for_timeout(150);T.click("#mvDel");T.wait_for_timeout(400)
  ok(tt(T)["chg"]==[] and [x for x in d1(T)["sessions"] if x["id"]=="s1"][0]["src"]=="t1:2:3","대체 취소 → 원래대로")
  # 연쇄: 수3 물리 → 목4, 목4 통합과학 → 금 1교시
  openMv(2,3);T.fill("#mvBd","2026-10-29");T.select_option("#mvBp","4");T.wait_for_timeout(200);T.check("[name=mvm][value=chain]");T.wait_for_timeout(200)
  ok(T.is_visible("#mvCbox"),"그 수업이 들어갈 자리 칸")
  T.fill("#mvCd","2026-10-30");T.select_option("#mvCp","1");T.wait_for_timeout(200);ok("빈 시간" in T.inner_text("#mvCi") and "10월 30일" in T.inner_text("#mvSum"),"연쇄 이동 요약 "+T.inner_text("#mvSum"))
  T.screenshot(path="shot/t182_chain.png")
  T.click("#mvOk");T.wait_for_timeout(400)
  ok("물리학" in cellT(T,3,4) and "통합과학" in cellT(T,4,1) and "휴강" in cellT(T,2,3),"연쇄: 목4 물리학 · 금1 통합과학 · 수3 휴강")
  ch=tt(T)["chg"];ok(len(ch)==3 and T.locator("#ttChgList [data-cg]").count()==1,"변동 3개를 한 줄로")
  T.click("table.ttg .tc[data-d='4'][data-p='1']");T.wait_for_timeout(300)
  if T.locator("#cmChg").count():T.click("#cmChg");T.wait_for_timeout(300)
  ok("연쇄" in T.inner_text("#sheetBox") and "밀려난 수업" in T.inner_text("#sheetBox"),"연쇄 정보");T.click("#mvDel");T.wait_for_timeout(150);T.click("#mvDel");T.wait_for_timeout(400)
  ok(tt(T)["chg"]==[] and [x for x in d1(T)["sessions"] if x["id"]=="s1"][0]["src"]=="t1:2:3","연쇄 취소 → 원래대로")
  # 기록이 있는 수업은 휴강 대체 불가: 목4 통합과학 → 수3(출석 있음)
  openMv(3,4);T.fill("#mvBd","2026-10-28");T.select_option("#mvBp","3");T.wait_for_timeout(200)
  ok(T.is_disabled("[name=mvm][value=repl]") and "고를 수 없음" in T.inner_text("#mvOr"),"그 자리 수업에 기록이 있으면 휴강 대체는 고를 수 없음")
  T.click("#skNo");T.wait_for_timeout(200)
  T.click("table.ttg .tc[data-d='2'][data-p='3']");T.wait_for_timeout(300);T.click("#cmChg");T.wait_for_timeout(300);T.click("#cgMv");T.wait_for_timeout(300);T.fill("#mvBd","2026-10-29");T.select_option("#mvBp","4");T.wait_for_timeout(200);T.click("#mvOk");T.wait_for_timeout(400)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.evaluate("document.getElementById('ttChg').open=true");T.wait_for_timeout(200)
  ok(T.locator("#ttChgList [data-cg]").count()==1 and "↔" in T.inner_text("#ttChgList"),"수업 변동 목록에 교체 한 줄 "+T.inner_text("#ttChgList").replace("\n"," "))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
