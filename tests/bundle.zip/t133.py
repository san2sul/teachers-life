src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
R1=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"]]
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  ses=[{"id":"s1","date":"2026-10-22","time":"09:00","label":"1교시","p":{"10101":True,"10104":True}},
       {"id":"s2","date":"2026-10-21","time":"09:00","label":"1교시","p":{"10101":True,"10102":True,"10103":True}},
       {"id":"s3","date":"2026-10-20","time":"09:00","label":"1교시","p":{}}]
  tasks=[{"id":"k1","k":"perf","n":"실험 보고서 발표","due":"2026-10-22","cls":["c1"],"miss":{},"at":"2026-10-20T00:00:00Z"},
         {"id":"k2","k":"hw","n":"학습지","due":"2026-10-21","cls":["c1"],"miss":{},"at":"2026-10-19T00:00:00Z"},
         {"id":"k3","k":"form","n":"퀴즈(체크 전)","due":"2026-10-20","cls":["c1"],"miss":{},"at":"2026-10-18T00:00:00Z"},
         {"id":"k4","k":"form","n":"반영 안 함","due":"2026-10-22","cls":["c1"],"miss":{},"noAtt":True,"at":"2026-10-18T00:00:00Z"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":R1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}}],"staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":tasks,"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-22T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def task(T,i):return [x for x in root(T)["tasks"] if x["id"]==i][0]
def miss(T,i):return task(T,i).get("miss",{}).get("c1",{})
def ses(T,i):return [x for x in root(T)["list"][0]["data"]["sessions"] if x["id"]==i][0]["p"]
def setp(T,sid,v):
  T.evaluate("([sid,v])=>{const s=JSON.parse(localStorage.getItem('att-app-v2'));const x=s.list[0].data.sessions.find(y=>y.id==='s1');if(v)x.p[sid]=true;else delete x.p[sid];localStorage.setItem('att-app-v2',JSON.stringify(s))}",[sid,v]);T.reload();T.wait_for_timeout(900)
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX)
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','task');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  P0=json.dumps(root(T)["list"][0]["data"]["sessions"],sort_keys=True)
  ok(miss(T,"k1")=={"10102":"m","10103":"m"},"평가일 결석 학생 → 미참여 자동: "+str(miss(T,"k1")))
  ok(task(T,"k1").get("as",{}).get("c1")=={"10102":"a","10103":"a"},"auto marks remembered")
  ok(miss(T,"k2")=={"10104":"m"},"과제 마감일 결석 → 미제출: "+str(miss(T,"k2")))
  ok(miss(T,"k3")=={},"출석 체크를 아직 안 한 날(모두 결석 상태)은 반영 안 함")
  ok(miss(T,"k4")=={},"‘출석 결석 자동 반영’ 끈 평가는 그대로")
  # sheet shows 결석 badge + note
  T.locator("#ttTasks .tkrow",has_text="실험 보고서").click();T.wait_for_timeout(250);T.click("#sheetBox [data-hc]");T.wait_for_timeout(250)
  ok("결석" in T.inner_text("#sheetBox .tkgrid") and T.locator("#sheetBox .tkatt").count()==1 and T.locator("#tkOn .tkab").count()==2,"sheet shows 결석 badges + 안내")
  T.screenshot(path="shot/t133_sheet.png")
  # teacher: 다솜 later took the test → clear (manual)
  T.click("#sheetBox [data-tg='10103']");T.wait_for_timeout(250)
  ok(miss(T,"k1")=={"10102":"m"} and task(T,"k1")["as"]["c1"]["10103"]=="x","manual change takes the student out of auto sync")
  # teacher marks 가람(출석) as 미참여 → attendance unchanged
  T.click("#sheetBox [data-tg='10101']");T.wait_for_timeout(250)
  ok(miss(T,"k1").get("10101")=="m","manual 미참여 for present student")
  ok(json.dumps(root(T)["list"][0]["data"]["sessions"],sort_keys=True)==P0,"평가 · 과제를 고쳐도 출석 체크 결과는 그대로")
  T.evaluate("document.getElementById('sheet').hidden=true")
  # attendance fix: 나래 actually present → auto mark removed
  setp(T,"10102",True);T.evaluate("document.querySelector('#amode [data-m=task]').click()");T.wait_for_timeout(300)
  ok("10102" not in miss(T,"k1") and "10102" not in task(T,"k1").get("as",{}).get("c1",{}),"출석으로 고치면 자동 미참여가 빠짐")
  ok(miss(T,"k1").get("10101")=="m","manual mark kept")
  # 다솜 still absent but teacher cleared → stays cleared
  ok("10103" not in miss(T,"k1"),"직접 고친 학생은 다시 결석이어도 자동으로 안 바뀜")
  # 라온 now absent on 22 → auto added
  setp(T,"10104",False);T.evaluate("document.querySelector('#amode [data-m=task]').click()");T.wait_for_timeout(300)
  ok(miss(T,"k1").get("10104")=="m" and task(T,"k1")["as"]["c1"]["10104"]=="a","새로 결석 → 자동 추가")
  ok(miss(T,"k4")=={},"끈 평가는 여전히 그대로")
  # date change via editor → old auto marks follow the new date
  T.locator("#ttTasks .tkrow",has_text="실험 보고서").click();T.wait_for_timeout(250);T.click("#hbEdit");T.wait_for_timeout(250)
  ok(T.is_checked("#tkAtt"),"editor has 출석 결석 자동 반영 (checked)")
  T.fill("#tkD","2026-10-21");T.click("#tkOk");T.wait_for_timeout(300)
  m=miss(T,"k1");ok(m=={"10101":"m","10104":"m"},"날짜를 바꾸면 그 날(21일) 출석 기준으로 다시 맞춤: "+str(m))
  # turn off → auto marks removed
  T.click("#hbEdit");T.wait_for_timeout(250);T.uncheck("#tkAtt");T.click("#tkOk");T.wait_for_timeout(300)
  ok(task(T,"k1").get("noAtt")==True,"끄기 저장")
  ok(miss(T,"k1")=={"10101":"m"},"끄면 자동으로 넣은 표시만 빠지고 직접 넣은 것은 남음: "+str(miss(T,"k1")))
  # ---- 출석을 먼저 하고 평가 · 과제를 나중에 만들어도 반영 (공통 목록에서 만들기)
  T.evaluate("document.getElementById('sheet').hidden=true");T.wait_for_timeout(100)
  T.evaluate("document.querySelector('#amode [data-m=task]').click()");T.wait_for_timeout(250)
  T.click("#ttTkNew");T.wait_for_timeout(250);T.fill("#tkN","나중에 만든 수행평가");T.fill("#tkD","2026-10-22");T.click("#tkC [data-c='c1']");T.click("#tkOk");T.wait_for_timeout(400)
  nk=[x for x in root(T)["tasks"] if x["n"]=="나중에 만든 수행평가"][0]
  ok(nk["miss"].get("c1")=={"10103":"m","10104":"m"},"출석 먼저 → 나중에 만든 평가에 결석 학생 자동 반영: "+str(nk["miss"].get("c1")))
  ok(json.dumps(root(T)["list"][0]["data"]["sessions"],sort_keys=True)!=None,"")
  T.evaluate("document.getElementById('sheet').hidden=true");T.wait_for_timeout(100)
  # 학급 관찰 기록에서 나중에 만든 과제 (마감일 21일 → 21일 결석 학생)
  T.evaluate("document.querySelector('#amode [data-m=obs]').click()");T.wait_for_timeout(300)
  T.click("#tkNew");T.wait_for_timeout(250);T.click("#tkK [data-k='hw']");T.fill("#tkN","나중에 만든 과제");T.fill("#tkD","2026-10-21");T.click("#tkOk");T.wait_for_timeout(400)
  nh=[x for x in root(T)["tasks"] if x["n"]=="나중에 만든 과제"][0]
  ok(nh["miss"].get("c1")=={"10104":"m"},"학급 화면에서 나중에 만든 과제도 반영: "+str(nh["miss"].get("c1")))
  ok("결석" in T.inner_text("#sheetBox .tkgrid"),"만든 직후 체크 창에 결석 표시")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
