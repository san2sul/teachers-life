src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ROS=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"]]
def state(tt_extra):
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":"과학실"} for w in range(5)}
  cells["2-3"]={"subject":"통합과학","clsId":"c1","clsName":"","room":""}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]};t.update(tt_extra)
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ROS,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s1","date":"2026-10-21","time":"","label":"","p":{"10101":True}}]}}],
    "staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('%s').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
def dev(b,st,when,cheer=None,wx=None):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,timezone_id="Asia/Seoul");c.route("**/*",handler)
  if wx=="fail":c.route("https://api.open-meteo.com/**",lambda r:r.abort())
  elif wx:c.route("https://api.open-meteo.com/**",lambda r:(calls.append(r.request.url),r.fulfill(json=wx))[1])
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX%when);T.add_init_script(SPY)
  T.goto("https://tl.test/index.html");T.evaluate("([s,ch])=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-cheer',JSON.stringify(ch||{am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','5')}",[json.dumps(st),cheer])
  T.reload();T.wait_for_timeout(900);return T
SPY="window.__plays=[];window.__vib=[];const _p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){window.__plays.push({src:this.src,vol:this.volume});return Promise.resolve()};try{Object.defineProperty(navigator,'vibrate',{value:p=>{window.__vib.push(p);return true},configurable:true})}catch(e){}"
calls=[]
WX={"current":{"temperature_2m":-2.6,"apparent_temperature":-6,"weather_code":0},"daily":{"temperature_2m_max":[4.2],"temperature_2m_min":[-5.1]}}
def arm(T,label):T.click(f"#obsBar [data-k]:text-is('{label}')");T.wait_for_timeout(80)
def tap(T,sid):T.click(f"#obsList [data-s='{sid}']");T.wait_for_timeout(80)
def obs(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))["list"][0]["data"].get("obs",[])
with sync_playwright() as p:
  b=p.chromium.launch()
  ST=state({"from":"2026-08-24","to":"2026-12-31"})
  ST["list"][0]["data"]["roster"]=[[f"101{i:02d}",n] for i,n in enumerate(["가람","나래","다솜","라온","마루","바다"],1)]
  E=dev(b,ST,"2026-10-22T10:30:00+09:00")
  E.click(".navb[data-v=att]");E.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");E.wait_for_timeout(200)
  ok(E.locator("#obsBar [data-k]:text-is('수행평가 미참여')").count()==1,"new quick-check item: 수행평가 미참여")
  arm(E,"과제 미제출");[tap(E,s) for s in ("10101","10102","10103")]
  arm(E,"수행평가 미참여");[tap(E,s) for s in ("10102","10105")];arm(E,"수행평가 미참여")
  st=E.inner_text("#obsTsBox");print("  strip:",st.replace("\n"," "));ok("과제 미제출 3명" in st and "수행평가 미참여 2명" in st,"today's summary strip by item")
  E.click("#obsTsBox [data-ts]:has-text('과제 미제출')");E.wait_for_timeout(200)
  sh=E.inner_text("#sheetBox");ok("과제 미제출" in sh and E.locator("#tsOn [data-on]").count()==3 and E.locator("#tsOff [data-off]").count()==3,"summary: 3 checked / 3 not yet")
  E.screenshot(path="s541_ts.png")
  E.check("#tsOn [data-on='10102']");E.click("#tsDel");E.wait_for_timeout(200)
  ok(E.locator("#tsOn [data-on]").count()==2 and not any(r["sid"]=="10102" and r["tags"].get("a7") for r in obs(E)),"bulk remove selected")
  ok(any(r["sid"]=="10102" and r["tags"].get("a11") for r in obs(E)),"other item on same student kept")
  E.click("#utoast button");E.wait_for_timeout(200);ok(E.locator("#tsOn [data-on]").count()==3,"undo restores")
  E.click("#tsAllOff");E.click("#tsAdd");E.wait_for_timeout(200);ok(E.locator("#tsOn [data-on]").count()==6 and E.locator("#tsOff [data-off]").count()==0,"bulk add (모두 선택 → 넣기)")
  E.click("#tsAllOn");E.check("#tsOn [data-on='10104']") ;E.uncheck("#tsOn [data-on='10104']");E.click("#tsDel");E.wait_for_timeout(200)
  ok(E.locator("#tsOn [data-on]").count()==1,"bulk remove all but one")
  E.click("[data-tk]:has-text('수행평가 미참여')");E.wait_for_timeout(150);ok(E.locator("#tsOn [data-on]").count()==2,"switch item inside the sheet")
  E.click("#skNo")
  # another day → week scope aggregates
  E.fill("#obsDate","2026-10-20");E.dispatch_event("#obsDate","change");E.wait_for_timeout(200)
  arm(E,"수행평가 미참여");tap(E,"10102");tap(E,"10106");arm(E,"수행평가 미참여")
  E.click("#obsTsBox [data-ts]:has-text('수행평가 미참여')");E.click("[data-tsc=week]");E.wait_for_timeout(200)
  sh=E.inner_text("#tsOn");print("  week:",sh.replace("\n"," | "));ok(E.locator("#tsOn [data-on]").count()==3 and "10/20" in sh.replace("월 ","/").replace("일","") or "20" in sh,"week scope: 3 students with dates")
  ok(E.locator("#tsAdd").count()==0,"adding only in day scope")
  E.check("#tsOn [data-on='10102']");E.click("#tsDel");E.wait_for_timeout(200)
  ok(not any(r["sid"]=="10102" and r["tags"].get("a11") for r in obs(E)),"week scope: removed from both days")
  E.click("#skNo")
  # locked day
  E.click("#obsLockBtn");E.wait_for_timeout(150);E.click("#sheetBox .btn.pri") if E.is_visible("#sheetBox .btn.pri") else None;E.wait_for_timeout(150)
  E.click("#obsTsBox [data-ts]:has-text('항목별')");E.click("[data-tsc=day]");E.wait_for_timeout(200)
  ok(E.is_disabled("#tsAdd") if E.locator("#tsAdd").count() else True,"locked date: cannot add")
  b.close()
  # migration for customised items
  ST2=copy.deepcopy(ST);ST2["obsTags"]={"groups":[{"g":"수업 태도","items":[{"k":"a7","l":"과제 미제출","t":-1},{"k":"u1","l":"내 항목","t":1}]}]}
  b=p.chromium.launch();G=dev(b,ST2,"2026-10-22T10:30:00+09:00");G.click(".navb[data-v=att]");G.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");G.wait_for_timeout(200)
  labs=G.evaluate("[...document.querySelectorAll('#obsBar [data-k]')].map(b=>b.textContent)");ok(labs==["과제 미제출","수행평가 미참여","내 항목"],"customised items: 수행평가 미참여 added once after 과제 미제출: "+str(labs))
  b.close()
print("fails",F);print(errs)
