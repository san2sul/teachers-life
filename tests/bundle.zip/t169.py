src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "flowCfg":{"auto":True},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2,has_touch=True);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click(".navb[data-v=todo]");T.wait_for_timeout(500)
  H="#v-todo .nowhero"
  ok(T.locator(H+" [data-flpick]").count()==1,"지금 수업 카드에 ‘수업 흐름 정하기’")
  T.click(H+" [data-flpick]");T.wait_for_timeout(300)
  ok(T.locator("#sheetBox [data-fp]").count()==4 and "50분" in T.inner_text("#sheetBox h2"),"기본 틀 4개 · 수업 50분")
  T.click("#sheetBox [data-fp='b:3']");T.wait_for_timeout(100);T.click("#flUse");T.wait_for_timeout(1300)
  ok(root(T).get("flowSub",{}).get("물리학")=="b:3","물리학 기본 틀로 저장")
  txt=T.inner_text(H+" [data-flowbox]");ok("2/3" in txt and "전개" in txt and ("20:0" in txt or "19:5" in txt),"지금 단계 · 남은 시간 "+txt.replace("\n"," "))
  ok("다음 · 정리 10분" in txt,"다음 단계 안내")
  # 밀림 → 맞추기
  T.click(H+" [data-flplus]");T.wait_for_timeout(1300);txt=T.inner_text(H+" [data-flowbox]")
  ok("수업 끝을 2분 넘음" in txt and T.locator(H+" [data-flfit]").count()==1,"＋2분 → 수업 끝을 넘으면 경고")
  T.click(H+" [data-flfit]");T.wait_for_timeout(1300);ok(T.locator(H+" [data-flfit]").count()==0 and "정리" in T.inner_text(H+" [data-flowbox]"),"남은 단계 줄여 맞추기(정리는 꼭 지킴)")
  run=root(T)["flowRun"];adj=list(run.values())[0]["adj"];ok(abs(adj.get("b:3-1",0))<=1000 and "b:3-2" not in adj,"전개만 줄임 "+str(adj))
  # 1분 전 알림
  T.click(H+" [data-flmore]");T.wait_for_timeout(300);T.evaluate("window.__flowAlerts=[]")
  for k in range(19):T.click("#sheetBox [data-fla='b:3-1|-60000']");T.wait_for_timeout(60)
  T.click("#skNo");T.wait_for_timeout(1600);al=T.evaluate("window.__flowAlerts||[]");ok(any("전개 1분 남음" in (m or "") for a,m,*_ in al),"단계 끝나기 1분 전 알림 "+str(al))
  # 작은 표시(지금 수업 카드가 안 보일 때)
  T.click(".navb[data-v=att]");T.wait_for_timeout(1500);ok(T.is_visible("#flLine") and "전개" in T.inner_text("#flLine") and T.locator("#flPill:visible").count()==0,"5.92: 출석 체크 중에는 맨 위 수업 흐름 한 줄 "+(T.inner_text("#flLine") if T.locator("#flLine").count() else ""))
  T.click("#flLine [data-fls]");T.wait_for_timeout(300);ok(T.locator("#sheetBox .flsr").count()==3 and T.locator("#sheetBox .flsr.on").count()==1,"한 줄을 누르면 수업 흐름 창(단계 목록)")
  T.evaluate("window.__flowAlerts=[]");T.click("#skNo");T.wait_for_timeout(200)
  T.click(".navb[data-v=todo]");T.wait_for_timeout(600);T.click(H+" [data-flnext]");T.wait_for_timeout(1300)
  al=T.evaluate("window.__flowAlerts||[]");ok(any("정리 시작" in (m or "") for a,m,*_ in al) and "3/3" in T.inner_text(H+" [data-flowbox]"),"다음 단계 → 정리 시작 알림")
  # 흐름 끄기
  T.click(H+" [data-flmore]");T.wait_for_timeout(300);T.click("#sheetBox [data-flsw=off]");T.wait_for_timeout(200);T.click("#skNo");T.wait_for_timeout(1300);ok(T.locator(H+" [data-flpick]").count()==1 and "꺼짐" in T.inner_text(H+" [data-flpick]"),"이 수업 흐름 끄기 → 카드에 ‘꺼짐’")
  # 틀 직접 설계
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#ttPnBtn");T.wait_for_timeout(300);T.click("#flMgrB");T.wait_for_timeout(300);T.click("#flNew2");T.wait_for_timeout(300)
  ok(T.locator("#sheetBox .fled").count()==3 and "딱 맞음" in T.inner_text("#flSum"),"새 틀: 도입 · 전개 · 정리로 시작, 합계 확인")
  T.click("#flN");cd=c.new_cdp_session(T);T.evaluate("window.__n0=document.getElementById('flN')")
  for ch in "실험 수업":
    cd.send("Input.insertText",{"text":ch});T.wait_for_timeout(40)
  ok(T.input_value("#flN")=="실험 수업" and T.evaluate("window.__n0===document.getElementById('flN')"),"틀 이름 한글 입력")
  f0=".fled[data-j='0'] ";T.select_option("#sheetBox "+f0+"[data-k=m]","25");T.fill("#sheetBox .fled[data-j='1'] [data-k=n]","실험");T.select_option("#sheetBox .fled[data-j='1'] [data-k=m]","20");T.wait_for_timeout(100)
  ok("5분 넘침" in T.inner_text("#flSum"),"합계 55분 → 5분 넘침 "+T.inner_text("#flSum"))
  T.click("#sheetBox .fled[data-j='1'] summary");T.select_option("#sheetBox .fled[data-j='1'] [data-k=tool]","tm");T.select_option("#sheetBox .fled[data-j='1'] [data-k=al]","snd");T.fill("#sheetBox .fled[data-j='1'] [data-k=memo]","활동지 2번까지")
  T.click("#flFit2");T.wait_for_timeout(200);ok("딱 맞음" in T.inner_text("#flSum"),"수업 50분에 맞추기(정리는 그대로)")
  T.click("#flAdd");T.wait_for_timeout(200);ok(T.locator("#sheetBox .fled").count()==4,"단계 넣기")
  T.click("#sheetBox .fled[data-j='3'] [data-rm]");T.wait_for_timeout(200);ok(T.locator("#sheetBox .fled").count()==3,"단계 빼기")
  T.click("#flOk");T.wait_for_timeout(300)
  fl=root(T)["flows"];ok(len(fl)==1 and fl[0]["n"]=="실험 수업" and [x["n"] for x in fl[0]["steps"]]==["도입","실험","정리"] and sum(x["m"] for x in fl[0]["steps"])==50 and fl[0]["steps"][1]["tool"]=="tm" and fl[0]["steps"][1]["al"]=="snd" and fl[0]["steps"][2]["fix"],"직접 설계한 틀 저장 "+str([(x["n"],x["m"]) for x in fl[0]["steps"]]))
  fid=fl[0]["id"];T.click("#skNo");T.wait_for_timeout(200)
  # 진도표 차시에 틀 붙이기 → 그 차시 수업에서 그 틀
  T.click("#ttProg [data-pnc='a2']");T.wait_for_timeout(300);T.select_option("#pnFl",fid);T.wait_for_timeout(100);T.click("#skNo");T.wait_for_timeout(200)
  ok(root(T)["plans"][0]["units"][0]["ch"][1].get("flow")==fid,"진도표 1-2 차시에 틀 붙임")
  T.evaluate("window.__flowAlerts=[]")
  T.click(".navb[data-v=todo]");T.wait_for_timeout(1500);T.click(H+" [data-flpick]");T.wait_for_timeout(300);T.click("#sheetBox [data-flsw=on]");T.wait_for_timeout(300)
  ok("실험 수업" in T.inner_text("#sheetBox") and "진도표 1-2 차시의 틀" in T.inner_text("#sheetBox"),"켜기 → 다음 차시(1-2)의 틀이 교과 기본 틀보다 먼저")
  T.click("#skNo");T.wait_for_timeout(200)
  cur=T.inner_text(H+" [data-flowbox]");ok("도입" in cur and "활동지" not in cur,"지금은 도입 단계 "+cur.replace("\n"," "))
  T.click(H+" [data-flnext]");T.wait_for_timeout(1300)
  m1=root(T)["flows"][0]["steps"][1]["m"];ok(T.is_visible("#ctool") and T.inner_text("#ctBig") in("%02d:00"%m1,"%02d:00"%(m1-1)) and "시작" in T.inner_text("#ctTmGo"),"실험 단계 시작 → 타이머가 단계 시간으로 맞춰져 열림 "+(T.inner_text("#ctBig") if T.locator("#ctBig").count() else ""))
  al=T.evaluate("window.__flowAlerts||[]");ok(any(a=="snd" and "실험 시작" in (m or "") for a,m,*_ in al),"단계 알림 방식(진동 + 소리)")
  T.click("#ctX");T.wait_for_timeout(1200);ok("활동지 2번까지" in T.inner_text(H+" [data-flowbox]"),"단계 메모 표시")
  T.screenshot(path="shot/t169_card.png")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
