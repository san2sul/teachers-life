src=open('audit2.py').read();exec(src.split("sizes=")[0])
import re,urllib.parse
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
STAFF=[{"name":"김과학","phone":"010-1000-0001","dept":"교무부","role":"교무부장","subj":"과학"},{"name":"이수학","phone":"010-1000-0002","dept":"연구부","role":"수업","subj":"수학"},
       {"name":"박국어","phone":"010-1000-0003","dept":"교무부","role":"학적","subj":"국어"},{"name":"최물리","phone":"010-1000-0004","dept":"과학정보부","role":"부장","subj":"과학"}]
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":[["10101","가람"]],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":STAFF,"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def flush(T):T.wait_for_timeout(560)
def spy(T):return T.evaluate("window.__goSpy")
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script("window.__goSpy=[];window.__fileSpy=[];window.__printSpy=[];")
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  # ---- 교직원 입력 양식: 이름 · 연락처 · 부서 · 업무 · 교과
  T.click(".navb[data-v=set]");T.wait_for_timeout(300);T.evaluate("document.getElementById('d-staff').open=true");T.wait_for_timeout(200)
  ok(all(T.locator(x).count()==1 for x in ["#sfName","#sfPh","#sfDept","#sfRole","#sfSubj"]),"교직원 양식: 이름 · 연락처 · 부서 · 업무 · 교과")
  T.fill("#sfName","정영어");T.fill("#sfPh","010-1000-0005");T.fill("#sfDept","연구부");T.fill("#sfRole","방과후");T.fill("#sfSubj","영어");T.locator("#addStaff button[type=submit]").click();T.wait_for_timeout(400);flush(T)
  st=[x for x in root(T)["staff"] if x["name"]=="정영어"];ok(len(st)==1 and st[0].get("subj")=="영어" and st[0].get("role")=="방과후","교직원 추가 (교과 · 업무 저장)")
  T.screenshot(path="shot/t141_staff.png")
  # ---- 회의 참석자: 이름 · 부서 · 교과로 찾기
  T.click(".navb[data-v=att]");T.wait_for_timeout(300)
  T.evaluate("localStorage.setItem('att-app-amode','write')");T.reload();T.wait_for_timeout(900)
  T.click("[data-wn=meet]");T.wait_for_timeout(400);T.click("#wrWho");T.wait_for_timeout(300)
  rows=lambda:T.locator("#sheetBox [data-sw]").count()
  ok(rows()==5 and T.locator("#sheetBox [data-fd]").count()==4 and T.locator("#sheetBox [data-fs]").count()==5,"참석자 고르기: 부서 · 교과 단추")
  T.fill("#swQ","과학");T.wait_for_timeout(200);ok(rows()==2,"‘과학’으로 찾기 (교과 · 부서)")
  T.fill("#swQ","이수");T.wait_for_timeout(200);ok(rows()==1,"이름으로 찾기")
  T.fill("#swQ","");T.wait_for_timeout(200);T.click("#sheetBox [data-fd='교무부']");T.wait_for_timeout(200);ok(rows()==2,"부서로 거르기")
  T.click("#sheetBox [data-fd='']");T.click("#sheetBox [data-fs='과학']");T.wait_for_timeout(200);ok(rows()==2,"교과로 거르기")
  T.screenshot(path="shot/t141_pick.png")
  T.click("#swAll");T.wait_for_timeout(200);T.fill("#swN","외부 강사");T.click("#swAdd");T.wait_for_timeout(200);T.click("#swOk");T.wait_for_timeout(300);flush(T)
  r=root(T)["recs"][-1];ok(sorted(r["meet"]["who"])==sorted(["김과학","최물리","외부 강사"]),"보이는 사람 모두 고르기 + 직접 넣기")
  T.fill("#wrTi" if T.locator("#wrTi").count() else "#wrMn","교과 협의회") if False else None
  # ---- 전달하기: 명단에 없는 번호 · 메일 여러 개
  T.click("#skNo");T.wait_for_timeout(300);T.locator("#wrCard [data-ws]").first.click();T.wait_for_timeout(300)
  T.fill("#wsTo","010-7777-8888, 01066665555, a@b.com");T.click("[data-wsh=sms]");T.wait_for_timeout(300);g=spy(T)[-1]
  ok(g.startswith("sms:") and "01077778888" in g and "01066665555" in g,"전달: 직접 적은 번호 여러 개로 문자")
  T.fill("#wsTo","a@b.com, c@d.kr");T.click("[data-wsh=mail]");T.wait_for_timeout(300);g=spy(T)[-1];ok(g.startswith("mailto:a%40b.com,c%40d.kr"),"전달: 직접 적은 메일 여러 개")
  T.fill("#wsTo","010-7777-8888");T.click("[data-wsh=tel]");T.wait_for_timeout(300);ok(spy(T)[-1]=="tel:01077778888","전달: 직접 적은 번호로 전화")
  T.click("#skNo");T.wait_for_timeout(300)
  # ---- 연락 → ✍ 직접 입력
  T.click(".navb[data-v=call]");T.wait_for_timeout(300);T.click("#ctabs [data-c=direct]");T.wait_for_timeout(300)
  ok(not T.locator("#c-direct").is_hidden() and T.locator("#dmToT").count()==1,"연락: ✍ 직접 입력 탭")
  T.fill("#dmMsg","내일 학부모 상담 안내드립니다.");T.fill("#dmSub","상담 안내");T.fill("#dmToT","010-1234-5678; parent@mail.com 010 9876 5432")
  T.click("#dmTo [data-ds=sms]");T.wait_for_timeout(300);g=spy(T)[-1];ok(g.startswith("sms:") and "01012345678" in g and "%EB%82%B4%EC%9D%BC" in g or "내일" in urllib.parse.unquote(g),"직접 입력: 문자")
  T.click("#dmTo [data-ds=mail]");T.wait_for_timeout(300);g=spy(T)[-1];ok(g.startswith("mailto:parent%40mail.com?subject=") and "상담 안내" in urllib.parse.unquote(g),"직접 입력: 이메일")
  T.click("#dmTo [data-ds=tel]");T.wait_for_timeout(300);ok(spy(T)[-1]=="tel:01012345678","직접 입력: 전화")
  T.fill("#dmToT","abc");T.click("#dmTo [data-ds=sms]");T.wait_for_timeout(300);ok("전화번호를 적어" in T.inner_text("body"),"번호가 없으면 알림")
  rec=json.loads(T.evaluate("localStorage.getItem('tl-direct-recent')"));ok("01012345678" in rec and "parent@mail.com" in rec,"최근 보낸 번호 · 메일 기억")
  T.screenshot(path="shot/t141_direct.png")
  T.reload();T.wait_for_timeout(900);T.click(".navb[data-v=call]");T.wait_for_timeout(300);T.click("#ctabs [data-c=direct]");T.wait_for_timeout(300)
  ok(T.input_value("#dmMsg")=="내일 학부모 상담 안내드립니다." and T.locator("#dmTo [data-dr]").count()>=2,"쓰던 내용 · 최근 받는 사람 단추")
  T.locator("#dmTo [data-dr]").first.click();ok(T.input_value("#dmToT")!="","최근 받는 사람 누르면 채움")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
