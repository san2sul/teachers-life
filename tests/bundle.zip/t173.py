src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"flowSub":{"물리학":"b:exp"},"flows":[{"id":"f1","n":"내 틀","steps":[{"id":"s1","n":"도입","m":10,"al":"snd","tool":"","fix":False},{"id":"s2","n":"활동","m":40,"al":"vib","tool":"tm","fix":False}]}],"flowRun":{"2026-10-28|t1:3:4":{"off":True}},"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch()
  for v in ["todo","tt","att","call"]:
    c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
    T=c.new_page();cons=[];T.on("pageerror",lambda e:errs.append(str(e)));T.on("console",lambda m:cons.append(m.text) if m.type=="error" else None)
    T.add_init_script(FIX);T.add_init_script(INIT.replace("localStorage.setItem('att-app-view','tt')","localStorage.setItem('att-app-view','%s')"%v));T.goto("https://tl.test/index.html");T.wait_for_timeout(1500)
    bar=T.locator("#errBar").count() and T.is_visible("#errBar")
    ok(not bar and not cons,"%s 화면으로 시작해도 오류 없음 %s"%(v,(T.inner_text("#errBar") if bar else "")+str(cons[:2])))
    if v=="todo":
      ok(T.locator("#v-todo .nowhero [data-flowbox]").count()==1,"지금 수업 카드에 수업 흐름")
      if T.is_visible("#v-todo .nowhero .nhx"):T.click("#v-todo .nowhero .nhx");T.wait_for_timeout(300)
      chips=T.evaluate("[...document.querySelectorAll('#tdToday [data-flk]')].map(e=>e.textContent)")
      ok(any("실험 수업" in x for x in chips),"오늘 수업에 ⏱ 틀 이름 바로 표시(지금 수업 카드를 닫으면) "+str(chips))
    c.close()
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
