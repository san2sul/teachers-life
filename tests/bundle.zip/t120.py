src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ST={"active":"c0","list":[{"id":"c0","data":{"v":3,"cls":"1학년 1반","roster":[["10101","가나"]],"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block");c.route("**/*",handler);T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)))
  T.goto("https://tl.test/index.html");T.evaluate("s=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','stat');localStorage.setItem('att-app-ui','{}')}",json.dumps(ST))
  T.reload();T.wait_for_timeout(700);vw=lambda:T.evaluate("document.documentElement.dataset.view")
  ok(vw()=="todo","default: opens on 오늘 even though last view was 평가·통계")
  T.goto("https://tl.test/index.html?go=att");T.wait_for_timeout(700);ok(vw()=="att" and "go=" not in T.url,"shortcut ?go=att opens 출석, address cleaned")
  T.goto("https://tl.test/index.html?go=tt");T.wait_for_timeout(700);ok(vw()=="tt","shortcut ?go=tt opens 시간표")
  T.goto("https://tl.test/index.html?go=add");T.wait_for_timeout(1000);ok(vw()=="todo" and T.is_visible("#sheet") and "추가" in T.inner_text("#sheetBox")[:20],"shortcut ?go=add opens new 할 일")
  T.goto("https://tl.test/index.html?go=school");T.wait_for_timeout(700);ok(vw()=="todo","unknown/blocked target falls back to 오늘")
  T.goto("https://tl.test/index.html?go=%3Cscript%3E");T.wait_for_timeout(700);ok(vw()=="todo","junk parameter ignored")
  # preference: last view
  T.click(".navb[data-v=set]");T.evaluate("()=>{document.getElementById('d-ui').open=true}");T.click("[data-ui=open] [data-v=last]");T.wait_for_timeout(100)
  T.click(".navb[data-v=att]");T.evaluate("document.querySelector('[data-key=\"t:eval\"]').click()");T.wait_for_timeout(200);T.reload();T.wait_for_timeout(700);ok(vw()=="stat","setting '마지막으로 본 화면' restores last view")
  T.click(".navb[data-v=set]");T.evaluate("()=>{document.getElementById('d-ui').open=true}");T.click("#uiReset");T.wait_for_timeout(100);ok(T.evaluate("localStorage.getItem('att-app-ui')") is None,"모두 자동으로 clears the choice")
  T.evaluate("localStorage.setItem('att-app-ui','{}')");T.reload();T.wait_for_timeout(700);ok(vw()=="todo","no choice → opens on 오늘")
  m=json.load(open(APP+"/manifest.webmanifest",encoding="utf-8"))
  sc=m.get("shortcuts",[]);ok(len(sc)==4 and all(s["url"].startswith("./?go=") and s["icons"][0]["src"]=="icon-192.png" for s in sc),"manifest has 4 shortcuts inside app scope")
  ok(all(os.path.exists(os.path.join(APP,s["icons"][0]["src"])) for s in sc),"shortcut icons exist")
  b.close()
print("fails",F);print(errs)
