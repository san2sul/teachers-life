src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
# 5.93 오늘=안내 · 출석부=수업 진행 · 앱을 열 때 지금 수업 학급으로 맞춤
# (참고) 5.92 흐름 꼬임 · 수업 화면: 출석은 늘 오늘 · 돌아가는 단추 · 학생 창 · 학급 안 바뀜 · 출석부 수업 흐름 한 줄 · 일하는 중 인사 미루기
r1=[["10101","가람"],["10102","가온"],["10103","나래"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s0","date":"2026-10-26","time":"10:00","label":"2교시 물리학","p":{"10101":False,"10102":True},"src":"t1:0:2"},{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c2","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s2","date":"2026-10-28","time":"09:00","label":"1교시 물리학","p":{"10201":True},"src":"t1:2:1"}]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "flows":[{"id":"f1","n":"실험 수업","steps":[{"id":"x1","n":"도입","m":5,"al":"vib"},{"id":"x2","n":"실험","m":35,"al":"vib"},{"id":"x3","n":"정리","m":10,"al":"vib"}]}],"flowSub":{"물리학":"f1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘","ch":[{"id":"a1","t":"속력"}]}],"pg":{}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off+(window.__adv||0))}static now(){return R.now()+off+(window.__adv||0)}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:true,noon:false,pmAt:'11:00'}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},has_touch=True,service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1500)
  # 1. 저장된 학급(2반)으로 출석부가 열리던 문제 → 지금 수업 학급(1반)으로 맞춤
  ok(T.evaluate("document.documentElement.dataset.view")=="att","출석부로 시작")
  ok("1학년 1반" in T.inner_text("#cls") and root(T)["active"]=="c1","앱을 열면 지금 수업(3교시 1반) 학급으로 맞춤 "+T.inner_text("#cls"))
  ok("3교시" in T.inner_text("#sesCard"),"지금 수업의 출석 체크가 골라짐")
  ok(T.is_visible("#flLine") and "실험" in T.inner_text("#flLine"),"맨 위 수업 흐름 줄도 같은 수업 "+T.inner_text("#flLine").replace("\n"," ")[:60])
  # 2. 수업 흐름 창: 맨 위에 지금 흐름, 같은 단추는 한 번만
  T.click("#flLine [data-fls]");T.wait_for_timeout(500)
  ok(T.locator("#sheetBox .flsheetnow [data-flowbox]").count()==1 and "실험" in T.inner_text("#sheetBox .flsheetnow"),"수업 흐름 창 맨 위에 지금 흐름 상자")
  ok(T.locator("#sheetBox .flctl:visible").count()==0 and T.locator("#sheetBox .flsheetnow [data-flmore]:visible").count()==0,"창 안에서 ▶ ⏸ ■ · ⋯ 단추가 겹치지 않음")
  T.click("#sheetBox .flsheetnow [data-flgo=start]");T.wait_for_timeout(700)
  ok(T.locator("#sheetBox .flsr.on").count()==1 and T.locator("#sheetBox .flsheetnow [data-flgo=pause]").count()==1,"상자에서 ▶ 시작 → 창의 단계 목록도 지금 단계 표시")
  a0=T.inner_text("#sheetBox .flsr >> nth=1").split("\n")[0]
  T.click("#sheetBox .flsheetnow [data-flplus]");T.wait_for_timeout(700)
  a1=T.inner_text("#sheetBox .flsr >> nth=1").split("\n")[0]
  ok(a0!=a1,"상자에서 ＋2분 → 창의 단계 목록 시각도 함께 바뀜 "+a0+" → "+a1)
  T.click("#skNo");T.wait_for_timeout(300)
  # 3. 오늘 화면: 지금 수업 카드는 안내만(보기 · 가기)
  T.click(".navb[data-v=todo]");T.wait_for_timeout(800);H="#v-todo .nowhero"
  ok(T.locator(H+" [data-flowbox]").count()==0 and T.locator(H+" [data-nhtl]").count()==0 and T.locator(H+" [data-flgo]").count()==0,"오늘 카드에는 수업 흐름 조작 단추가 없음")
  t=T.inner_text(H).replace("\n"," ");ok("수업 열기 ›" in t and "⏱" in t and "실험" in t and "출석 2/3" in t and "1/3" in t,"카드: 출석 현황 · 지금 단계 안내 · 수업 열기 "+t[:140])
  T.screenshot(path="shot/t194_today.png")
  # 다른 반을 보다가 카드 → 지금 수업 학급의 출석부
  T.click(".navb[data-v=att]");T.wait_for_timeout(600);T.click("#clsBtn");T.wait_for_timeout(400);T.click("#sheetBox [data-id='c2']");T.wait_for_timeout(500)
  ok(root(T)["active"]=="c2","출석부에서 2반으로 바꿈")
  T.click(".navb[data-v=todo]");T.wait_for_timeout(600);T.click(H+" [data-nhgo]");T.wait_for_timeout(900)
  ok(T.evaluate("document.documentElement.dataset.view")=="att" and "1학년 1반" in T.inner_text("#cls") and "3교시" in T.inner_text("#sesCard"),"수업 열기 → 지금 수업 학급의 출석부 "+T.inner_text("#cls"))
  T.screenshot(path="shot/t194_att.png")
  # 4. 10분 넘게 다른 앱을 쓰다 돌아오면 지금 수업으로 다시 맞춤
  T.click("#clsBtn");T.wait_for_timeout(400);T.click("#sheetBox [data-id='c2']");T.wait_for_timeout(500);ok("1학년 2반" in T.inner_text("#cls"),"출석부에서 2반을 봄")
  vis="v=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>v});Object.defineProperty(document,'visibilityState',{configurable:true,get:()=>v?'hidden':'visible'});document.dispatchEvent(new Event('visibilitychange'))}"
  T.evaluate(vis,True);T.evaluate("window.__adv=3*60000");T.evaluate(vis,False);T.wait_for_timeout(500)
  ok("1학년 2반" in T.inner_text("#cls"),"잠깐(3분) 다녀오면 보던 학급 그대로")
  T.evaluate(vis,True);T.evaluate("window.__adv=15*60000");T.evaluate(vis,False);T.wait_for_timeout(800)
  ok("1학년 1반" in T.inner_text("#cls") and root(T)["active"]=="c1","10분 넘게 지나 돌아오면 지금 수업 학급으로 "+T.inner_text("#cls"))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
