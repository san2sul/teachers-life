src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
# 5.91.1 연계 검증: 한 차시(1-2)를 두 수업에 나눠 한 뒤(월 2교시 반만 → 수 3교시 마침) 수업을 옮기고 · 맞바꾸고 · 취소해도
# 두 수업의 진도 기록 · 수업 메모 · 출석 체크가 각각 제자리에 남는지
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
K0="t1:0:2:2026-10-26";K1="t1:2:3:2026-10-28";K2="t1:1:1:2026-10-27"
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s0","date":"2026-10-26","time":"10:00","label":"2교시 물리학","p":{"10101":True},"src":"t1:0:2","tm":{"10101":1}},{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3","tm":{"10101":2,"10102":3}}]
  pg={"c1":{"a1":{"st":"d","d":"2026-10-21"},"a2":{"st":"d","d":"2026-10-28","s":"s1","k":K1,"h":[{"st":"h","d":"2026-10-26","s":"s0","k":K0}]}},"c2":{"a1":{"st":"d","d":"2026-10-27","s":"s2","k":K2}}}
  notes={K0:{"progress":"1-2 가속도(반만)","pAuto":True,"memo":"월 메모","task":"","meet":"","date":"2026-10-26","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":2,"updated":1},
         K1:{"progress":"1-2 가속도","pAuto":True,"memo":"수 메모","task":"","meet":"","date":"2026-10-28","clsId":"c1","cls":"1학년 1반","subject":"물리학","period":3,"updated":2},
         K2:{"progress":"1-1 속력","pAuto":True,"memo":"2반 화 메모","task":"","meet":"","date":"2026-10-27","clsId":"c2","cls":"1학년 2반","subject":"물리학","period":1,"updated":3}}
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s2","date":"2026-10-27","time":"09:00","label":"1교시 물리학","p":{"10201":True},"src":"t1:1:1"}]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":notes,"events":[],"evals":[],"tasks":[],"recs":[],
    "plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘","ch":[{"id":"a1","t":"속력"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴"}]}],"pg":pg}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def ents(v):
  if not v:return []
  c={k:x for k,x in v.items() if k!="h"};return [c]+list(v.get("h",[]))
def a2(T):return sorted([(e["k"],e["d"],e["st"],e.get("s")) for e in ents(root(T)["plans"][0]["pg"]["c1"].get("a2"))])
def c2a1(T):return [(e["k"],e["d"],e["st"]) for e in ents(root(T)["plans"][0]["pg"]["c2"].get("a1"))]
def ses(T,cl,sid):return [x for x in root(T)["list"][cl]["data"]["sessions"] if x["id"]==sid][0]
def note(T,k):return (root(T)["notes"].get(k) or {}).get("memo")
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},has_touch=True,service_workers="block",timezone_id="Asia/Seoul");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(1200)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300)
  if T.locator("[data-tm=week]").count():T.click("[data-tm=week]");T.wait_for_timeout(300)
  A0=a2(T);S0=root(T)
  ok(A0==[(K0,"2026-10-26","h","s0"),(K1,"2026-10-28","d","s1")],"처음: 1-2가 월(반만) · 수(마침) 두 수업에 "+str(A0))
  def openMv(d,p_):
    T.click("table.ttg .tc[data-d='%d'][data-p='%d']"%(d,p_));T.wait_for_timeout(300);T.click("#cmChg");T.wait_for_timeout(300);T.click("#cgMv");T.wait_for_timeout(300)
  def cancelAt(d,p_):
    T.click(".navb[data-v=tt]");T.wait_for_timeout(200);T.click("table.ttg .tc[data-d='%d'][data-p='%d']"%(d,p_));T.wait_for_timeout(300)
    if T.locator("#cmChg").count():T.click("#cmChg");T.wait_for_timeout(300)
    T.click("#mvDel");T.wait_for_timeout(500)
  def same0(tag):
    R=root(T);ok(a2(T)==A0 and c2a1(T)==[(K2,"2026-10-27","d")] and R["tt"]["list"][0]["chg"]==[] and ses(T,0,"s0")["src"]=="t1:0:2" and ses(T,0,"s1")["src"]=="t1:2:3" and ses(T,1,"s2")["src"]=="t1:1:1"
       and note(T,K0)=="월 메모" and note(T,K1)=="수 메모" and note(T,K2)=="2반 화 메모" and ses(T,0,"s1")["tm"]=={"10101":2,"10102":3},tag+": 진도 두 기록 · 메모 · 출석(누른 시각 포함)이 처음 그대로 "+str(a2(T)))
  # ① 수 3교시(마침 쪽)를 목 2교시(빈 시간)로 옮기기
  openMv(2,3);T.fill("#mvBd","2026-10-29");T.select_option("#mvBp","2");T.wait_for_timeout(200);T.click("#mvOk");T.wait_for_timeout(500)
  K1m="t1:3:2:2026-10-29"
  ok(a2(T)==[(K0,"2026-10-26","h","s0"),(K1m,"2026-10-29","d","s1")],"① 이동: 마침 기록만 목 2교시로, 월 반만 기록은 그대로 "+str(a2(T)))
  ok(note(T,K1m)=="수 메모" and note(T,K0)=="월 메모" and K1 not in root(T)["notes"] and ses(T,0,"s1")["src"]=="t1:3:2" and ses(T,0,"s1")["tm"]=={"10101":2,"10102":3},"① 이동: 메모 · 출석(누른 시각)도 함께, 월 수업은 그대로")
  cancelAt(3,2);same0("① 이동 취소")
  # ② 월 2교시(반만 쪽, 1반) ↔ 화 1교시(2반) 맞바꾸기 — 두 반 기록이 서로 섞이지 않아야 함
  openMv(0,2);T.fill("#mvBd","2026-10-27");T.select_option("#mvBp","1");T.wait_for_timeout(200)
  if T.locator("[name=mvm][value=swap]").count():T.check("[name=mvm][value=swap]")
  T.click("#mvOk");T.wait_for_timeout(500)
  A=a2(T);C2=c2a1(T)
  ok(A==[(K2,"2026-10-27","h","s0"),(K1,"2026-10-28","d","s1")] and C2==[(K0,"2026-10-26","d")],"② 맞바꾸기: 1반 반만 기록은 화 1교시로, 2반 기록은 월 2교시로(반끼리 섞이지 않음) "+str(A)+str(C2))
  ok(note(T,K2)=="월 메모" and note(T,K0)=="2반 화 메모" and note(T,K1)=="수 메모","② 맞바꾸기: 메모도 서로 자리를 바꿈, 수 수업은 그대로")
  cancelAt(1,1);same0("② 맞바꾸기 취소")
  # ③ 수 3교시(마침 쪽) → 월 2교시(반만 쪽, 같은 반의 다른 수업이 있는 자리)로 맞바꾸기 — 같은 차시의 두 기록이 서로 자리를 바꿈
  openMv(2,3);T.fill("#mvBd","2026-10-26");T.select_option("#mvBp","2");T.wait_for_timeout(200)
  if T.locator("[name=mvm][value=swap]").count():T.check("[name=mvm][value=swap]")
  T.click("#mvOk");T.wait_for_timeout(500)
  A=a2(T);ok(len(A)==2 and {x[2] for x in A}=={"h","d"} and {x[0] for x in A}=={K0,K1},"③ 같은 반 두 수업 맞바꾸기: 1-2 기록 둘(반만 · 마침)이 모두 남음 "+str(A))
  ok(dict((x[3],x[0]) for x in A)=={"s1":K0,"s0":K1},"③ 마침 기록(수 출석 s1)은 월 자리로, 반만 기록(월 출석 s0)은 수 자리로 "+str(A))
  cancelAt(0,2);same0("③ 맞바꾸기 취소")
  # ④ 이동 → 되돌리기 알림으로 취소해도 같음
  openMv(2,3);T.fill("#mvBd","2026-10-30");T.select_option("#mvBp","5");T.wait_for_timeout(200);T.click("#mvOk");T.wait_for_timeout(500)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(200);T.click("table.ttg .tc[data-d='4'][data-p='5']");T.wait_for_timeout(300)
  if T.locator("#cmChg").count():T.click("#cmChg");T.wait_for_timeout(300)
  T.click("#mvDel");T.wait_for_timeout(400);same0("④ 이동 취소")
  T.click("#utoast button");T.wait_for_timeout(500)
  ok(a2(T)==[(K0,"2026-10-26","h","s0"),("t1:4:5:2026-10-30","2026-10-30","d","s1")],"④ 취소를 되돌리면 다시 금 5교시로 "+str(a2(T)))
  cancelAt(4,5);same0("④ 다시 취소")
  # 진도 현황 표에서도 두 수업이 각각
  T.click("#ttPnBtn");T.wait_for_timeout(400)
  rows=T.evaluate("[...document.querySelectorAll('#pnLogCard .pnlr')].map(r=>r.innerText.replace(/\\n/g,' '))")
  ok(any("1-2 반만" in r for r in rows) and any("1-2" in r and "반만" not in r for r in rows),"진도 현황 표: 월 ‘1-2 반만’ · 수 ‘1-2’ 각각 "+str(rows))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
