src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ros=[["1010%d"%i,"학생%d"%i] for i in range(1,7)]
def state():
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ros,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],"tt":{"list":[],"active":""},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-wrk','stu');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-ctfx',JSON.stringify({sec:2,snd:true}));localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}))}}catch(e){}"%json.dumps(json.dumps(state()))
VV="(()=>{const t=new EventTarget();t.height=844;t.width=390;t.offsetTop=0;t.offsetLeft=0;t.scale=1;t.pageTop=0;window.__vv=t;try{Object.defineProperty(window,'visualViewport',{configurable:true,get:()=>t})}catch(e){}})()"
AC="(()=>{window.__acs=[];class A extends OfflineAudioContext{constructor(){super(1,48000*4,48000);window.__acs.push(this)}resume(){return Promise.resolve()}};window.AudioContext=A;window.webkitAudioContext=A})()"
errs=[]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block");c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(VV);T.add_init_script(AC);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  # 1. 아이폰 키보드: 창을 보이는 영역에 맞춤
  T.click("#wrCard [data-sub=cns]");T.wait_for_timeout(400)
  ok(T.evaluate("document.getElementById('sheet').style.top")=="","키보드 없을 때는 원래 자리")
  T.evaluate("()=>{const v=window.__vv;v.height=420;v.offsetTop=260;v.dispatchEvent(new Event('resize'))}");T.wait_for_timeout(200)
  st=T.evaluate("(()=>{const s=document.getElementById('sheet'),b=document.getElementById('sheetBox');return [s.style.top,s.style.height,b.style.maxHeight]})()")
  ok(st==["260px","420px","412px"],"키보드가 올라오면 창을 보이는 영역에 맞춤 "+str(st))
  ok(T.evaluate("document.getElementById('sheetBox').getBoundingClientRect().top")>=260,"창 위쪽이 보이는 영역 안")
  T.evaluate("()=>{const v=window.__vv;v.height=844;v.offsetTop=0;v.dispatchEvent(new Event('resize'))}");T.wait_for_timeout(200)
  ok(T.evaluate("document.getElementById('sheet').style.top")=="" and T.evaluate("document.getElementById('sheetBox').style.maxHeight")=="","키보드가 내려가면 원래대로")
  T.click("#skNo");T.wait_for_timeout(300)
  # 2. 뽑기 드럼롤이 끝까지 울림
  T.evaluate("document.getElementById('ctBtn').click()");T.wait_for_timeout(200);T.click("#ctool [data-ct=pk]");T.wait_for_timeout(150);T.click("#ctGo");T.wait_for_timeout(2600)
  r=T.evaluate("""async()=>{const ac=window.__acs[window.__acs.length-1];const buf=await ac.startRendering();const d=buf.getChannelData(0),sr=buf.sampleRate,out=[];for(let s=0;s<2;s+=.5){let sum=0;const a=Math.floor(s*sr),e=Math.floor((s+.5)*sr);for(let i=a;i<e;i++)sum+=d[i]*d[i];out.push(Math.sqrt(sum/(e-a)))}let pk=0;for(const x of d)pk=Math.max(pk,Math.abs(x));return [out,pk]}""")
  ok(all(x>0.05 for x in r[0][1:]),"드럼롤이 뜸 들이는 동안 계속 울림 "+str([round(x,3) for x in r[0]]))
  ok(r[1]<=1.0,"소리가 찢어지지 않음 (최고 %.2f)"%r[1])
  T.reload();T.wait_for_timeout(900);T.evaluate("document.getElementById('ctBtn').click()");T.wait_for_timeout(200)
  T.click("#ctool [data-ct=gp]");T.wait_for_timeout(150);T.click("#ctSplit");T.wait_for_timeout(2700)
  r=T.evaluate("""async()=>{const ac=window.__acs[window.__acs.length-1];const buf=await ac.startRendering();const d=buf.getChannelData(0),sr=buf.sampleRate,out=[];for(let s=0;s<2;s+=.5){let sum=0;const a=Math.floor(s*sr),e=Math.floor((s+.5)*sr);for(let i=a;i<e;i++)sum+=d[i]*d[i];out.push(Math.sqrt(sum/(e-a)))}return out}""")
  ok(all(x>0.05 for x in r[1:]),"모둠 나누기 드럼롤도 계속 울림 "+str([round(x,3) for x in r]))
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
