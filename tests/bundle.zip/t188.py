src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "pnCfg":{"mode":"auto","from":"2026-10-26"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(3200)
  pg=lambda cid="c1":plan(T)["pg"].get(cid,{})
  ok(root(T)["pnCfg"]["mode"]=="manual" and set(pg())=={"a1"},"기본은 직접 입력: 고르지 않고 자동이던 설정은 직접 입력으로, 자동 기록 안 함 "+str(root(T)["pnCfg"]))
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#ttPnBtn");T.wait_for_timeout(300)
  ok(T.get_attribute("[data-pnm=manual]","aria-pressed")=="true" and T.locator("#pnLogCard").count()==1,"진도 현황: 직접 입력 선택 · 수업별 진도 기록 표")
  rows=T.evaluate("[...document.querySelectorAll('#pnLogCard .pnlr')].map(r=>r.innerText.replace(/\\n/g,' '))")
  ok(len(rows)==3 and "1학년 1반" in rows[0] and "1학년 2반" in rows[1] and "기록 없음" in rows[0],"이 주 물리학 수업 3개(월 1반 · 화 2반 · 수 1반) 한 줄씩 "+str(rows))
  T.locator("#pnLogCard").screenshot(path="shot/t188_log.png")
  # 월 1반: 계획 1-2 → 반만으로 고치기(한 곳에서)
  T.click("#pnLogCard [data-pnle='0']");T.wait_for_timeout(300)
  ok("10월 26일" in T.inner_text("#sheetBox h2") and T.locator("#pnLsBox [data-pc]").count()>=3,"고치기: 그 수업의 진도 목록 창")
  T.click("#pnLsBox [data-pc='a2|h']");T.wait_for_timeout(300);T.click("#skNo");T.wait_for_timeout(300)
  ok(pg()["a2"]["st"]=="h" and pg()["a2"]["k"]=="t1:0:2:2026-10-26","월 1반 1-2 반만(그 수업 기록)")
  # 화 2반: ✓ 계획대로
  T.click("#pnLogCard [data-pnlq='1']");T.wait_for_timeout(300);ok(pg("c2").get("a1",{}).get("k")=="t1:1:1:2026-10-27","화 2반: ✓ 1-1 마침 바로 기록")
  T.click("#utoast button");T.wait_for_timeout(300);ok("a1" not in pg("c2"),"되돌리기");T.click("#pnLogCard [data-pnlq='1']");T.wait_for_timeout(300)
  # 수 1반: 한 차시를 두 수업에 — 1-2 마침(월 반만은 그대로)
  rows=T.evaluate("[...document.querySelectorAll('#pnLogCard .pnlr')].map(r=>r.innerText.replace(/\\n/g,' '))");ok("1-2 마침" in rows[2],"수 1반 계획은 1-2(월에 반만) "+rows[2])
  T.click("#pnLogCard [data-pnlq='2']");T.wait_for_timeout(300)
  a2=pg()["a2"];ok(a2["st"]=="d" and a2["k"]=="t1:2:3:2026-10-28" and a2.get("h",[{}])[0].get("st")=="h" and a2["h"][0]["k"]=="t1:0:2:2026-10-26","1-2: 월 반만 + 수 마침 두 기록 모두 "+str(a2))
  rows=T.evaluate("[...document.querySelectorAll('#pnLogCard .pnlr')].map(r=>r.innerText.replace(/\\n/g,' '))")
  ok("1-2 반만" in rows[0] and "1-2" in rows[2] and "반만" not in rows[2],"표: 월 ‘1-2 반만’, 수 ‘1-2’ 각각 "+str(rows))
  ok("1-2" in T.inner_text("#ttProg .pnr >> nth=0") or "1-3" in T.inner_text("#ttProg .pnr >> nth=0"),"현황(다음 차시)은 최근 기록 기준")
  # 출석부(수 1반)에서도 같은 기록
  T.evaluate("localStorage.setItem('att-app-ttprog','0')");T.reload();T.wait_for_timeout(1200);T.click(".navb[data-v=tt]");T.wait_for_timeout(400)
  T.click(".tc[data-d='2'][data-p='3']");T.wait_for_timeout(400);T.locator("#cmAtt").dispatch_event("click");T.wait_for_timeout(500)
  ok("1-2" in T.inner_text("#pnBar") or "가속도" in T.inner_text("#pnBar"),"출석부 📘에 같은 기록 "+T.inner_text("#pnBar").replace("\n"," ")[:80])
  ok("1-2" in T.inner_text("#pnBar .pnlast") or "반만" in T.inner_text("#pnBar"),"지난 시간(월 1-2 반만)도 보임")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
