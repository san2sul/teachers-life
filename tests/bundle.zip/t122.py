src=open('audit2.py').read();exec(src.split("sizes=")[0])
import copy
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ROS=[["10101","가람"],["10102","나래"],["10103","다솜"],["10104","라온"]]
def state(tt_extra):
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":"과학실"} for w in range(5)}
  cells["2-3"]={"subject":"통합과학","clsId":"c1","clsName":"","room":""}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]};t.update(tt_extra)
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ROS,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[{"id":"s1","date":"2026-10-21","time":"","label":"","p":{"10101":True}}]}}],
    "staff":[],"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('%s').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
def dev(b,st,when,cheer=None,wx=None):
  c=b.new_context(viewport={"width":390,"height":844},service_workers="block",accept_downloads=True,timezone_id="Asia/Seoul");c.route("**/*",handler)
  if wx=="fail":c.route("https://api.open-meteo.com/**",lambda r:r.abort())
  elif wx:c.route("https://api.open-meteo.com/**",lambda r:(calls.append(r.request.url),r.fulfill(json=wx))[1])
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX%when);T.add_init_script(SPY)
  T.goto("https://tl.test/index.html");T.evaluate("([s,ch])=>{localStorage.setItem('att-app-v2',s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-cheer',JSON.stringify(ch||{am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','5')}",[json.dumps(st),cheer])
  T.reload();T.wait_for_timeout(900);return T
SPY="window.__plays=[];window.__vib=[];const _p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){window.__plays.push({src:this.src,vol:this.volume});return Promise.resolve()};try{Object.defineProperty(navigator,'vibrate',{value:p=>{window.__vib.push(p);return true},configurable:true})}catch(e){}"
calls=[]
WX={"current":{"temperature_2m":-2.6,"apparent_temperature":-6,"weather_code":0},"daily":{"temperature_2m_max":[4.2],"temperature_2m_min":[-5.1]}}
with sync_playwright() as p:
  b=p.chromium.launch()
  ST=state({"from":"2026-08-24","to":"2026-12-31"})
  # ---- 1. 짧은 메모
  E=dev(b,ST,"2026-10-22T10:30:00+09:00")
  E.click(".navb[data-v=att]");E.wait_for_timeout(200);E.evaluate("()=>{const b=document.getElementById('startSes');if(b&&!b.closest('[hidden]'))b.click();else document.querySelector('#tabs .tab.add').click()}");E.wait_for_timeout(300)
  on0=E.evaluate("document.querySelectorAll('#list .st.on').length")
  t=E.locator("#list .st >> nth=1");bb=t.bounding_box();E.mouse.move(bb["x"]+20,bb["y"]+20);E.mouse.down();E.wait_for_timeout(800);E.mouse.up();E.wait_for_timeout(300)
  ok(E.is_visible("#sheet") and "나래 짧은 메모" in E.inner_text("#sheetBox"),"long-press on attendance tile opens 짧은 메모")
  ok(E.evaluate("document.querySelectorAll('#list .st.on').length")==on0,"long-press did not toggle attendance")
  E.fill("#snT","앞자리 배치 필요");E.click("#snAdd");E.wait_for_timeout(150)
  E.click("#snK [data-k=prom]");E.fill("#snT","다음 시간 발표 기회 주기");E.press("#snT","Enter");E.wait_for_timeout(150)
  E.click("#snK [data-k=note]");E.fill("#snT","실험 정리 꼼꼼");E.click("#snAdd");E.wait_for_timeout(150);E.click("#skNo")
  d0=json.loads(E.evaluate("localStorage.getItem('att-app-v2')"))["list"][0]["data"]["snote"]["10102"]
  ok([n["k"] for n in d0]==["warn","prom","note"] and d0[1]["t"]=="다음 시간 발표 기회 주기","saved 3 notes")
  tile=E.inner_text("#list .st >> nth=1");ok("주의" in tile and "약속" in tile and "특기" in tile,"tile shows small marks: "+tile.replace("\n"," "))
  E.click(".navb[data-v=todo]");E.wait_for_timeout(300);tx=E.inner_text("#tdToday");ok("학생과의 약속" in tx and "다음 시간 발표 기회 주기" in tx,"오늘 tab lists open promises")
  E.click("#tdToday [data-prom]");E.wait_for_timeout(200);E.click("[data-done]");E.wait_for_timeout(200);E.click("#skNo");E.wait_for_timeout(200)
  ok("학생과의 약속" not in E.inner_text("#tdToday"),"kept promise leaves the 오늘 list")
  E.click(".navb[data-v=att]");E.wait_for_timeout(200);ok("약속" not in E.inner_text("#list .st >> nth=1"),"kept promise mark removed")
  E.click("[data-av=list]");E.wait_for_timeout(150);ok("주의 · 앞자리 배치 필요" in E.inner_text("#list .st >> nth=1"),"list view shows first note text");E.click("[data-av=grid]")
  E.click(".navb[data-v=set]");E.evaluate("()=>{document.querySelectorAll('details.card').forEach(d=>{if(d.querySelector('#stuList'))d.open=true})}");E.wait_for_timeout(100)
  ok("주의 · 특기" in E.inner_text("#stuList .prow:has-text('나래') em"),"roster list badge")
  E.click("#stuList .prow:has-text('나래')");E.wait_for_timeout(200);ok("3개" in E.inner_text("#esSn"),"edit sheet: 짧은 메모 button with count");E.fill("#esId","10150");E.click("#esOk");E.wait_for_timeout(200)
  ok(len(json.loads(E.evaluate("localStorage.getItem('att-app-v2')"))["list"][0]["data"]["snote"]["10150"])==3,"학번 change carries notes")
  E.evaluate("()=>{document.getElementById('d-ui').open=true}");E.click("[data-ui=low] [data-v=hide]");E.click(".navb[data-v=att]");E.wait_for_timeout(200)
  ok(E.locator("#list .sntag").count()==0,"hide option hides note marks");E.click(".navb[data-v=set]");E.click("[data-ui=low] [data-v='']")
  E.reload();E.wait_for_timeout(800);E.click(".navb[data-v=att]");E.wait_for_timeout(200);ok(E.locator("#list .sntag").count()>=2,"survives reload")
  # ---- 2. 하루 세 번 인사 (날씨 · 기온 · 기분 · 업무량)
  ST2=copy.deepcopy(ST);ST2["events"]=[{"id":f"e{i}","date":"2026-10-22","start":"15:00","end":"","cat":"교무 업무","title":f"업무{i}","memo":"","clsId":"","alarm":-1,"important":False,"done":False} for i in range(4)]
  for w in range(5):
    for p_ in (2,4,5,6):ST2["tt"]["list"][0]["cells"][f"{w}-{p_}"]={"subject":"물리학","clsId":"c1","clsName":"","room":""}
  M=dev(b,ST2,"2026-10-22T08:20:00+09:00",{"rg":"seoul"},WX);M.wait_for_timeout(2600);sh=M.inner_text("#sheetBox") if M.is_visible("#sheet") else "";print("  morning:",sh[:400].replace("\n"," | "))
  ok("좋은 아침입니다" in sh and "서울은 오늘 아침 -3도" in sh and "영하의 아침" in sh,"morning: weather & temperature")
  ok("빼곡한 하루" in sh and "할 일 4개" in sh,"morning: workload reflected")
  M.click("#chMood [data-m=tired]");M.wait_for_timeout(100);re_=M.inner_text("#chRe");ok("80%" in re_ and "내일로 미뤄도" in re_,"morning: mood × workload reply: "+re_)
  M.click("#chGo")
  N=dev(b,ST2,"2026-10-22T13:55:00+09:00",{"rg":"seoul"},WX);N.evaluate("()=>{localStorage.setItem('att-app-diary',JSON.stringify({'2026-10-22':{am:'tired'}}))}");N.reload();N.wait_for_timeout(2600)
  sh=N.inner_text("#sheetBox") if N.is_visible("#sheet") else "";print("  noon:",sh[:300].replace("\n"," | "))
  ok("오후 일과를 시작해요" in sh and "아침에 조금 지쳐 계셨는데" in sh,"noon: remembers morning mood")
  ok("서울은 지금 -3도" in sh and "오후에 수업" in sh,"noon: weather + remaining classes")
  N.click("#chMood [data-m=good]");N.wait_for_timeout(100);ok("오후도" in N.inner_text("#chRe"),"noon: mood reply");N.click("#chGo")
  V=dev(b,ST2,"2026-10-22T17:10:00+09:00",{"rg":"seoul"},WX);V.evaluate("()=>{localStorage.setItem('att-app-diary',JSON.stringify({'2026-10-22':{am:'tired',noon:'hard'}}))}");V.reload();V.wait_for_timeout(2600)
  sh=V.inner_text("#sheetBox") if V.is_visible("#sheet") else "";print("  evening:",sh[:300].replace("\n"," | "))
  ok("서울의 퇴근길은 -3도" in sh and "지친 마음으로도" in sh and "정말 바쁜 하루" in sh,"evening: weather + mood memory + workload")
  V.click("#chMood [data-m=ok]");V.fill("#chNote","3반 발표 좋았음");V.click("#chGo");V.wait_for_timeout(100)
  dy=json.loads(V.evaluate("localStorage.getItem('att-app-diary')"))["2026-10-22"];ok(dy.get("am")=="tired" and dy.get("noon")=="hard" and dy.get("m")=="ok" and dy.get("t"),"diary keeps morning/noon/evening moods")
  Q=dev(b,ST2,"2026-10-22T13:55:00+09:00",{"rg":"seoul","noon":False},WX);Q.wait_for_timeout(2600);ok(Q.is_hidden("#sheet"),"오후 인사 can be turned off")
  # ---- 3. 알림 방식 (벨소리 · 진동)
  A=dev(b,ST,"2026-10-22T08:56:00+09:00");A.wait_for_timeout(3200)
  pl=A.evaluate("window.__plays");vb=A.evaluate("window.__vib");print("  plays:",pl[-1:] ,"vib:",vb[-1:])
  ok(A.is_visible("#alarmBar") and any(x["src"].startswith("blob:") for x in pl) and [200,100,200] in vb,"class alarm: screen + bell + vibration (defaults)")
  A.click("#abX");A.click(".navb[data-v=tt]");A.wait_for_timeout(300)
  A.click("[data-als=snd][data-alv=bell]");A.click("[data-als=vib][data-alv=heart]");A.click("[data-als=vol][data-alv='1']");A.wait_for_timeout(100)
  st_=json.loads(A.evaluate("localStorage.getItem('att-app-alstyle')"));ok(st_=={"snd":"bell","vib":"heart","vol":1},"style saved: "+str(st_))
  A.evaluate("window.__plays=[];window.__vib=[]");A.click("#alTest");A.wait_for_timeout(200)
  ok(A.evaluate("window.__plays.length")==1 and A.evaluate("window.__plays[0].vol")==1 and A.evaluate("window.__vib[0]")==[120,80,120,420,120,80,120],"preview uses chosen bell/volume/vibration")
  A.click("[data-als=snd][data-alv=none]");A.click("[data-als=vib][data-alv=none]");A.evaluate("window.__plays=[];window.__vib=[];localStorage.removeItem('att-app-clsal-seen')");A.reload();A.wait_for_timeout(3300)
  ok(A.is_visible("#alarmBar") and A.evaluate("window.__plays.filter(x=>x.vol>0).length")==0 and A.evaluate("window.__vib.filter(v=>v&&v.length).length")==0,"소리 없음 · 진동 없음 → screen only")
  wav=A.evaluate("async()=>{const r=await fetch(document.querySelector('audio')?'':'');return 1}") if False else None
  sizes=A.evaluate("()=>['chime','bell','xylo','soft','wood'].map(k=>{const u=alWav?1:0;return u})") if False else None
  b.close()
print("fails",F);print(errs)
