src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
ros=[["10101","가람"],["10102","가온"],["10103","나래"],["10104","다솜"]]
def state():
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":ros,"phones":{},"emails":{},"teachers":[],"msg":"m",
     "sessions":[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True,"10103":True},"src":"t1:2:3"}]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":{"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-5":{"subject":"물리학","clsId":"c1","clsName":"","room":""}},"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','todo');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def d1(T):return root(T)["list"][0]["data"]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click(".navb[data-v=att]");T.wait_for_timeout(200);T.evaluate("document.querySelector('[data-key=\"m:obs\"]').click()");T.wait_for_timeout(300)
  sid=d1(T)["roster"][0][0]
  ks=T.evaluate("[...document.querySelectorAll('#obsBar [data-k]')].map(b=>b.dataset.k)");k1,k2=ks[0],ks[1]
  T.click("#obsBar [data-k='%s']"%k1);T.wait_for_timeout(100);T.click("#obsList [data-s='%s']"%sid);T.wait_for_timeout(150);T.click("#obsList [data-s='%s']"%sid);T.wait_for_timeout(150)
  T.click("#obsBar [data-k='%s']"%k2);T.wait_for_timeout(100);T.click("#obsList [data-s='%s']"%sid);T.wait_for_timeout(150)
  T.click("#obsBar [data-k='%s']"%k2);T.wait_for_timeout(100)
  rec=lambda:[r for r in d1(T).get("obs",[]) if r["sid"]==sid and r["date"]=="2026-10-28"]
  ok(rec() and rec()[0]["tags"]=={k1:2,k2:1},"빠른 체크: %s ×2 · %s ×1"%(k1,k2))
  T.click("#obsList [data-e='%s']"%sid);T.wait_for_timeout(300)
  ok(T.locator("#obNow .obnr").count()==2 and T.locator("#obNow [data-dec]").count()==2 and T.locator("#obNow [data-rmk]").count()==2,"기록 창: 이 날 항목마다 −1 · ✕")
  ok("모두 삭제" in T.inner_text("#obDel"),"전체 삭제 단추는 ‘이 날 기록 모두 삭제’로 분명하게")
  T.click("#obNow [data-dec='%s']"%k1);T.wait_for_timeout(200);ok(rec()[0]["tags"]=={k1:1,k2:1},"−1 → 잘못 누른 1회만 빠짐(바로 저장)")
  T.click("#obNow [data-rmk='%s']"%k2);T.wait_for_timeout(200);ok(rec()[0]["tags"]=={k1:1} and T.locator("#obNow .obnr").count()==1,"✕ → 그 항목만 빠짐(다른 항목은 그대로)")
  T.click("#utoast button");T.wait_for_timeout(200);ok(rec()[0]["tags"]=={k1:1,k2:1} and T.locator("#obNow .obnr").count()==2,"되돌리기")
  T.fill("#obMemo","메모 남김");T.click("#obOk");T.wait_for_timeout(200)
  T.click("#obsList [data-e='%s']"%sid);T.wait_for_timeout(300);T.click("#obNow [data-rmk='%s']"%k1);T.wait_for_timeout(100);T.click("#obNow [data-rmk='%s']"%k2);T.wait_for_timeout(200)
  ok(rec() and rec()[0]["tags"]=={} and rec()[0]["memo"]=="메모 남김","항목을 모두 빼도 메모는 남음")
  T.screenshot(path="shot/t172.png")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
