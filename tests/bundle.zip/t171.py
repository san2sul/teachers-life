src=open('audit2.py').read();exec(src.split("sizes=")[0])
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
r1=[["10101","가람"],["10102","가온"]];r2=[["10201","다솜"]]
def state():
  cells={"0-2":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"2-3":{"subject":"물리학","clsId":"c1","clsName":"","room":""},"1-1":{"subject":"물리학","clsId":"c2","clsName":"","room":""},"3-4":{"subject":"통합과학","clsId":"c2","clsName":"","room":""}}
  ses=[{"id":"s1","date":"2026-10-28","time":"11:00","label":"3교시 물리학","p":{"10101":True,"10102":True},"src":"t1:2:3"}]
  return {"active":"c1","list":[{"id":"c1","data":{"v":3,"cls":"1학년 1반","year":2026,"term":"2학기","roster":r1,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":ses}},
    {"id":"c2","data":{"v":3,"cls":"1학년 2반","year":2026,"term":"2학기","roster":r2,"phones":{},"emails":{},"teachers":[],"msg":"m","sessions":[]}}],"staff":[],
    "tt":{"list":[{"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}],"active":"t1"},
    "flowCfg":{"auto":True},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"plans":[{"id":"pl1","subj":"물리학","year":2026,"term":"2학기","cls":["c1","c2"],"end":"2026-12-20","units":[{"id":"u1","n":"1. 힘과 운동","ch":[{"id":"a1","t":"속력과 속도"},{"id":"a2","t":"가속도"},{"id":"a3","t":"뉴턴 법칙"}]},{"id":"u2","n":"2. 열","ch":[{"id":"b1","t":"온도와 열"},{"id":"b2","t":"열평형"}]}],"pg":{"c1":{"a1":{"st":"d","d":"2026-10-21"}}}}],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-28T11:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
INIT="try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-view','tt');localStorage.setItem('att-app-ttmode','week');localStorage.setItem('att-app-amode','att');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state()))
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def plan(T):return [p for p in root(T)["plans"] if p["subj"]=="물리학"][0]
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",device_scale_factor=2);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script(INIT);T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  T.click(".navb[data-v=att]");T.wait_for_timeout(800);H="#sheetBox .flsheetnow"
  def fs(X=None):
    X=X or T
    if X.is_hidden("#sheet") or not X.locator("#sheetBox .flsheetnow").count():
      if X.evaluate("document.documentElement.dataset.view")!="att":X.click(".navb[data-v=att]");X.wait_for_timeout(600)
      X.evaluate("document.getElementById('sheet').hidden=true");X.click("#flLine [data-fls]");X.wait_for_timeout(500)
  T.click("#flLine [data-flpick]");T.wait_for_timeout(300);T.click("#sheetBox [data-fp='b:5']");T.click("#flUse");T.wait_for_timeout(1300);fs()
  box=lambda:(fs(),T.inner_text(H+" [data-flowbox]"))[1]
  sec=lambda t:int(t.split(":")[0])*60+int(t.split(":")[1])
  ok("3/5" in box() and "활동" in box() and T.locator(H+" [data-flprev]").count()==1,"‹ 이전 단추 "+box().split("\n")[0])
  fs();ok(T.locator(H+" [data-fltool]").count()==1 and "타이머 열기" in T.inner_text(H+" [data-fltool]"),"지금 단계(활동)에 ‘⏱ 타이머 열기’ 단추")
  fs();T.click(H+" [data-fltool]");T.wait_for_timeout(400);lt=sec((fs(),T.inner_text(H+" [data-fltime]"))[1]) if False else None
  ok(T.is_visible("#ctool") and T.get_attribute("#ctool [data-ct=tm]","aria-pressed") in ("true",None) and T.inner_text("#ctBig") in ("15:00","14:00") and "시작" in T.inner_text("#ctTmGo"),"누르면 타이머가 그 단계 남은 시간으로 맞춰져 열림 "+T.inner_text("#ctBig"))
  T.click("#ctX");T.wait_for_timeout(600)
  fs()
  ok(T.locator("#sheetBox [data-fltl]").count()==2,"수업 흐름 창: 도구 있는 단계마다 열기 단추")
  T.click("#sheetBox [data-fltl='3']");T.wait_for_timeout(400);ok(T.is_visible("#ctool") and T.is_visible("#ctGo"),"‘🎯 발표자 뽑기 열기’ → 뽑기 화면")
  T.click("#ctX");T.wait_for_timeout(600)
  fs();T.click(H+" [data-flprev]");T.wait_for_timeout(1300);t=(fs(),T.inner_text(H+" [data-fltime]"))[1]
  ok("2/5" in box() and "개념 학습" in box() and sec(t)>=110,"이전 단계(개념 학습)로 돌아감 · 남은 "+t)
  fs();T.click(H+" [data-flnext]");T.wait_for_timeout(1300);ok(T.is_visible("#ctool"),"활동 단계 → 타이머 열림");T.click("#ctX");T.wait_for_timeout(1200);ok("3/5" in box() and "활동" in box(),"다음 › 로 다시 활동")
  a0=sec((fs(),T.inner_text(H+" [data-fltime]"))[1])
  fs()
  ok(T.locator("#sheetBox [data-flbk]").count()==2 and T.locator("#sheetBox .flsr >> nth=0").locator("[data-fla]").count()==0 and T.locator("#sheetBox .flsr >> nth=2").locator("[data-fla]").count()==2,"지난 단계는 ↩ 돌아가기, 지금 · 뒤 단계는 −1 · ＋1")
  T.click("#sheetBox [data-flbk='0']");T.wait_for_timeout(300)
  ok(T.locator("#sheetBox .flsr.on >> nth=0").inner_text().find("동기 유발")>=0 and T.locator("#sheetBox .flsr.on").locator("[data-fla]").count()==2,"↩ 로 첫 단계로 돌아가면 그 단계 시간 고치기")
  T.click("#sheetBox .flsr.on [data-fla$='|60000']");T.wait_for_timeout(200);T.click("#skNo");T.wait_for_timeout(1300)
  t=(fs(),T.inner_text(H+" [data-fltime]"))[1];ok("1/5" in box() and "동기 유발" in box() and sec(t)>=170,"돌아간 단계 ＋1분 → 남은 "+t)
  fs();T.click(H+" [data-flnext]");T.wait_for_timeout(1300);ok("2/5" in box() and "개념 학습" in box(),"다음 › 로 이어서")
  # 5.80.2 틀 만들기: 단계 넣기 위치 · 한국어 입력
  T.click("#skNo");T.wait_for_timeout(200)
  T.click(".navb[data-v=tt]");T.wait_for_timeout(300);T.click("#ttPnBtn");T.wait_for_timeout(300);T.click("#flMgrB");T.wait_for_timeout(300);T.click("#flNew2");T.wait_for_timeout(300)
  names=lambda:T.evaluate("[...document.querySelectorAll('#sheetBox .fled [data-k=n]')].map(i=>i.value)")
  ok(T.get_attribute("#flN","lang")=="ko" and T.get_attribute("#sheetBox .fled [data-k=n]","lang")=="ko","입력칸 한국어(lang=ko)")
  ok(T.locator("#sheetBox input[type=number]").count()==0 and T.locator("#sheetBox .fled select[data-k=m]").count()==T.locator("#sheetBox .fled").count(),"5.80.3 시간 칸은 고르기 목록(숫자 자판 없음 → 한글 입력 유지)")
  T.select_option("#sheetBox .fled[data-j='0'] [data-k=m]","7");T.wait_for_timeout(100);ok("7" in T.input_value("#sheetBox .fled[data-j='0'] [data-k=m]"),"시간 목록에서 7분 고르기")
  T.click("#sheetBox .fled[data-j='0'] [data-k=n]");T.click("#flAdd");T.wait_for_timeout(200)
  ok(names()==["도입","","전개","정리"] and T.evaluate("document.activeElement.closest('.fled').dataset.j")=="1","1단계 칸에서 ＋ 단계 넣기 → 바로 다음 줄(2번째)에 "+str(names()))
  T.keyboard.type("동기 유발");T.focus("#sheetBox .fled[data-j='2'] [data-k=m]");T.click("#flAdd");T.wait_for_timeout(200)
  ok(names()==["도입","동기 유발","전개","","정리"],"3단계 시간 칸에서 → 4번째에 "+str(names()))
  T.click("#flN");T.click("#flAdd");T.wait_for_timeout(200);ok(names()[-1]=="" and len(names())==6,"단계 칸이 아닌 곳(틀 이름)에서 → 맨 끝에 "+str(names()))
  T.click("#sheetBox h2");T.click("#flAdd");T.wait_for_timeout(200);ok(len(names())==7 and names()[-1]=="","빈 곳을 누른 뒤 → 맨 끝에")
  T.click("#skNo");T.wait_for_timeout(200);T.click("#skNo");T.wait_for_timeout(200);T.click(".ttmode [data-tm=week]");T.wait_for_timeout(200)
  # 알림 소리 · 진동
  SPYA="window.__osc=0;window.__vib=[];window.__plays=[];const _s=OscillatorNode.prototype.start;OscillatorNode.prototype.start=function(...a){window.__osc++;return _s.apply(this,a)};const _p=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){window.__plays.push(String(this.src).slice(0,30));return _p.apply(this,arguments)};navigator.vibrate=function(p){window.__vib.push(p);return true}"
  snd=lambda P:P.evaluate("window.__osc")+len([x for x in P.evaluate("window.__plays") if x])
  for ua,name in [(None,"안드로이드 · 컴퓨터"),("Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1","아이폰")]:
    c2=b.new_context(viewport={"width":390,"height":844},service_workers="block",timezone_id="Asia/Seoul",**({"user_agent":ua} if ua else {}));c2.route("**/*",handler)
    P=c2.new_page();P.on("pageerror",lambda e:errs.append(str(e)));P.add_init_script(FIX);P.add_init_script(INIT);P.add_init_script(SPYA);P.goto("https://tl.test/index.html");P.wait_for_timeout(900)
    P.click(".navb[data-v=att]");P.wait_for_timeout(800);P.click("#flLine [data-flpick]");P.wait_for_timeout(300);P.click("#sheetBox [data-fp='b:3']");P.click("#flUse");P.wait_for_timeout(1300)
    fs(P)
    cap=P.inner_text("#sheetBox .flcap");ok("소리 준비됨" in cap,name+": 화면을 누른 뒤 소리 준비됨 "+cap.replace("\n"," / "))
    ok(("진동 됨" in cap)==(ua is None),name+": 진동 지원 표시")
    P.evaluate("window.__osc=0;window.__plays=[];window.__vib=[];window.__flowAlerts=[]");P.click("#flBell");P.wait_for_timeout(700)
    al=P.evaluate("window.__flowAlerts");ok(al and al[-1][2]["snd"] and snd(P)>=1,name+": 🔔 알림 시험 소리(차임) "+str(al[-1][2])+" 재생=%d"%snd(P))
    ok(P.evaluate("window.__plays").count(P.evaluate("window.__plays")[-1])>=1 if P.evaluate("window.__plays") else True,name+": 깨워 둔 재생기로 재생")
    # 미리 돌려 보기: 화면을 누르지 않은 채 이어지는 알림도 매번 소리
    P.evaluate("window.__osc=0;window.__plays=[];window.__vib=[];window.__flowAlerts=[]");P.click("#flSim");P.wait_for_timeout(6500);P.click("#flSim")
    AL=P.evaluate("window.__flowAlerts");al=[a for a in AL if a[2]["snd"]];pl=snd(P)
    if ua:ok(len(al)>=2 and pl>=len(al),name+": 미리 돌려 보기 알림 %d번 모두 소리(재생 %d)"%(len(al),pl))
    else:ok(len(AL)>=2 and len(P.evaluate("window.__vib"))>=len(AL),name+": 미리 돌려 보기 알림 %d번 모두 진동"%len(AL))
    P.click("#skNo");P.wait_for_timeout(300);P.evaluate("window.__osc=0;window.__plays=[];window.__vib=[];window.__flowAlerts=[]");fs(P);P.click(H+" [data-flnext]");P.wait_for_timeout(1300)
    al=P.evaluate("window.__flowAlerts");a2=al[-1][2] if al else {}
    if ua is None:ok(a2.get("vib") and P.evaluate("window.__vib")[-1:]==[[400,150,400,150,400]] and not a2.get("snd"),name+": ‘진동’ 단계 → 진동 "+str(a2)+str(P.evaluate("window.__vib")))
    else:ok(a2.get("snd") and not a2.get("vib") and snd(P)>=1,name+": 진동 못 하는 기기는 ‘진동’ 단계도 소리로 "+str(a2))
    c2.close()
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
