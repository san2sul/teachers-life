src=open('audit2.py').read();exec(src.split("sizes=")[0])
import re,urllib.parse,io
F=[]
def ok(c,m):print(("OK  " if c else "FAIL"),m);(None if c else F.append(m))
STAFF=[{"name":"김과학","phone":"010-1000-0001","dept":"교무부","role":"교무부장","subj":"과학"},{"name":"이수학","phone":"010-1000-0002","dept":"연구부","role":"수업","subj":"수학"},
       {"name":"박국어","phone":"010-1000-0003","dept":"교무부","role":"학적","subj":"국어","email":"park@school.kr"},{"name":"최물리","phone":"010-1000-0004","dept":"과학정보부","role":"부장","subj":"과학"}]
def cls(i,name,roster,phones,emails={}):return {"id":i,"data":{"v":3,"cls":name,"year":2026,"term":"2학기","roster":roster,"phones":phones,"emails":emails,"teachers":[],"msg":"m","sessions":[]}}
def state():
  cells={f"{w}-1":{"subject":"물리학","clsId":"c1","clsName":"","room":""} for w in range(5)}
  t={"id":"t1","year":2026,"term":"2학기","start":"09:00","classMin":50,"breakMin":10,"lunchMin":60,"cells":cells,"adj":{},"days":{},"chg":[]}
  return {"active":"c1","list":[cls("c1","1학년 1반",[["10101","가람"],["10102","가온"]],{"10101":"010-1111-0001"}),cls("c2","1학년 2반",[["10201","나래"],["10202","누리"]],{"10201":"010-2222-0001","10202":"010-2222-0002"}),cls("c3","2학년 1반",[["20101","다솜"]],{},{"20101":"dasom@ex.com"})],
    "staff":STAFF,"tt":{"list":[t],"active":"t1"},"notes":{},"events":[],"evals":[],"tasks":[],"recs":[],"period":{"year":2026,"term":"2학기"}}
FIX="(()=>{const R=Date,off=new R('2026-10-23T15:20:00+09:00').getTime()-R.now();class D extends R{constructor(...a){a.length?super(...a):super(R.now()+off)}static now(){return R.now()+off}};window.Date=D})()"
errs=[]
def root(T):return json.loads(T.evaluate("localStorage.getItem('att-app-v2')"))
def flush(T):T.wait_for_timeout(560)
def spy(T):return T.evaluate("window.__goSpy")
def rows(T):return T.locator(".rcov [data-rc]").count()
with sync_playwright() as p:
  b=p.chromium.launch();c=b.new_context(viewport={"width":390,"height":844},is_mobile=True,has_touch=True,device_scale_factor=2,service_workers="block",timezone_id="Asia/Seoul",accept_downloads=True);c.route("**/*",handler)
  T=c.new_page();T.on("pageerror",lambda e:errs.append(str(e)));T.add_init_script(FIX);T.add_init_script("window.__goSpy=[];window.__fileSpy=[];window.__printSpy=[];")
  T.add_init_script("try{if(!localStorage.getItem('att-app-v2')){localStorage.setItem('att-app-v2',%s);localStorage.setItem('att-app-lastver','9.9.9');localStorage.setItem('att-app-setup','1');localStorage.setItem('att-app-ui',JSON.stringify({open:'last'}));localStorage.setItem('att-app-view','att');localStorage.setItem('att-app-amode','write');localStorage.setItem('att-app-wrk','day');localStorage.setItem('att-app-cheer',JSON.stringify({am:false,pm:false,noon:false}));localStorage.setItem('att-app-clsal','0')}}catch(e){}"%json.dumps(json.dumps(state())))
  T.goto("https://tl.test/index.html");T.wait_for_timeout(900)
  # ---- 전달하기: 교직원 · 학생 찾기
  T.evaluate("document.querySelector('[data-key=\"w:day\"]').click()");T.wait_for_timeout(150);T.click("#wrCard [data-wn=day]");T.wait_for_timeout(300);T.click("#wrEd .wbt");T.keyboard.type("내일 협의회",delay=5);flush(T);T.click("#skNo");T.wait_for_timeout(300)
  T.locator("#wrCard [data-ws]").first.click();T.wait_for_timeout(300)
  ok(T.locator("#wsPS").count()==1 and T.locator("#wsPU").count()==1 and T.locator("#wsTo").count()==1,"전달: 교직원 · 학생 찾기 · 직접 입력")
  T.click("#wsPS");T.wait_for_timeout(300)
  ok(rows(T)==4 and T.locator(".rcov [data-r1]").count()==4 and T.locator(".rcov [data-r2]").count()==4,"교직원 찾기: 부서 · 교과 단추")
  T.fill("#rcQ","과학");T.wait_for_timeout(150);ok(rows(T)==2,"교과(과학)로 찾기")
  T.fill("#rcQ","학적");T.wait_for_timeout(150);ok(rows(T)==1,"역할(학적)로 찾기")
  T.fill("#rcQ","이수");T.wait_for_timeout(150);ok(rows(T)==1,"이름으로 찾기")
  T.fill("#rcQ","");T.click(".rcov [data-r1='교무부']");T.wait_for_timeout(150);ok(rows(T)==2,"부서로 거르기")
  T.screenshot(path="shot/t142_staff.png")
  T.click("#rcAll");T.wait_for_timeout(100);ok("2명 고름" in T.inner_text("#rcN"),"보이는 사람 모두 고르기");T.click("#rcOk");T.wait_for_timeout(300)
  ok(T.locator("#sheetBox .rcc").count()==2,"받는 사람 칩 2명")
  T.click("#wsPU");T.wait_for_timeout(300);ok(rows(T)==5 and T.locator(".rcov [data-r1]").count()==3,"학생 찾기: 학년 단추 (전체 · 1 · 2)")
  T.click(".rcov [data-r1='1']");T.wait_for_timeout(150);ok(rows(T)==4 and T.locator(".rcov [data-r2]").count()==3,"1학년 → 반 단추")
  T.click(".rcov [data-r2='1학년 2반']");T.wait_for_timeout(150);ok(rows(T)==2,"반으로 거르기")
  T.click(".rcov [data-r1='']");T.wait_for_timeout(150);T.fill("#rcQ","1학년 2반 나");T.wait_for_timeout(150);ok(rows(T)==1,"‘1학년 2반 나’로 찾기")
  T.screenshot(path="shot/t142_stu.png")
  T.locator(".rcov [data-rc]").first.check();T.click("#rcOk");T.wait_for_timeout(300)
  ok(T.locator("#sheetBox .rcc").count()==3,"학생 칩 추가")
  T.fill("#wsTo","010-9999-0000");T.click("[data-wsh=sms]");T.wait_for_timeout(300);g=spy(T)[-1]
  ok(g.startswith("sms:") and all(x in g for x in ["01010000001","01010000003","01022220001","01099990000"]),"고른 사람 + 직접 입력 모두에게 문자")
  T.click("[data-wsh=mail]");T.wait_for_timeout(300);ok(spy(T)[-1].startswith("mailto:park%40school.kr?subject="),"메일은 주소 있는 사람에게")
  T.locator("#sheetBox .rcc button").first.click();T.wait_for_timeout(200);ok(T.locator("#sheetBox .rcc").count()==2,"칩 빼기")
  T.screenshot(path="shot/t142_share.png")
  T.click("#skNo");T.wait_for_timeout(300)
  # ---- 웹 링크: 링크 글자 없이 단추
  T.locator("#wrCard [data-wo]").first.click();T.wait_for_timeout(400);T.click("[data-wc=tool]");T.click("#wrTool [data-ex]");T.wait_for_timeout(200);T.click(".wexp [data-x=link]");T.wait_for_timeout(2000)
  ok(T.locator(".wweb textarea").count()==0 and T.locator("#wwU").get_attribute("type")=="hidden" and "/view.html#v=" in T.input_value("#wwU"),"웹 링크: 주소를 보여 주지 않음")
  ok("http" not in T.inner_text(".wweb") and T.locator("#wwSh").count()==1 and T.locator("#wwO").count()==1,"공유 · 열어 보기 단추")
  T.screenshot(path="shot/t142_web.png")
  T.click("#wwO");T.wait_for_timeout(200);ok("/view.html#v=" in spy(T)[-1],"열어 보기")
  T.click("#wwNo");T.wait_for_timeout(200);T.click("#skNo");T.wait_for_timeout(300)
  # ---- 연락 → 직접 입력 칸에서 명단 찾기
  T.click(".navb[data-v=call]");T.wait_for_timeout(300);T.click("#ctabs [data-c=direct]");T.wait_for_timeout(300)
  T.locator("#dmTo [data-dsp=staff]").click();T.wait_for_timeout(300);T.fill("#rcQ","국어");T.wait_for_timeout(150);T.locator(".rcov [data-rc]").first.check();T.click("#rcOk");T.wait_for_timeout(200)
  ok("박국어" in T.input_value("#dmToT") and "010-1000-0003" in T.input_value("#dmToT"),"직접 보내기 칸: 명단에서 찾아 넣기")
  T.locator("#dmTo [data-dsp=stu]").click();T.wait_for_timeout(300);T.click(".rcov [data-r1='2']");T.wait_for_timeout(150);T.locator(".rcov [data-rc]").first.check();T.click("#rcOk");T.wait_for_timeout(200)
  ok("dasom@ex.com" in T.input_value("#dmToT"),"학생에서 찾아 넣기 (이메일)")
  T.click("#dmTo [data-ds=sms]");T.wait_for_timeout(300);ok(spy(T)[-1].startswith("sms:01010000003"),"찾아 넣은 사람에게 문자")
  b.close()
ok(errs==[],"no page errors "+str(errs[:3]))
print("FAILS:",F);sys.exit(1 if F else 0)
